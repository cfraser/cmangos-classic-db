-- Fixed required skill for quest 2203 (Badlands Reagent Run (2))
-- Source: http://www.wowhead.com/quest=2203/badlands-reagent-run-ii
UPDATE quest_template SET RequiredSkillValue = 210 WHERE entry = 2203;
