-- Added missing GO : 180671 (Xandivious' Demon Bag) used in quest 8481 (The Root of all Evil)
DELETE FROM `gameobject_template` WHERE `entry` = 180671;
INSERT INTO `gameobject_template` (`entry`, `type`, `displayId`, `name`, `data0`, `data1`) VALUES
(180671,3,644,'Xandivious\' Demon Bag',43,17516);

-- Add loot for The Root of All Evil
DELETE FROM `gameobject_loot_template` WHERE `Entry` = 17516;
INSERT INTO `gameobject_loot_template` (`Entry`,`Item`,`ChanceOrQuestChance`) VALUES
(17516,21145,-100);

-- DELETE FROM `creature_template` WHERE `Entry` = 15623;
-- INSERT INTO `creature_template` (`Entry`, `Name`, `SubName`, `MinLevel`, `MaxLevel`, `ModelId1`, `ModelId2`, `FactionAlliance`, `FactionHorde`, `Scale`, `Family`, `CreatureType`, `InhabitType`, `RegenerateStats`, `RacialLeader`, `NpcFlags`, `UnitFlags`, `DynamicFlags`, `ExtraFlags`, `CreatureTypeFlags`, `SpeedWalk`, `SpeedRun`, `UnitClass`, `Rank`, `HealthMultiplier`, `PowerMultiplier`, `DamageMultiplier`, `DamageVariance`, `ArmorMultiplier`, `ExperienceMultiplier`, `MinLevelHealth`, `MaxLevelHealth`, `MinLevelMana`, `MaxLevelMana`, `MinMeleeDmg`, `MaxMeleeDmg`, `MinRangedDmg`, `MaxRangedDmg`, `Armor`, `MeleeAttackPower`, `RangedAttackPower`, `MeleeBaseAttackTime`, `RangedBaseAttackTime`, `DamageSchool`, `MinLootGold`, `MaxLootGold`, `LootId`, `PickpocketLootId`, `SkinningLootId`, `KillCredit1`, `KillCredit2`, `MechanicImmuneMask`, `ResistanceHoly`, `ResistanceFire`, `ResistanceNature`, `ResistanceFrost`, `ResistanceShadow`, `ResistanceArcane`, `PetSpellDataId`, `MovementType`, `TrainerType`, `TrainerSpell`, `TrainerClass`, `TrainerRace`, `TrainerTemplateId`, `VendorTemplateId`, `GossipMenuId`, `EquipmentTemplateId`, `AIName`, `ScriptName`) VALUES (15623, 'Xandivious', NULL, 62, 62, 11341, 0, 90, 90, 1, 0, 3, 3, 3, 0, 0, 1, 0, 0, 0, 1, 1.14286, 8, 1, 8, 3, 1, 1, -1, 1, 20720, 20720, 7704, 7704, 648, 717, 0, 0, 3555, 315, 0, 2000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '');

DELETE FROM `creature_loot_template` WHERE `entry` = 15623;
UPDATE `creature_template` SET `LootId` = 0 WHERE `Entry` = 15623;

/*
DELETE FROM gameobject WHERE guid=99998;
INSERT INTO `gameobject` (guid, id, map, spawnMask, phaseMask, position_x, position_y, position_z, spawntimesecs, State) VALUES 
(99998, 180673, 1, 1, 1, 6723.67, -5271.68, 778, 180, 1);
*/
