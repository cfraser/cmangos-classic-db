


-- -----------------------

-- UPDATE `creature_template` SET `SpeedWalk`='1' WHERE `Entry`='2754';
