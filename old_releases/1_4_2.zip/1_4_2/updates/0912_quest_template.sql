


-- --------------------

UPDATE `quest_template` SET `PrevQuestId`='0' WHERE `entry`='3761';
