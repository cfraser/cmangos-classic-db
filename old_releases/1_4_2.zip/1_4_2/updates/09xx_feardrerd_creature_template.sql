-- Fixed stats of NPC 6652 (Master Feardred) in Azshara
UPDATE `creature_template` SET `UnitClass` = 1, `MinLevel` = 52, `MaxLevel` = 52, `MinLevelHealth` = 3082, `MaxLevelHealth` = 3082, `Armor` = 3128, `HealthMultiplier` = 1.3, `ArmorMultiplier` = 1 WHERE `Entry` = 6652;

SET @GUID := 2352;
SET @POOL := 1212;

DELETE FROM `creature` WHERE `guid` BETWEEN @GUID + 1 AND @GUID + 2;
INSERT INTO `creature` VALUES
(@GUID + 1, 6652, 1, 0, 0, 4776.41, -6639.24, 111.696, 1.72771, 28800, 0, 0, 3082, 0, 0, 0),
(@GUID + 2, 6652, 1, 0, 0, 4499.01, -6388.19, 127, 4.06034, 28800, 5, 0, 3082, 0, 0, 1);
UPDATE `creature` SET `spawndist` = 5, `MovementType` = 1, `spawntimesecs` = 8 * 60 * 60 WHERE `id` = 14344;

DELETE FROM `pool_creature_template` WHERE `id` = 14344;
INSERT INTO `pool_creature_template` VALUES
(6652, @POOL + 1, 0, 'Master Feardred (6652)');

DELETE FROM `pool_template` WHERE `entry` = @POOL + 1;
INSERT INTO `pool_template` VALUES
(@POOL + 1, 1, 'Master Feardred (6652)');