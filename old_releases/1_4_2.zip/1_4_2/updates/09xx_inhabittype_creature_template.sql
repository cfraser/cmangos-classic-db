-- Fixed InhabitType of a few creatures: this change is specific to Classic
-- due to the absence of true flying creatures aside from some bosses (scripted)
-- and some flavour creatures (only moving but no interaction with players.
-- The ones changed here have a flying-like animation
-- but are not really flying, leading to wrong behaviours on movement.
-- Also fixed InhabitType of a few creature that should only swim

UPDATE `creature_template` SET `InhabitType` = 2 WHERE `entry` IN (4830, 6145);
UPDATE `creature_template` SET `InhabitType` = 3 WHERE `entry` IN (7044, 7045);
UPDATE `creature_template` SET `InhabitType` = 4 WHERE `entry` = 16218;

DELETE FROM `creature_movement` WHERE `id` IN (6095, 6096);
INSERT INTO `creature_movement` (`id`, `point`, `position_x`, `position_y`, `position_z`, `waittime`, `script_id`, `textid1`, `textid2`, `textid3`, `textid4`, `textid5`, `emote`, `spell`, `orientation`, `model1`, `model2`) VALUES
(6095, 1, 3487.76, -2911.2, 319.406, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3.90954, 0, 0),
(6095, 2, 3487.76, -2911.2, 319.406, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3.90954, 0, 0),
(6096, 1, 3527.81, -2952.38, 319.326, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3.90954, 0, 0),
(6096, 2, 3527.81, -2952.38, 319.326, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3.90954, 0, 0);
UPDATE `creature` SET `MovementType` = 2 WHERE `id` = 16218;

