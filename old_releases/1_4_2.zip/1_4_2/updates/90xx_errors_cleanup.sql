-- Removed addons from creature previously removed
DELETE FROM `creature_addon` WHERE `guid` IN (91405, 91406, 91407, 91421, 91422, 91427);
-- Fixed gossip script no longer needed after previous update
DELETE FROM `dbscripts_on_gossip` WHERE `id` = 5740;
