-- Fixed spawn time of GO 176589 (Black Lotus) : it should respawn every hour
UPDATE `gameobject` SET `spawntimesecs` = 3600 WHERE `id` = 176589;

-- Added missing pool for the last zone where Black Lotus spawn (Burning Steppes)
SET @POOL := 942;

DELETE FROM `pool_gameobject` WHERE `guid` IN (20263, 20266, 20268, 20272, 20275, 20279, 20280, 20282, 20284, 20288, 20289, 20293, 20294, 20295, 20297, 20305, 20307, 33420, 65289, 65290);
INSERT INTO `pool_gameobject` VALUES
(20263, @POOL, 0, 'Burning Steppes - Black Lotus'),
(20266, @POOL, 0, 'Burning Steppes - Black Lotus'),
(20268, @POOL, 0, 'Burning Steppes - Black Lotus'),
(20272, @POOL, 0, 'Burning Steppes - Black Lotus'),
(20275, @POOL, 0, 'Burning Steppes - Black Lotus'),
(20279, @POOL, 0, 'Burning Steppes - Black Lotus'),
(20280, @POOL, 0, 'Burning Steppes - Black Lotus'),
(20282, @POOL, 0, 'Burning Steppes - Black Lotus'),
(20284, @POOL, 0, 'Burning Steppes - Black Lotus'),
(20288, @POOL, 0, 'Burning Steppes - Black Lotus'),
(20289, @POOL, 0, 'Burning Steppes - Black Lotus'),
(20293, @POOL, 0, 'Burning Steppes - Black Lotus'),
(20294, @POOL, 0, 'Burning Steppes - Black Lotus'),
(20295, @POOL, 0, 'Burning Steppes - Black Lotus'),
(20297, @POOL, 0, 'Burning Steppes - Black Lotus'),
(20305, @POOL, 0, 'Burning Steppes - Black Lotus'),
(20307, @POOL, 0, 'Burning Steppes - Black Lotus'),
(33420, @POOL, 0, 'Burning Steppes - Black Lotus'),
(65289, @POOL, 0, 'Burning Steppes - Black Lotus'),
(65290, @POOL, 0, 'Burning Steppes - Black Lotus');

DELETE FROM `pool_template` WHERE `entry` = @POOL;
INSERT INTO `pool_template` VALUES
(@POOL, 1, 'MASTER Herbs Black Lotus Burning Steppes zone 46');
