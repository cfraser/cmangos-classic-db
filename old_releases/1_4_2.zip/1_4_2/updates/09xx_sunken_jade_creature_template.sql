-- Fixed rank of NPC 1063 (Jade) at Sunken Temple entrance because this NPC is rare elite
UPDATE `creature_template` SET `rank` = 2 WHERE `Entry` = 1063;

DELETE FROM `creature_loot_template` WHERE `entry` = 1063;
INSERT INTO `creature_loot_template` VALUES
(1063, 4402, 16, 0, 1, 1, 0),
(1063, 4460, 10, 0, 1, 1, 0),
(1063, 4557, 10, 0, 1, 1, 0),
(1063, 8146, 2, 0, 1, 1, 0),
(1063, 24118, 100, 0, -24118, 1, 0),
(1063, 24120, 1, 0, -24120, 1, 0);

DELETE FROM `reference_loot_template` WHERE `entry` IN (24118, 24120);
INSERT INTO `reference_loot_template` VALUES
(24118, 24041, 25, 1, -24041, 1, 0),
(24118, 24043, 50, 1, -24043, 1, 0),
(24118, 24045, 25, 1, -24045, 1, 0),
(24120, 24025, 50, 1, -24025, 1, 0),
(24120, 24027, 25, 1, -24027, 1, 0),
(24120, 24045, 25, 1, -24045, 1, 0);
