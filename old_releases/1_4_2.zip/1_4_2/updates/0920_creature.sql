-- Removed duplicate NPC 12219 (Barbed Lasher) in Maraudon
DELETE FROM `creature` WHERE `guid` = 54310;
