


-- --------------------

UPDATE `quest_template` SET `MinLevel`='35' WHERE `entry`='4963';
