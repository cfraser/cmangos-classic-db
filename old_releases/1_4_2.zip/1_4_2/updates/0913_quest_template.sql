


-- --------------------

UPDATE `quest_template` SET `ReqItemId2`='0', `ReqItemCount2`='0' WHERE `entry`='6621';
