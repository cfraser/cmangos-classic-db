-- Fixed many wrong mineral ores node (bad node, wrong zone, wrong position, wrong type...)
-- Badlands
DELETE FROM `gameobject` WHERE `guid` IN (72444,72480,72486,72852,72984,73092,73140,72449,72485,72491,72857,72989,73097,73145,72445,72481,72487,72853,72985,73093,73141,72446, 72447, 72482, 72483, 72484, 72490, 72489, 72488, 72854, 72855, 72856, 72988, 72987, 72986, 73096, 73095, 73094, 73144, 73143, 73142);
-- Swamp of Sorrow
DELETE FROM `gameobject` WHERE `guid` IN (71853, 71857, 71921);
-- Wetlands
DELETE FROM `gameobject` WHERE `guid` = 77812;
-- Elwynn Forest
DELETE FROM `gameobject` WHERE `guid` IN (105257, 105261, 105259, 105258, 105256, 105260);
-- Durotar
DELETE FROM `gameobject` WHERE `guid` IN (5666, 5907);
UPDATE `gameobject` SET `id` = 1731 WHERE `guid` IN (5503, 5535);
-- Dustwallow Marsh
UPDATE `gameobject` SET `id` = 1735 WHERE `guid` IN (40823, 120390);
-- The Barrens
DELETE FROM `gameobject` WHERE `guid` = 74264;
UPDATE `gameobject` SET `id` = 1732 WHERE `guid` = 74263;
-- Loch Modan
DELETE FROM `gameobject` WHERE `guid` IN (71397, 71395, 71396, 71399);
-- Burning Steppes
DELETE FROM `gameobject` WHERE `guid` IN (76717, 76747);
-- Hinterlands
DELETE FROM `gameobject` WHERE `guid` IN (70012, 70024, 70216);
-- Feralas
DELETE FROM `gameobject` WHERE `guid` IN (18384, 9565, 6704, 7103, 5762);
-- Un'Goro Crater
DELETE FROM `gameobject` WHERE `guid` IN (5768,5802,5831,5866,5875,5883,5886,5901,5905,5920,5924,5925,5948,5949,5951,5969,5988);
