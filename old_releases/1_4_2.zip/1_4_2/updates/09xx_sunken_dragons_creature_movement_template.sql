-- Added movement to NPCs 5720 & 5721 (Dreamscythe and Weaver) in Sunken Temple
-- spawned after Jammal'an the Prophet is defeated. They will now patrol through the central room
-- Also fixed their faction and added skinning loot table

UPDATE `creature_template` SET `FactionAlliance` = 50, `FactionHorde` = 50, `MovementType` = 2 WHERE `Entry` IN (5720, 5721);
UPDATE `creature_template` SET `SkinningLootId` = 5720 WHERE `Entry` = 5720;
UPDATE `creature_template` SET `SkinningLootId` = 5721 WHERE `Entry` = 5721;

DELETE FROM creature_movement_template WHERE entry=5721;
INSERT INTO creature_movement_template (entry, point, position_x, position_y, position_z, orientation, waittime, script_id) VALUES
(5721,12,-482.917,42.428,-91.3105,100,0,0),
(5721,11,-452.024,39.6454,-91.2566,100,0,0),
(5721,10,-424.524,55.407,-91.2277,100,0,0),
(5721,9,-412.627,81.0488,-91.2901,100,0,0),
(5721,8,-413.346,111.11,-91.3013,100,0,0),
(5721,7,-429.363,136.152,-91.2937,100,0,0),
(5721,6,-452.177,148.956,-91.3031,100,0,0),
(5721,5,-484.049,149.333,-91.274,100,0,0),
(5721,4,-508.711,134.289,-91.2576,100,0,0),
(5721,3,-523.805,109.812,-91.2264,100,0,0),
(5721,2,-521.969,80.1382,-91.2695,100,0,0),
(5721,1,-506.573,54.6337,-91.2768,100,0,572101);

DELETE FROM creature_movement_template WHERE entry=5720;
INSERT INTO creature_movement_template (entry, point, position_x, position_y, position_z, orientation, waittime, script_id) VALUES
(5720,12,-506.573,54.6337,-91.2768,100,0,0),
(5720,11,-482.917,42.428,-91.3105,100,0,0),
(5720,10,-452.024,39.6454,-91.2566,100,0,0),
(5720,9,-424.524,55.407,-91.2277,100,0,0),
(5720,8,-412.627,81.0488,-91.2901,100,0,0),
(5720,7,-413.346,111.11,-91.3013,100,0,0),
(5720,6,-429.363,136.152,-91.2937,100,0,0),
(5720,5,-452.177,148.956,-91.3031,100,0,0),
(5720,4,-484.049,149.333,-91.274,100,0,0),
(5720,3,-508.711,134.289,-91.2576,100,0,0),
(5720,2,-523.805,109.812,-91.2264,100,0,0),
(5720,1,-521.969,80.1382,-91.2695,100,0,572001);

DELETE FROM `dbscripts_on_creature_movement` WHERE `id` IN (572001, 572101);
INSERT INTO `dbscripts_on_creature_movement` VALUES
(572001, 0, 25, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'Weaver - RUN ON'),
(572101, 0, 25, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'Dreamscythe - RUN ON');

DELETE FROM `skinning_loot_template` WHERE `entry` IN (5720, 5721);
INSERT INTO `skinning_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `groupid`, `mincountOrRef`, `maxcount`, `condition_id`) VALUES
(5720, 8165, 99.4318, 0, 1, 2, 0),
(5720, 8169, 20.1705, 0, 1, 1, 0),
(5720, 8170, 96.875, 0, 2, 3, 0),
(5720, 15412, 99.1477, 0, 2, 3, 0),
(5721, 8165, 98.2558, 0, 1, 2, 0),
(5721, 8169, 19.186, 0, 1, 1, 0),
(5721, 8170, 97.093, 0, 2, 3, 0),
(5721, 15412, 98.5465, 0, 2, 3, 0);
