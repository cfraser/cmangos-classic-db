
UPDATE `npc_vendor` SET `maxcount`='1' WHERE `entry`='2480' and`item`='14634';
