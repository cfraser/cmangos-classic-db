
UPDATE `creature_template` SET `Armor`='3216', `MeleeBaseAttackTime`='2000', `ResistanceHoly`='0', `ResistanceFire`='0', `ResistanceNature`='0', `ResistanceFrost`='0', `ResistanceShadow`='0', `ResistanceArcane`='0', `AIName`='EventAI' WHERE `Entry`='8911';
