-- Added movement to NPCs 5719 & 5722 (Hazzah and Morphaz) in Sunken Temple
-- They will now patrol through the room before Eranikus

DELETE FROM `creature_movement_template` WHERE `entry` IN (5722, 5719);
INSERT INTO `creature_movement_template` VALUES 
(5719, 1, -644.219, 58.4874, -90.8341, 0, 571901, 0, 0, 0, 0, 0, 0, 0, 1.57404, 0, 0),
(5719, 2, -644.331, 136.016, -90.8297, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3.20482, 0, 0),
(5719, 3, -674.273, 134.121, -90.8297, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4.72107, 0, 0),
(5719, 4, -673.602, 56.772, -90.8339, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6.27551, 0, 0),
(5719, 5, -643.732, 56.5426, -90.8339, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6.27551, 0, 0),
(5722, 1, -644.27, 74.3273, -90.8327, 0, 572201, 0, 0, 0, 0, 0, 0, 0, 1.57404, 0, 0),
(5722, 2, -644.468, 135.471, -90.8296, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3.22119, 0, 0),
(5722, 3, -673.758, 133.936, -90.8296, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4.71017, 0, 0),
(5722, 4, -673.928, 57.2586, -90.8338, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6.27006, 0, 0),
(5722, 5, -643.802, 56.8631, -90.8338, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1.57403, 0, 0);

UPDATE `creature_template` SET `MovementType` = 2 WHERE `Entry` IN (5722, 5719);
UPDATE `creature` SET `MovementType` = 2 WHERE `id` IN (5722, 5719);

DELETE FROM `dbscripts_on_creature_movement` WHERE `id` IN (571901, 572201);
INSERT INTO `dbscripts_on_creature_movement` VALUES
(571901, 0, 25, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'Hazzah - RUN ON'),
(572201, 0, 25, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'Morphaz - RUN ON');
