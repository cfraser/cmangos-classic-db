-- Removed wrong spawn of NPC 8257 (Oozeling) and NPC 8497 (Nightmare Suppressor) in Sunken Temple
DELETE FROM `creature` WHERE `guid` IN (33638, 33600, 39733, 38087);

