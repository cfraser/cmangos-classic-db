
UPDATE `quest_template` SET `questlevel`='20', `requiredraces`='178', `RewMoneyMaxLevel`='465' WHERE `entry`='2985';
UPDATE `quest_template` SET `RewMoneyMaxLevel`='840' WHERE `entry`='63';
UPDATE `quest_template` SET `RewMoneyMaxLevel`='1650' WHERE `entry`='96';
UPDATE `quest_template` SET `RewMoneyMaxLevel`='750' WHERE `entry`='100';
UPDATE `quest_template` SET `RewMoneyMaxLevel`='276' WHERE `entry`='220';
UPDATE `quest_template` SET `minlevel`='20' WHERE `entry`='1103';
UPDATE `quest_template` SET `RewMoneyMaxLevel`='465' WHERE `entry`='1528';
UPDATE `quest_template` SET `RewMoneyMaxLevel`='465' WHERE `entry`='1529';
UPDATE `quest_template` SET `RewMoneyMaxLevel`='264' WHERE `entry`='1530';
UPDATE `quest_template` SET `RewMoneyMaxLevel`='840' WHERE `entry`='1534';
UPDATE `quest_template` SET `RewMoneyMaxLevel`='525' WHERE `entry`='1535';
UPDATE `quest_template` SET `RewMoneyMaxLevel`='780' WHERE `entry`='1536';
UPDATE `quest_template` SET `questlevel`='20', `RewMoneyMaxLevel`='465' WHERE `entry`='2986';
