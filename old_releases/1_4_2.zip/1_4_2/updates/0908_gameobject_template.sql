


-- -------------------------

UPDATE `gameobject_template` SET `size`='0.2' WHERE `entry`='161513';
