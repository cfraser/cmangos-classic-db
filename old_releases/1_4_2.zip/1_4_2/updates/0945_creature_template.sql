
UPDATE `creature_template` SET `DamageSchool`='4' WHERE `Entry`='5462';
