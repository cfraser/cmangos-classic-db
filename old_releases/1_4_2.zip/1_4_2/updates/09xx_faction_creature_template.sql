-- Fix faction for creature 10076 ; author: Xfurry
UPDATE creature_template SET FactionAlliance=54, FactionHorde=54 WHERE entry=10076;
