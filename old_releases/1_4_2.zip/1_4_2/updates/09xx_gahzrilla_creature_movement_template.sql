-- Improved (fixed) NPC 7273 (Gahz'rilla) spawn script in Zul'Farrak
-- It will now spawn inside the pool and walk out of it instead of
-- spawning mid-air before falling into the pool and staying there
UPDATE `dbscripts_on_event` SET `x` = 1660.50, `y` = 1181.4, `z` = -2.0, `o` = 0.8 WHERE `id` = 2488 AND `delay` = 2;

DELETE FROM `creature_movement_template` WHERE `entry` = 7273;
INSERT INTO `creature_movement_template` VALUES
(7273, 1, 1660.50, 1181.4, -2.0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.8, 0, 0),
(7273, 2, 1700.66, 1225.78, 8.88, 10000, 727301, 0, 0, 0, 0, 0, 0, 0, 0.9, 0, 0);

DELETE FROM `dbscripts_on_creature_movement` WHERE `id` IN (7273, 727301);
INSERT INTO `dbscripts_on_creature_movement` VALUES
(727301, 0, 32, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'Gahz\'rilla - pause WP movement'),
(727301, 1, 20, 1, 15, 0, 0, 0x08, 0, 0, 0, 0, 0, 0, 0, 0, 'Gahz\'rilla - movement changed to 1:random');
