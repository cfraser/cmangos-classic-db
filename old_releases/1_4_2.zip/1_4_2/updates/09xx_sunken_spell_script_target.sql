-- Fixed spell target of spell 12623 (Suppression) in Shade of Hakkar event in Sunken Temple
UPDATE `spell_script_target` SET `targetEntry` = 8440 WHERE `entry` = 12623;

-- Also prevent caster (NPC 8497 Nightmare Suppressor) to move while casting
UPDATE `creature_template` SET `MovementType` = 0 WHERE `Entry` = 8497;
