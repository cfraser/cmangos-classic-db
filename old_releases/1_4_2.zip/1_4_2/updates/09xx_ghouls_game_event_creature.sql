-- Added day/night cycle to NPCs in the Moonbrook graveyard
-- NPCs 1109 (Fleshrippers) at day, NPCs 846 (Rotten Ghouls) at night
-- Source: http://www.wowhead.com/npc=846/rotten-ghoul#comments

DELETE FROM `game_event_creature` WHERE `guid` IN (90279, 52594, 52596, 90280, 52595);
INSERT INTO `game_event_creature` VALUES
(90279, -27),
(52594, -27),
(52596, -27),
(90280, -27),
(52595, -27);

SET @GUID := 160341;

DELETE FROM `creature` WHERE `guid` BETWEEN @GUID + 1 AND @GUID + 5;
INSERT INTO `creature` VALUES
(@GUID + 1,846,0,0,0,-10988.2,1600.1,45.6427,5.37523,300,5,0,332,0,0,1),
(@GUID + 2,846,0,0,0,-10958.9,1603.63,47.8132,1.78282,300,5,0,332,0,0,1),
(@GUID + 3,846,0,0,0,-10976.4,1610.5,46.0335,1.98,300,5,0,332,0,0,1),
(@GUID + 4,846,0,0,0,-10990.2,1623.08,45.1017,4.4604,300,5,0,332,0,0,1),
(@GUID + 5,846,0,0,0,-10962.3,1625.83,46.4382,3.24442,300,5,0,332,0,0,1);

DELETE FROM `game_event_creature` WHERE `guid` BETWEEN @GUID + 1 AND @GUID + 5;
INSERT INTO `game_event_creature` VALUES
(@GUID + 1, 27),
(@GUID + 2, 27),
(@GUID + 3, 27),
(@GUID + 4, 27),
(@GUID + 5, 27);
