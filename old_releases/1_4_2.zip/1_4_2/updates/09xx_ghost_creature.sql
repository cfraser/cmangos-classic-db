-- Removed spawn of NPC 10940 (Ghost of the Past) in Eastern Plaguelands
-- as this NPC is spawned by script
DELETE FROM `creature` WHERE `guid` = 92845;
DELETE FROM `creature_addon` WHERE `guid` = 92845;