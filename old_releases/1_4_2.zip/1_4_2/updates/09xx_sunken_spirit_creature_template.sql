-- Fixed unitflags of NPC 8317 (Atal'ai Deathwalker's Spirit) in Sunken Temple
-- The NPC should attack and be targetable
UPDATE `creature_template` SET `UnitFlags` = 64 WHERE `Entry` = 8317;
