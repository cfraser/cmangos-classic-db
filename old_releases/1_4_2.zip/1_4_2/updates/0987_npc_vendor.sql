
UPDATE `npc_vendor` SET `incrtime`='1800' WHERE `entry`='2480' and`item`='14634';
