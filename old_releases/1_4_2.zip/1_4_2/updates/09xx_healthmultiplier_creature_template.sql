UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 3; -- Flesh Eater
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 79; -- Narg the Taskmaster
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 92; -- Rock Elemental
UPDATE creature_template SET HealthMultiplier = 1.0 WHERE Entry = 125; -- Riverpaw Overseer
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 193; -- Blue Dragonspawn
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 202; -- Skeletal Horror
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 206; -- Nightbane Vile Fang
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 212; -- Splinter Fist Warrior
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 215; -- Defias Night Runner
UPDATE creature_template SET HealthMultiplier = 1.8 WHERE Entry = 228; -- Avette Fellwood
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 232; -- Farmer Ray
UPDATE creature_template SET HealthMultiplier = 1.8 WHERE Entry = 268; -- Sirra Von'Indi
UPDATE creature_template SET HealthMultiplier = 1.8 WHERE Entry = 313; -- Theocritus
UPDATE creature_template SET HealthMultiplier = 2.0 WHERE Entry = 328; -- Zaldimar Wefhellt
UPDATE creature_template SET HealthMultiplier = 1.26 WHERE Entry = 332; -- Master Mathias Shaw
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 334; -- Gath'Ilzogg
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 335; -- Singe
UPDATE creature_template SET HealthMultiplier = 2.0 WHERE Entry = 377; -- Priestess Josetta
UPDATE creature_template SET HealthMultiplier = 10.0 WHERE Entry = 412; -- Stitches
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 431; -- Shadowhide Slayer
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 432; -- Shadowhide Brute
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 435; -- Blackrock Champion
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 448; -- Hogger
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 456; -- Murloc Minor Oracle
UPDATE creature_template SET HealthMultiplier = 20.0 WHERE Entry = 469; -- Lieutenant Doren
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 503; -- Lord Malathrom
UPDATE creature_template SET HealthMultiplier = 1.8 WHERE Entry = 514; -- Smith Argus
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 521; -- Lupos
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 531; -- Skeletal Fiend
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 568; -- Shadowhide Warrior
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 574; -- Naraxis
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 579; -- Shadowhide Assassin
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 587; -- Bloodscalp Warrior
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 604; -- Plague Spreader
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 615; -- Blackrock Tracker
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 616; -- Chatter
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 622; -- Goblin Engineer
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 628; -- Black Ravager
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 634; -- Defias Overseer
UPDATE creature_template SET HealthMultiplier = 8.0 WHERE Entry = 642; -- Sneed's Shredder
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 643; -- Sneed
UPDATE creature_template SET HealthMultiplier = 10.0 WHERE Entry = 644; -- Rhahk'Zor
UPDATE creature_template SET HealthMultiplier = 6.0 WHERE Entry = 645; -- Cookie
UPDATE creature_template SET HealthMultiplier = 8.0 WHERE Entry = 646; -- Mr. Smite
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 660; -- Bloodscalp Witch Doctor
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 667; -- Skullsplitter Warrior
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 669; -- Skullsplitter Hunter
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 670; -- Skullsplitter Witch Doctor
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 672; -- Skullsplitter Spiritchaser
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 674; -- Venture Co. Strip Miner
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 675; -- Venture Co. Foreman
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 676; -- Venture Co. Surveyor
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 682; -- Stranglethorn Tiger
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 684; -- Shadowmaw Panther
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 685; -- Stranglethorn Raptor
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 686; -- Lashtail Raptor
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 687; -- Jungle Stalker
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 690; -- Cold Eye Basilisk
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 694; -- Bloodscalp Axe Thrower
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 696; -- Skullsplitter Axe Thrower
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 697; -- Bloodscalp Shaman
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 701; -- Bloodscalp Mystic
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 702; -- Bloodscalp Scavenger
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 736; -- Panther
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 741; -- Dreaming Whelp
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 750; -- Marsh Inkspewer
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 751; -- Marsh Flesheater
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 757; -- Lost One Fisherman
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 761; -- Lost One Seer
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 763; -- Lost One Chieftain
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 768; -- Shadow Panther
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 769; -- Deathstrike Tarantula
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 771; -- Commander Felstrom
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 772; -- Stranglethorn Tigress
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 775; -- Kurzen's Agent
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 780; -- Skullsplitter Mystic
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 781; -- Skullsplitter Headhunter
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 782; -- Skullsplitter Scout
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 783; -- Skullsplitter Berserker
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 784; -- Skullsplitter Beastmaster
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 822; -- Young Forest Bear
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 856; -- Young Lashtail Raptor
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 889; -- Splinter Fist Ogre
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 891; -- Splinter Fist Fire Weaver
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 892; -- Splinter Fist Taskmaster
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 909; -- Defias Night Blade
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 910; -- Defias Enchanter
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 920; -- Nightbane Tainted One
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 922; -- Silt Crawler
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 923; -- Young Black Ravager
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 930; -- Black Widow Hatchling
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 937; -- Kurzen Jungle Fighter
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 940; -- Kurzen Medicine Man
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 941; -- Kurzen Headshrinker
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 943; -- Kurzen Wrangler
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 948; -- Rotted One
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 949; -- Carrion Recluse
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 950; -- Swamp Talker
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 976; -- Kurzen War Tiger
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 977; -- Kurzen War Panther
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 1011; -- Mosshide Trapper
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 1012; -- Mosshide Brute
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 1014; -- Mosshide Alpha
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 1015; -- Highland Raptor
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 1016; -- Highland Lashtail
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 1017; -- Highland Scytheclaw
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 1018; -- Highland Razormaw
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 1019; -- Elder Razormaw
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 1021; -- Mottled Screecher
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 1022; -- Mottled Scytheclaw
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 1027; -- Bluegill Warrior
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 1028; -- Bluegill Muckdweller
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 1031; -- Crimson Ooze
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 1032; -- Black Ooze
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 1033; -- Monstrous Ooze
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 1040; -- Fen Creeper
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 1041; -- Fen Lord
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 1042; -- Red Whelp
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 1045; -- Red Dragonspawn
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 1046; -- Red Wyrmkin
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 1046; -- Red Wyrmkin
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 1047; -- Red Scalebane
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 1048; -- Scalebane Lieutenant
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 1049; -- Wyrmkin Firebrand
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 1049; -- Wyrmkin Firebrand
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 1050; -- Scalebane Royal Guard
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 1059; -- Ana'thek the Cruel
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 1060; -- Mogh the Undying
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 1060; -- Mogh the Undying
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 1062; -- Nezzliok the Dire
UPDATE creature_template SET HealthMultiplier = 1.5 WHERE Entry = 1081; -- Mire Lord
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 1082; -- Sawtooth Crocolisk
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 1084; -- Young Sawtooth Crocolisk
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 1087; -- Sawtooth Snapper
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 1106; -- Lost One Cook
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 1108; -- Mistvale Gorilla
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 1110; -- Skeletal Raider
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 1112; -- Leech Widow
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 1114; -- Jungle Thunderer
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 1129; -- Black Bear
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 1151; -- Saltwater Crocolisk
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 1152; -- Snapjaw Crocolisk
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 1159; -- First Mate Snellig
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 1160; -- Captain Halyndor
UPDATE creature_template SET HealthMultiplier = 1.0 WHERE Entry = 1172; -- Tunnel Rat Vermin
UPDATE creature_template SET HealthMultiplier = 4.5 WHERE Entry = 1200; -- Morbent Fel
UPDATE creature_template SET PowerMultiplier = 1.5 WHERE Entry = 1200; -- Morbent Fel
UPDATE creature_template SET HealthMultiplier = 1.0 WHERE Entry = 1202; -- Tunnel Rat Kobold
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 1210; -- Chok'sul
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 1258; -- Black Ravager Mastiff
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 1270; -- Fetid Corpse
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 1271; -- Old Icebeard
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 1353; -- Sarltooth
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 1399; -- Magosh
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 1400; -- Wetlands Crocolisk
UPDATE creature_template SET HealthMultiplier = 1.6 WHERE Entry = 1411; -- Ian Strom
UPDATE creature_template SET HealthMultiplier = 1.8 WHERE Entry = 1466; -- Gretta Finespindle
UPDATE creature_template SET HealthMultiplier = 1.6 WHERE Entry = 1475; -- Menethil Guard
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 1511; -- Enraged Silverback Gorilla
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 1514; -- Mokk the Savage
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 1516; -- Konda
UPDATE creature_template SET HealthMultiplier = 1.04 WHERE Entry = 1529; -- Bleeding Horror
UPDATE creature_template SET HealthMultiplier = 1.0 WHERE Entry = 1544; -- Vile Fin Minor Oracle
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 1550; -- Thrashtail Basilisk
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 1551; -- Ironjaw Basilisk
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 1552; -- Scale Belly
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 1557; -- Elder Mistvale Gorilla
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 1558; -- Silverback Patriarch
UPDATE creature_template SET HealthMultiplier = 1.8 WHERE Entry = 1652; -- Deathguard Burgess
UPDATE creature_template SET HealthMultiplier = 1.8 WHERE Entry = 1702; -- Bronk Guzzlegear
UPDATE creature_template SET HealthMultiplier = 1.8 WHERE Entry = 1703; -- Uthrar Threx
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 1706; -- Defias Prisoner
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 1713; -- Elder Shadowmaw Panther
UPDATE creature_template SET HealthMultiplier = 2.5 WHERE Entry = 1717; -- Hamhock
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 1731; -- Goblin Craftsman
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 1732; -- Defias Squallshaper
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 1732; -- Defias Squallshaper
UPDATE creature_template SET HealthMultiplier = 1.8 WHERE Entry = 1744; -- Deathguard Mort
UPDATE creature_template SET HealthMultiplier = 6.0 WHERE Entry = 1763; -- Gilnid
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 1783; -- Skeletal Flayer
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 1784; -- Skeletal Sorcerer
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 1785; -- Skeletal Terror
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 1789; -- Skeletal Acolyte
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 1791; -- Slavering Ghoul
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 1793; -- Rotting Ghoul
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 1794; -- Soulless Ghoul
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 1796; -- Freezing Ghoul
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 1802; -- Hungering Wraith
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 1804; -- Wailing Death
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 1805; -- Flesh Golem
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 1806; -- Vile Slime
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 1808; -- Devouring Ooze
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 1809; -- Carrion Vulture
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 1812; -- Rotting Behemoth
UPDATE creature_template SET HealthMultiplier = 1.5 WHERE Entry = 1815; -- Diseased Black Bear
UPDATE creature_template SET HealthMultiplier = 1.5 WHERE Entry = 1816; -- Diseased Grizzly
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 1817; -- Diseased Wolf
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 1821; -- Carrion Lurker
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 1822; -- Venom Mist Lurker
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 1824; -- Plague Lurker
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 1831; -- Scarlet Hunter
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 1833; -- Scarlet Knight
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 1835; -- Scarlet Invoker
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 1837; -- Scarlet Judge
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 1839; -- Scarlet High Clerist
UPDATE creature_template SET HealthMultiplier = 25.0 WHERE Entry = 1840; -- Grand Inquisitor Isillien
UPDATE creature_template SET PowerMultiplier = 8.0 WHERE Entry = 1840; -- Grand Inquisitor Isillien
UPDATE creature_template SET HealthMultiplier = 10.0 WHERE Entry = 1842; -- Highlord Taelan Fordring
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 1842; -- Highlord Taelan Fordring
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 1844; -- Foreman Marcrid
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 1845; -- High Protector Tarsen
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 1846; -- High Protector Lorik
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 1847; -- Foulmane
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 1848; -- Lord Maldazzar
UPDATE creature_template SET PowerMultiplier = 1.0 WHERE Entry = 1848; -- Lord Maldazzar
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 1850; -- Putridius
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 1851; -- The Husk
UPDATE creature_template SET HealthMultiplier = 3.3 WHERE Entry = 1852; -- Araj the Summoner
UPDATE creature_template SET PowerMultiplier = 3.0 WHERE Entry = 1852; -- Araj the Summoner
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 1883; -- Scarlet Worker
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 1884; -- Scarlet Lumberjack
UPDATE creature_template SET PowerMultiplier = 1.3 WHERE Entry = 1888; -- Dalaran Watcher
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 1891; -- Pyrewood Watcher
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 1892; -- Moonrage Watcher
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 1893; -- Moonrage Sentry
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 1894; -- Pyrewood Sentry
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 1895; -- Pyrewood Elder
UPDATE creature_template SET PowerMultiplier = 1.5 WHERE Entry = 1911; -- Deeb
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 1948; -- Snarlmane
UPDATE creature_template SET HealthMultiplier = 1.0 WHERE Entry = 1954; -- Elder Lake Skulker
UPDATE creature_template SET PowerMultiplier = 1.0 WHERE Entry = 1954; -- Elder Lake Skulker
UPDATE creature_template SET HealthMultiplier = 1.8 WHERE Entry = 2056; -- Ravenclaw Apparition
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 2058; -- Deathstalker Faerleia
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 2061; -- Councilman Thatcher
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 2062; -- Councilman Hendricks
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 2063; -- Councilman Wilhelm
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 2065; -- Councilman Cooper
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 2066; -- Councilman Higarth
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 2067; -- Councilman Brunswick
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 2068; -- Lord Mayor Morrison
UPDATE creature_template SET HealthMultiplier = 1.8 WHERE Entry = 2070; -- Moonstalker Runt
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 2089; -- Giant Wetlands Crocolisk
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 2106; -- Apothecary Berard
UPDATE creature_template SET HealthMultiplier = 2.0 WHERE Entry = 2130; -- Marion Call
UPDATE creature_template SET HealthMultiplier = 2.0 WHERE Entry = 2136; -- Oliver Dwor
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 2165; -- Grizzled Thistle Bear
UPDATE creature_template SET HealthMultiplier = 1.0 WHERE Entry = 2174; -- Coastal Frenzy
UPDATE creature_template SET HealthMultiplier = 1.0 WHERE Entry = 2178; -- Wailing Highborne
UPDATE creature_template SET HealthMultiplier = 1.8 WHERE Entry = 2209; -- Deathguard Gavin
UPDATE creature_template SET HealthMultiplier = 1.8 WHERE Entry = 2210; -- Deathguard Royann
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 2240; -- Syndicate Footpad
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 2242; -- Syndicate Spy
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 2245; -- Syndicate Saboteur
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 2246; -- Syndicate Assassin
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 2247; -- Syndicate Enforcer
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 2250; -- Mountain Yeti
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 2251; -- Giant Yeti
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 2258; -- Stone Fury
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 2264; -- Hillsbrad Tailor
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 2267; -- Hillsbrad Peasant
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 2268; -- Hillsbrad Footman
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 2270; -- Hillsbrad Sentry
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 2272; -- Dalaran Theurgist
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 2274; -- Stanley
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 2275; -- Enraged Stanley
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 2283; -- Ravenclaw Regent
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 2303; -- Lyranne Feathersong
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 2319; -- Syndicate Wizard
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 2349; -- Giant Moss Creeper
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 2358; -- Dalaran Summoner
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 2371; -- Daggerspine Siren
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 2384; -- Starving Mountain Lion
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 2385; -- Feral Mountain Lion
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 2387; -- Hillsbrad Councilman
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 2403; -- Farmer Getz
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 2406; -- Mountain Lion
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 2407; -- Hulking Mountain Lion
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 2411; -- Ricter
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 2412; -- Alina
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 2417; -- Grel'borg the Miser
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 2423; -- Lord Aliden Perenolde
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 2427; -- Jailor Eston
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 2428; -- Jailor Marlgen
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 2431; -- Jailor Borhuin
UPDATE creature_template SET HealthMultiplier = 8.5 WHERE Entry = 2447; -- Narillasanz
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 2447; -- Narillasanz
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 2449; -- Citizen Wilkes
UPDATE creature_template SET HealthMultiplier = 1.04 WHERE Entry = 2450; -- Miner Hackett
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 2451; -- Farmer Kalaba
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 2453; -- Lo'Grosh
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 2477; -- Gradok
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 2503; -- Hillsbrad Foreman
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 2505; -- Saltwater Snapjaw
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 2530; -- Yenniku
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 2534; -- Zanzil the Outcast
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 2535; -- Maury "Club Foot" Wilkins
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 2536; -- Jon-Jon the Crow
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 2537; -- Chucky "Ten Thumbs"
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 2544; -- Southern Sand Crawler
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 2549; -- Garr Salthoof
UPDATE creature_template SET HealthMultiplier = 1.6 WHERE Entry = 2551; -- Brutus
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 2553; -- Witherbark Shadowcaster
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 2554; -- Witherbark Axe Thrower
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 2555; -- Witherbark Witch Doctor
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 2557; -- Witherbark Shadow Hunter
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 2560; -- Highland Thrasher
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 2562; -- Boulderfist Ogre
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 2563; -- Plains Creeper
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 2564; -- Boulderfist Enforcer
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 2565; -- Giant Plains Creeper
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 2566; -- Boulderfist Brute
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 2567; -- Boulderfist Magus
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 2572; -- Drywhisker Kobold
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 2575; -- Dark Iron Supplier
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 2577; -- Dark Iron Shadowcaster
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 2580; -- Elder Mesa Buzzard
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 2587; -- Syndicate Pathstalker
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 2592; -- Rumbling Exile
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 2595; -- Daggerspine Raider
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 2596; -- Daggerspine Sorceress
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 2600; -- Singer
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 2604; -- Molok the Crusher
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 2605; -- Zalas Witherbark
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 2605; -- Zalas Witherbark
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 2606; -- Nimar the Slayer
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 2628; -- Dalaran Worker
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 2639; -- Vilebranch Axe Thrower
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 2640; -- Vilebranch Witch Doctor
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 2649; -- Witherbark Scalper
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 2650; -- Witherbark Zealot
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 2651; -- Witherbark Hideskinner
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 2652; -- Witherbark Venomblood
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 2653; -- Witherbark Sadist
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 2655; -- Green Sludge
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 2656; -- Jade Ooze
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 2657; -- Trained Razorbeak
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 2658; -- Razorbeak Gryphon
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 2659; -- Razorbeak Skylord
UPDATE creature_template SET HealthMultiplier = 0.01 WHERE Entry = 2667; -- Ward of Laze
UPDATE creature_template SET HealthMultiplier = 1.6 WHERE Entry = 2678; -- Mechanical Dragonling
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 2680; -- Vilebranch Wolf Pup
UPDATE creature_template SET HealthMultiplier = 1.8 WHERE Entry = 2682; -- Fradd Swiftgear
UPDATE creature_template SET HealthMultiplier = 1.8 WHERE Entry = 2683; -- Namdo Bizzfizzle
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 2686; -- Witherbark Broodguard
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 2701; -- Dustbelcher Ogre
UPDATE creature_template SET HealthMultiplier = 7.0 WHERE Entry = 2707; -- Shadra
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 2714; -- Forsaken Courier
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 2715; -- Dustbelcher Brute
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 2716; -- Dustbelcher Wyrmhunter
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 2717; -- Dustbelcher Mauler
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 2718; -- Dustbelcher Shaman
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 2719; -- Dustbelcher Lord
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 2720; -- Dustbelcher Ogre Mage
UPDATE creature_template SET HealthMultiplier = 0.5 WHERE Entry = 2721; -- Forsaken Bodyguard
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 2723; -- Stone Golem
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 2725; -- Scalding Whelp
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 2726; -- Scorched Guardian
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 2727; -- Crag Coyote
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 2728; -- Feral Crag Coyote
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 2730; -- Rabid Crag Coyote
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 2732; -- Ridge Huntress
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 2734; -- Ridge Stalker Patriarch
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 2735; -- Lesser Rock Elemental
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 2736; -- Greater Rock Elemental
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 2739; -- Shadowforge Tunneler
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 2740; -- Shadowforge Darkweaver
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 2743; -- Shadowforge Warrior
UPDATE creature_template SET HealthMultiplier = 3.5 WHERE Entry = 2749; -- Siege Golem
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 2752; -- Rumbler
UPDATE creature_template SET HealthMultiplier = 4.5 WHERE Entry = 2754; -- Anathemus
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 2757; -- Blacklash
UPDATE creature_template SET HealthMultiplier = 6.0 WHERE Entry = 2759; -- Hematus
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 2760; -- Burning Exile
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 2762; -- Thundering Exile
UPDATE creature_template SET PowerMultiplier = 1.25 WHERE Entry = 2762; -- Thundering Exile
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 2767; -- First Mate Nilzlix
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 2775; -- Daggerspine Marauder
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 2778; -- Deckhand Moishe
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 2779; -- Prince Nazjak
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 2791; -- Enraged Rock Elemental
UPDATE creature_template SET HealthMultiplier = 1.14 WHERE Entry = 2793; -- Kor'gresh Coldrage
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 2829; -- Starving Buzzard
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 2830; -- Buzzard
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 2831; -- Giant Buzzard
UPDATE creature_template SET HealthMultiplier = 0.09 WHERE Entry = 2848; -- Glyx Brewright
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 2850; -- Broken Tooth
UPDATE creature_template SET HealthMultiplier = 1.8 WHERE Entry = 2855; -- Snang
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 2893; -- Stonevault Bonesnapper
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 2894; -- Stonevault Shaman
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 2923; -- Mangy Silvermane
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 2924; -- Silvermane Wolf
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 2925; -- Silvermane Howler
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 2926; -- Silvermane Stalker
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 2927; -- Vicious Owlbeast
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 2928; -- Primitive Owlbeast
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 2931; -- Zaricotl
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 2937; -- Dagun the Ravenous
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 2944; -- Boss Tho'grun
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 2945; -- Murdaloc
UPDATE creature_template SET HealthMultiplier = 0.1 WHERE Entry = 2946; -- Puppet of Helcular
UPDATE creature_template SET HealthMultiplier = 1.0 WHERE Entry = 2956; -- Adult Plainstrider
UPDATE creature_template SET HealthMultiplier = 1.8 WHERE Entry = 3008; -- Mak
UPDATE creature_template SET HealthMultiplier = 2.0 WHERE Entry = 3058; -- Arra'chea
UPDATE creature_template SET HealthMultiplier = 2.0 WHERE Entry = 3066; -- Narm Skychaser
UPDATE creature_template SET HealthMultiplier = 2.0 WHERE Entry = 3078; -- Kennah Hawkseye
UPDATE creature_template SET HealthMultiplier = 1.8 WHERE Entry = 3135; -- Malissa
UPDATE creature_template SET HealthMultiplier = 2.0 WHERE Entry = 3165; -- Ghrawt
UPDATE creature_template SET PowerMultiplier = 1.2 WHERE Entry = 3183; -- Yarrog Baneshadow
UPDATE creature_template SET HealthMultiplier = 2.14 WHERE Entry = 3190; -- Rhinag
UPDATE creature_template SET HealthMultiplier = 2.0 WHERE Entry = 3209; -- Brave Windfeather
UPDATE creature_template SET HealthMultiplier = 2.0 WHERE Entry = 3217; -- Brave Dawneagle
UPDATE creature_template SET HealthMultiplier = 2.0 WHERE Entry = 3218; -- Brave Swiftwind
UPDATE creature_template SET HealthMultiplier = 2.0 WHERE Entry = 3219; -- Brave Leaping Deer
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 3253; -- Silithid Harvester
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 3270; -- Elder Mystic Razorsnout
UPDATE creature_template SET HealthMultiplier = 1.8 WHERE Entry = 3291; -- Greishan Ironstove
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 3376; -- Bael'dun Soldier
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 3377; -- Bael'dun Rifleman
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 3398; -- Gesharahan
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 3435; -- Lok Orcbane
UPDATE creature_template SET HealthMultiplier = 2.0 WHERE Entry = 3443; -- Grub
UPDATE creature_template SET HealthMultiplier = 1.8 WHERE Entry = 3447; -- Pawe Mistrunner
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 3459; -- Razormane Warfrenzy
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 3472; -- Washte Pawne
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 3473; -- Owatanka
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 3476; -- Isha Awak
UPDATE creature_template SET HealthMultiplier = 1.8 WHERE Entry = 3492; -- Vexspindle
UPDATE creature_template SET HealthMultiplier = 1.8 WHERE Entry = 3497; -- Kilxx
UPDATE creature_template SET HealthMultiplier = 1.6 WHERE Entry = 3510; -- Twain
UPDATE creature_template SET HealthMultiplier = 1.8 WHERE Entry = 3523; -- Bowen Brisboise
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 3528; -- Pyrewood Armorer
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 3529; -- Moonrage Armorer
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 3531; -- Moonrage Tailor
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 3532; -- Pyrewood Leatherworker
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 3586; -- Miner Johnson
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 3616; -- Onu
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 3636; -- Deviate Ravager
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 3637; -- Deviate Guardian
UPDATE creature_template SET HealthMultiplier = 1.5 WHERE Entry = 3664; -- Ilkrud Magthrull
UPDATE creature_template SET PowerMultiplier = 1.5 WHERE Entry = 3664; -- Ilkrud Magthrull
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 3669; -- Lord Cobrahn
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 3671; -- Lady Anacondra
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 3678; -- Disciple of Naralex
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 3696; -- Ran Bloodtooth
UPDATE creature_template SET HealthMultiplier = 1.0 WHERE Entry = 3728; -- Dark Strand Adept
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 3736; -- Darkslayer Mordenthal
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 3745; -- Foulweald Pathfinder
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 3746; -- Foulweald Den Watcher
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 3749; -- Foulweald Ursa
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 3752; -- Xavian Rogue
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 3758; -- Felmusk Satyr
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 3767; -- Bleakheart Trickster
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 3770; -- Bleakheart Shadowstalker
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 3782; -- Shadethicket Stone Mover
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 3783; -- Shadethicket Raincaller
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 3806; -- Forsaken Infiltrator
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 3807; -- Forsaken Assassin
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 3820; -- Wildthorn Venomspitter
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 3824; -- Ghostpaw Howler
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 3825; -- Ghostpaw Alpha
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 3834; -- Crazed Ancient
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 3840; -- Druid of the Fang
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 3840; -- Druid of the Fang
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 3850; -- Sorcerer Ashcrombe
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 3851; -- Shadowfang Whitescalp
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 3851; -- Shadowfang Whitescalp
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 3853; -- Shadowfang Moonwalker
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 3853; -- Shadowfang Moonwalker
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 3854; -- Shadowfang Wolfguard
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 3861; -- Bleak Worg
UPDATE creature_template SET HealthMultiplier = 2.0 WHERE Entry = 3884; -- Jhawna Oatwind
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 3893; -- Forsaken Scout
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 3898; -- Aligar the Tormentor
UPDATE creature_template SET HealthMultiplier = 0.01 WHERE Entry = 3902; -- Searing Totem II
UPDATE creature_template SET HealthMultiplier = 4.0 WHERE Entry = 3914; -- Rethilgore
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 3915; -- Dagri
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 3931; -- Shadethicket Oracle
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 3940; -- Taneel Darkwood
UPDATE creature_template SET HealthMultiplier = 1.06 WHERE Entry = 3942; -- Mavoris Cloudsbreak
UPDATE creature_template SET HealthMultiplier = 1.8 WHERE Entry = 3955; -- Shandrina
UPDATE creature_template SET HealthMultiplier = 1.8 WHERE Entry = 3956; -- Harklan Moongrove
UPDATE creature_template SET HealthMultiplier = 1.04 WHERE Entry = 3962; -- Haljan Oakheart
UPDATE creature_template SET HealthMultiplier = 1.8 WHERE Entry = 3965; -- Cylania Rootstalker
UPDATE creature_template SET HealthMultiplier = 8.0 WHERE Entry = 3974; -- Houndmaster Loksey
UPDATE creature_template SET HealthMultiplier = 6.0 WHERE Entry = 3983; -- Interrogator Vishas
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 3984; -- Nancy Vishas
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 3985; -- Grandpa Vishas
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 3987; -- Dal Bloodclaw
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 4003; -- Windshear Geomancer
UPDATE creature_template SET HealthMultiplier = 1.0 WHERE Entry = 4009; -- Raging Cliff Stormer
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 4013; -- Pridewing Skyhunter
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 4015; -- Pridewing Patriarch
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 4019; -- Great Courser
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 4021; -- Corrosive Sap Beast
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 4022; -- Bloodfury Harpy
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 4023; -- Bloodfury Roguefeather
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 4031; -- Fledgling Chimaera
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 4037; -- Burning Ravager
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 4041; -- Scorched Basilisk
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 4042; -- Singed Basilisk
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 4057; -- Son of Cenarius
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 4066; -- Nal'taszar
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 4067; -- Twilight Runner
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 4073; -- XT:4
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 4074; -- XT:9
UPDATE creature_template SET HealthMultiplier = 1.8 WHERE Entry = 4083; -- Jeeda
UPDATE creature_template SET HealthMultiplier = 1.8 WHERE Entry = 4084; -- Chylina
UPDATE creature_template SET HealthMultiplier = 1.8 WHERE Entry = 4085; -- Nizzik
UPDATE creature_template SET HealthMultiplier = 1.8 WHERE Entry = 4086; -- Veenix
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 4093; -- Galak Wrangler
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 4094; -- Galak Scout
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 4095; -- Galak Mauler
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 4101; -- Screeching Roguefeather
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 4104; -- Screeching Windcaller
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 4110; -- Highperch Patriarch
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 4112; -- Gravelsnout Vermin
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 4114; -- Gravelsnout Forager
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 4116; -- Gravelsnout Surveyor
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 4124; -- Needles Cougar
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 4126; -- Crag Stalker
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 4130; -- Silithid Searcher
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 4133; -- Silithid Hive Drone
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 4139; -- Scorpid Terror
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 4144; -- Sparkleshell Borer
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 4151; -- Saltstone Crystalhide
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 4158; -- Salt Flats Vulture
UPDATE creature_template SET HealthMultiplier = 2.0 WHERE Entry = 4190; -- Kyndri
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 4202; -- Gerenzo Wrenchwhistle
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 4243; -- Nightshade
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 4250; -- Galak Packhound
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 4260; -- Venture Co. Shredder
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 4286; -- Scarlet Soldier
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 4287; -- Scarlet Gallant
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 4287; -- Scarlet Gallant
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 4288; -- Scarlet Beastmaster
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 4291; -- Scarlet Diviner
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 4291; -- Scarlet Diviner
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 4293; -- Scarlet Scryer
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 4293; -- Scarlet Scryer
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 4294; -- Scarlet Sorcerer
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 4294; -- Scarlet Sorcerer
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 4296; -- Scarlet Adept
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 4296; -- Scarlet Adept
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 4297; -- Scarlet Conjuror
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 4297; -- Scarlet Conjuror
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 4299; -- Scarlet Chaplain
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 4299; -- Scarlet Chaplain
UPDATE creature_template SET HealthMultiplier = 3.5 WHERE Entry = 4300; -- Scarlet Wizard
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 4300; -- Scarlet Wizard
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 4301; -- Scarlet Centurion
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 4302; -- Scarlet Champion
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 4302; -- Scarlet Champion
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 4303; -- Scarlet Abbot
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 4303; -- Scarlet Abbot
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 4304; -- Scarlet Tracking Hound
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 4306; -- Scarlet Torturer
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 4341; -- Drywallow Crocolisk
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 4343; -- Drywallow Snapper
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 4344; -- Mottled Drywallow Crocolisk
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 4346; -- Noxious Flayer
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 4347; -- Noxious Reaver
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 4348; -- Noxious Shredder
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 4355; -- Bloodfen Scytheclaw
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 4358; -- Mirefin Puddlejumper
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 4360; -- Mirefin Warrior
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 4364; -- Strashaz Warrior
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 4366; -- Strashaz Serpent Guard
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 4368; -- Strashaz Myrmidon
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 4370; -- Strashaz Sorceress
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 4370; -- Strashaz Sorceress
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 4371; -- Strashaz Siren
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 4371; -- Strashaz Siren
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 4374; -- Strashaz Hydra
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 4387; -- Withervine Mire Beast
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 4391; -- Swamp Ooze
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 4392; -- Corrosive Swamp Ooze
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 4393; -- Acidic Swamp Ooze
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 4397; -- Mudrock Spikeshell
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 4398; -- Mudrock Burrower
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 4399; -- Mudrock Borer
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 4402; -- Muckshell Snapclaw
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 4405; -- Muckshell Razorclaw
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 4413; -- Darkfang Spider
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 4415; -- Giant Darkfang Spider
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 4435; -- Razorfen Warrior
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 4436; -- Razorfen Quilguard
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 4437; -- Razorfen Warden
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 4457; -- Murkgill Forager
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 4458; -- Murkgill Hunter
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 4461; -- Murkgill Warrior
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 4466; -- Vilebranch Scalper
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 4467; -- Vilebranch Soothsayer
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 4472; -- Haunting Vision
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 4474; -- Rotting Cadaver
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 4475; -- Blighted Zombie
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 4479; -- Fardel Dabyrie
UPDATE creature_template SET HealthMultiplier = 2.0 WHERE Entry = 4485; -- Belgrom Rockmaul
UPDATE creature_template SET HealthMultiplier = 2.0 WHERE Entry = 4489; -- Braug Dimspirit
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 4493; -- Scarlet Avenger
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 4494; -- Scarlet Spellbinder
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 4504; -- Frostmaw
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 4511; -- Agam'ar
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 4514; -- Raging Agam'ar
UPDATE creature_template SET HealthMultiplier = 2.5 WHERE Entry = 4515; -- Death's Head Acolyte
UPDATE creature_template SET HealthMultiplier = 2.5 WHERE Entry = 4519; -- Death's Head Seer
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 4520; -- Razorfen Geomancer
UPDATE creature_template SET HealthMultiplier = 2.5 WHERE Entry = 4522; -- Razorfen Dustweaver
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 4530; -- Razorfen Handler
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 4542; -- High Inquisitor Fairbanks
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 4542; -- High Inquisitor Fairbanks
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 4546; -- Bor'zehn
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 4619; -- Geltharis
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 4638; -- Magram Scout
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 4639; -- Magram Outrunner
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 4640; -- Magram Wrangler
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 4641; -- Magram Windchaser
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 4642; -- Magram Stormer
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 4644; -- Magram Marauder
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 4645; -- Magram Mauler
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 4646; -- Gelkis Outrunner
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 4647; -- Gelkis Scout
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 4648; -- Gelkis Stamper
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 4649; -- Gelkis Windchaser
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 4651; -- Gelkis Earthcaller
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 4652; -- Gelkis Mauler
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 4653; -- Gelkis Marauder
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 4654; -- Maraudine Scout
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 4657; -- Maraudine Windchaser
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 4658; -- Maraudine Stormer
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 4659; -- Maraudine Marauder
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 4660; -- Maraudine Bonepaw
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 4662; -- Magram Bonepaw
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 4665; -- Burning Blade Adept
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 4667; -- Burning Blade Shadowmage
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 4673; -- Hatefury Betrayer
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 4674; -- Hatefury Shadowstalker
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 4675; -- Hatefury Hellcaller
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 4677; -- Doomwarder
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 4678; -- Mana Eater
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 4679; -- Nether Maiden
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 4680; -- Doomwarder Captain
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 4681; -- Mage Hunter
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 4682; -- Nether Sister
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 4684; -- Nether Sorceress
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 4686; -- Deepstrider Giant
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 4687; -- Deepstrider Searcher
UPDATE creature_template SET HealthMultiplier = 0.4 WHERE Entry = 4688; -- Bonepaw Hyena
UPDATE creature_template SET HealthMultiplier = 0.4 WHERE Entry = 4690; -- Rabid Bonepaw
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 4692; -- Dread Swoop
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 4694; -- Dread Ripper
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 4695; -- Carrion Horror
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 4699; -- Scorpashi Venomlash
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 4705; -- Burning Blade Invoker
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 4711; -- Slitherblade Naga
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 4712; -- Slitherblade Sorceress
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 4713; -- Slitherblade Warrior
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 4715; -- Slitherblade Razortail
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 4718; -- Slitherblade Oracle
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 4719; -- Slitherblade Sea Witch
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 4723; -- Foreman Cozzle
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 4729; -- Hulking Gritjaw Basilisk
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 4784; -- Argent Guard Manados
UPDATE creature_template SET HealthMultiplier = 4.5 WHERE Entry = 4807; -- Blackfathom Myrmidon
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 4815; -- Murkshallow Snapclaw
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 4818; -- Blindlight Murloc
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 4821; -- Skittering Crustacean
UPDATE creature_template SET PowerMultiplier = 1.04 WHERE Entry = 4852; -- Stonevault Oracle
UPDATE creature_template SET HealthMultiplier = 2.0 WHERE Entry = 4980; -- Paval Reethe
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 5046; -- Lieutenant Caldwell
UPDATE creature_template SET HealthMultiplier = 0.4 WHERE Entry = 5047; -- Ellaercia
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 5048; -- Deviate Adder
UPDATE creature_template SET HealthMultiplier = 3.15 WHERE Entry = 5185; -- Hammerhead Shark
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 5226; -- Murk Worm
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 5228; -- Saturated Ooze
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 5229; -- Gordunni Ogre
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 5232; -- Gordunni Brute
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 5234; -- Gordunni Mauler
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 5236; -- Gordunni Shaman
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5238; -- Gordunni Battlemaster
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 5240; -- Gordunni Warlock
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5241; -- Gordunni Warlord
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5244; -- Zukk'ash Stinger
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 5245; -- Zukk'ash Wasp
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 5246; -- Zukk'ash Worker
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5247; -- Zukk'ash Tunneler
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 5249; -- Woodpaw Mongrel
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 5251; -- Woodpaw Trapper
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 5253; -- Woodpaw Brute
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 5254; -- Woodpaw Mystic
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 5255; -- Woodpaw Reaver
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 5256; -- Atal'ai Warrior
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 5258; -- Woodpaw Alpha
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 5260; -- Groddoc Ape
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5262; -- Groddoc Thunderer
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 5268; -- Ironfur Bear
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 5272; -- Grizzled Ironfur Bear
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5274; -- Ironfur Patriarch
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5276; -- Sprite Dragon
UPDATE creature_template SET PowerMultiplier = 1.0 WHERE Entry = 5276; -- Sprite Dragon
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 5277; -- Nightmare Scalebane
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 5278; -- Sprite Darter
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 5286; -- Longtooth Runner
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 5287; -- Longtooth Howler
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5288; -- Rabid Longtooth
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 5292; -- Feral Scar Yeti
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 5293; -- Hulking Feral Scar
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5296; -- Rage Scar Yeti
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5299; -- Ferocious Rage Scar
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 5300; -- Frayfeather Hippogryph
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 5304; -- Frayfeather Stagwing
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5305; -- Frayfeather Skystormer
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5306; -- Frayfeather Patriarch
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 5307; -- Vale Screecher
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5308; -- Rogue Vale Screecher
UPDATE creature_template SET HealthMultiplier = 25.0 WHERE Entry = 5312; -- Lethlas
UPDATE creature_template SET HealthMultiplier = 25.0 WHERE Entry = 5314; -- Phantim
UPDATE creature_template SET HealthMultiplier = 25.0 WHERE Entry = 5317; -- Jademir Oracle
UPDATE creature_template SET PowerMultiplier = 10.0 WHERE Entry = 5317; -- Jademir Oracle
UPDATE creature_template SET HealthMultiplier = 25.0 WHERE Entry = 5319; -- Jademir Tree Warder
UPDATE creature_template SET HealthMultiplier = 25.0 WHERE Entry = 5320; -- Jademir Boughguard
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 5331; -- Hatecrest Warrior
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 5332; -- Hatecrest Wave Rider
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 5333; -- Hatecrest Serpent Guard
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 5334; -- Hatecrest Myrmidon
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 5335; -- Hatecrest Screamer
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 5336; -- Hatecrest Sorceress
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 5337; -- Hatecrest Siren
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5343; -- Lady Szallah
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5349; -- Arash-ethis
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5350; -- Qirot
UPDATE creature_template SET HealthMultiplier = 1.5 WHERE Entry = 5352; -- Old Grizzlegut
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 5356; -- Snarler
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 5357; -- Land Walker
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 5358; -- Cliff Giant
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 5359; -- Shore Strider
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 5360; -- Deep Strider
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 5361; -- Wave Strider
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5362; -- Northspring Harpy
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5363; -- Northspring Roguefeather
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 5401; -- Kazkaz the Unholy
UPDATE creature_template SET HealthMultiplier = 1.8 WHERE Entry = 5409; -- Harvester Swarm
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 5419; -- Glasshide Basilisk
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5420; -- Glasshide Gazer
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5421; -- Glasshide Petrifier
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 5422; -- Scorpid Hunter
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 5423; -- Scorpid Tail Lasher
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5424; -- Scorpid Dunestalker
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 5425; -- Starving Blisterpaw
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 5426; -- Blisterpaw Hyena
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5427; -- Rabid Blisterpaw
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 5428; -- Roc
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 5429; -- Fire Roc
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5431; -- Surf Glider
UPDATE creature_template SET HealthMultiplier = 3.25 WHERE Entry = 5432; -- Giant Surf Glider
UPDATE creature_template SET HealthMultiplier = 3.01 WHERE Entry = 5435; -- Sand Shark
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5441; -- Hazzali Wasp
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5450; -- Hazzali Stinger
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5451; -- Hazzali Swarmer
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5452; -- Hazzali Worker
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5453; -- Hazzali Tunneler
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5455; -- Centipaar Wasp
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5456; -- Centipaar Stinger
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5457; -- Centipaar Swarmer
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5458; -- Centipaar Worker
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5459; -- Centipaar Tunneler
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5460; -- Centipaar Sandreaver
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5461; -- Sea Elemental
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5462; -- Sea Spray
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5465; -- Land Rager
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 5466; -- Coast Strider
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 5469; -- Dune Smasher
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 5470; -- Raging Dune Smasher
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5471; -- Dunemaul Ogre
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5472; -- Dunemaul Enforcer
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5473; -- Dunemaul Ogre Mage
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 5473; -- Dunemaul Ogre Mage
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5475; -- Dunemaul Warlock
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 5475; -- Dunemaul Warlock
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 5477; -- Noboru the Cudgel
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5490; -- Gnarled Thistleshrub
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 5598; -- Atal'ai Exile
UPDATE creature_template SET HealthMultiplier = 2.0 WHERE Entry = 5611; -- Barkeep Morag
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 5648; -- Sandfury Shadowcaster
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 5648; -- Sandfury Shadowcaster
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 5649; -- Sandfury Blood Drinker
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 5650; -- Sandfury Witch Doctor
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 5650; -- Sandfury Witch Doctor
UPDATE creature_template SET HealthMultiplier = 1.01 WHERE Entry = 5676; -- Summoned Voidwalker
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 5683; -- Comar Villard
UPDATE creature_template SET HealthMultiplier = 1.8 WHERE Entry = 5694; -- High Sorcerer Andromath
UPDATE creature_template SET HealthMultiplier = 25.0 WHERE Entry = 5718; -- Rothos
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 5760; -- Lord Azrethoc
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 5761; -- Deviate Shambler
UPDATE creature_template SET PowerMultiplier = 1.0 WHERE Entry = 5761; -- Deviate Shambler
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 5771; -- Jugkar Grim'rod
UPDATE creature_template SET HealthMultiplier = 0.1 WHERE Entry = 5781; -- Silithid Creeper Egg
UPDATE creature_template SET HealthMultiplier = 2.0 WHERE Entry = 5785; -- Sister Hatelash
UPDATE creature_template SET HealthMultiplier = 1.5 WHERE Entry = 5787; -- Enforcer Emilgund
UPDATE creature_template SET HealthMultiplier = 2.25 WHERE Entry = 5797; -- Aean Swiftriver
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 5822; -- Felweaver Scornn
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 5824; -- Captain Flat Tusk
UPDATE creature_template SET HealthMultiplier = 4.0 WHERE Entry = 5827; -- Brontus
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 5828; -- Humar the Pridelord
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 5830; -- Sister Rathtalon
UPDATE creature_template SET PowerMultiplier = 3.0 WHERE Entry = 5830; -- Sister Rathtalon
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 5831; -- Swiftmane
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 5834; -- Azzere the Skyblade
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 5839; -- Dark Iron Geologist
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5840; -- Dark Iron Steamsmith
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5844; -- Dark Iron Slaver
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5846; -- Dark Iron Taskmaster
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 5848; -- Malgin Barleybrew
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 5849; -- Digger Flameforge
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5850; -- Blazing Elemental
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 5851; -- Captain Gerogg Hammertoe
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5852; -- Inferno Elemental
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5854; -- Heavy War Golem
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5855; -- Magma Elemental
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5857; -- Searing Lava Spider
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5858; -- Greater Lava Spider
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 5859; -- Hagg Taurenbane
UPDATE creature_template SET HealthMultiplier = 1.0 WHERE Entry = 5897; -- Corrupt Water Spirit
UPDATE creature_template SET HealthMultiplier = 1.0 WHERE Entry = 5914; -- Deviate Nightmare
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 5915; -- Brother Ravenoak
UPDATE creature_template SET PowerMultiplier = 1.0 WHERE Entry = 5915; -- Brother Ravenoak
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 5928; -- Sorrow Wing
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 5930; -- Sister Riven
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 5930; -- Sister Riven
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 5931; -- Foreman Rigger
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 5933; -- Achellios the Banished
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 5934; -- Heartrazor
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 5935; -- Ironeye the Invincible
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 5937; -- Vile Sting
UPDATE creature_template SET HealthMultiplier = 2.0 WHERE Entry = 5939; -- Vira Younghoof
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5976; -- Dreadmaul Brute
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 5977; -- Dreadmaul Mauler
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 5978; -- Dreadmaul Warlock
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 5983; -- Bonepicker
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5984; -- Starving Snickerfang
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5985; -- Snickerfang Hyena
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 5991; -- Redstone Crystalhide
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 5992; -- Ashmane Boar
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 5993; -- Helboar
UPDATE creature_template SET PowerMultiplier = 1.0 WHERE Entry = 6000; -- Nethergarde Cleric
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6004; -- Shadowsworn Cultist
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6005; -- Shadowsworn Thug
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6006; -- Shadowsworn Adept
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6007; -- Shadowsworn Enforcer
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6008; -- Shadowsworn Warlock
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6009; -- Shadowsworn Dreadweaver
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6011; -- Felguard Sentry
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 6013; -- Wayward Buzzard
UPDATE creature_template SET HealthMultiplier = 0.01 WHERE Entry = 6066; -- Earthgrab Totem
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 6069; -- Maraudine Khan Guard
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 6070; -- Maraudine Khan Advisor
UPDATE creature_template SET HealthMultiplier = 0.4 WHERE Entry = 6071; -- Legion Hound
UPDATE creature_template SET HealthMultiplier = 1.01 WHERE Entry = 6072; -- Diathorus the Seeker
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 6073; -- Searing Infernal
UPDATE creature_template SET HealthMultiplier = 275.0 WHERE Entry = 6109; -- Azuregos
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 6115; -- Roaming Felguard
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6117; -- Highborne Lichling
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 6118; -- Varo'then's Ghost
UPDATE creature_template SET HealthMultiplier = 2.32 WHERE Entry = 6119; -- Tog Rustsprocket
UPDATE creature_template SET HealthMultiplier = 2.32 WHERE Entry = 6121; -- Remen Marcot
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 6125; -- Haldarr Satyr
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 6126; -- Haldarr Trickster
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 6129; -- Draconic Magelord
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 6129; -- Draconic Magelord
UPDATE creature_template SET HealthMultiplier = 3.15 WHERE Entry = 6130; -- Blue Scalebane
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 6131; -- Draconic Mageweaver
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 6131; -- Draconic Mageweaver
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6135; -- Arkkoran Clacker
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6136; -- Arkkoran Muckdweller
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6137; -- Arkkoran Pincer
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6138; -- Arkkoran Oracle
UPDATE creature_template SET HealthMultiplier = 3.25 WHERE Entry = 6143; -- Servant of Arkkoroc
UPDATE creature_template SET HealthMultiplier = 3.25 WHERE Entry = 6144; -- Son of Arkkoroc
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 6146; -- Cliff Breaker
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 6147; -- Cliff Thunderer
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 6148; -- Cliff Walker
UPDATE creature_template SET HealthMultiplier = 1.8 WHERE Entry = 6166; -- Yorus Barleybrew
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 6170; -- Gutspill
UPDATE creature_template SET HealthMultiplier = 0.85 WHERE Entry = 6180; -- Defias Raider
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 6186; -- Timbermaw Totemic
UPDATE creature_template SET HealthMultiplier = 1.6 WHERE Entry = 6187; -- Timbermaw Den Watcher
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 6193; -- Spitelash Screamer
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 6194; -- Spitelash Serpent Guard
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6196; -- Spitelash Myrmidon
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6200; -- Legashi Satyr
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6201; -- Legashi Rogue
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6202; -- Legashi Hellcaller
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 6239; -- Cyclonian
UPDATE creature_template SET HealthMultiplier = 1.0 WHERE Entry = 6250; -- Crawler
UPDATE creature_template SET HealthMultiplier = 2.0 WHERE Entry = 6289; -- Rand Rhobart
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6347; -- Young Wavethrasher
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6348; -- Wavethrasher
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6349; -- Great Wavethrasher
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6350; -- Makrinni Razorclaw
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6369; -- Coralshell Tortoise
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6370; -- Makrinni Scrabbler
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6372; -- Makrinni Snapclaw
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 6375; -- Thunderhead Hippogryph
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 6377; -- Thunderhead Stagwing
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6378; -- Thunderhead Skystormer
UPDATE creature_template SET PowerMultiplier = 1.0 WHERE Entry = 6378; -- Thunderhead Skystormer
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6379; -- Thunderhead Patriarch
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6380; -- Thunderhead Consort
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 6426; -- Anguished Dead
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 6498; -- Devilsaur
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 6499; -- Ironhide Devilsaur
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 6500; -- Tyrant Devilsaur
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 6501; -- Stegodon
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 6502; -- Plated Stegodon
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 6503; -- Spiked Stegodon
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6505; -- Ravasaur
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6506; -- Ravasaur Runner
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6507; -- Ravasaur Hunter
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6508; -- Venomhide Ravasaur
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6509; -- Bloodpetal Lasher
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6510; -- Bloodpetal Flayer
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6511; -- Bloodpetal Thresher
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6512; -- Bloodpetal Trapper
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6513; -- Un'Goro Stomper
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6514; -- Un'Goro Gorilla
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6516; -- Un'Goro Thunderer
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6520; -- Scorching Elemental
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6521; -- Living Blaze
UPDATE creature_template SET HealthMultiplier = 1.8 WHERE Entry = 6546; -- Tabetha
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 6549; -- Demon of the Orb
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6551; -- Gorishi Wasp
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6552; -- Gorishi Worker
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6553; -- Gorishi Reaver
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6554; -- Gorishi Stinger
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6555; -- Gorishi Tunneler
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 6556; -- Muculent Ooze
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6557; -- Primal Ooze
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6559; -- Glutinous Ooze
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 6560; -- Stone Guardian
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6581; -- Ravasaur Matriarch
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6582; -- Clutchmother Zavas
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 6583; -- Gruff
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6585; -- Uhk'loc
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 6649; -- Lady Sesspira
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 6668; -- Lord Cyrik Blackforge
UPDATE creature_template SET HealthMultiplier = 1.04 WHERE Entry = 6738; -- Innkeeper Kimlya
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 6766; -- Ravenholdt Guard
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 6768; -- Lord Jorach Ravenholdt
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 6771; -- Ravenholdt Assassin
UPDATE creature_template SET HealthMultiplier = 1.0 WHERE Entry = 6911; -- Minion of Sethir
UPDATE creature_template SET HealthMultiplier = 2.0 WHERE Entry = 6912; -- Remains of a Paladin
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 7009; -- Arantir
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 7025; -- Blackrock Soldier
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 7026; -- Blackrock Sorcerer
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 7027; -- Blackrock Slayer
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 7028; -- Blackrock Warlock
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 7029; -- Blackrock Battlemaster
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 7031; -- Obsidian Elemental
UPDATE creature_template SET HealthMultiplier = 1.5 WHERE Entry = 7033; -- Firegut Ogre
UPDATE creature_template SET HealthMultiplier = 1.5 WHERE Entry = 7034; -- Firegut Ogre Mage
UPDATE creature_template SET HealthMultiplier = 1.5 WHERE Entry = 7035; -- Firegut Brute
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 7039; -- War Reaver
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 7047; -- Black Broodling
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 7048; -- Scalding Broodling
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 7049; -- Flamescale Broodling
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 7052; -- Defias Tower Patroller
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 7055; -- Blackrock Worg
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 7056; -- Defias Tower Sentry
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 7057; -- Digmaster Shovelphlange
UPDATE creature_template SET HealthMultiplier = 3.3 WHERE Entry = 7068; -- Condemned Acolyte
UPDATE creature_template SET PowerMultiplier = 3.0 WHERE Entry = 7068; -- Condemned Acolyte
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 7069; -- Condemned Monk
UPDATE creature_template SET PowerMultiplier = 3.0 WHERE Entry = 7070; -- Condemned Cleric
UPDATE creature_template SET HealthMultiplier = 3.3 WHERE Entry = 7071; -- Cursed Paladin
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 7071; -- Cursed Paladin
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 7075; -- Writhing Mage
UPDATE creature_template SET PowerMultiplier = 3.0 WHERE Entry = 7075; -- Writhing Mage
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 7092; -- Tainted Ooze
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 7093; -- Vile Ooze
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 7097; -- Ironbeak Owl
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 7098; -- Ironbeak Screecher
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 7099; -- Ironbeak Hunter
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 7100; -- Warpwood Moss Flayer
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 7101; -- Warpwood Shredder
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 7104; -- Dessecus
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 7105; -- Jadefire Satyr
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 7106; -- Jadefire Rogue
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 7107; -- Jadefire Trickster
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 7108; -- Jadefire Betrayer
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 7109; -- Jadefire Felsworn
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 7110; -- Jadefire Shadowstalker
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 7111; -- Jadefire Hellcaller
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 7112; -- Jaedenar Cultist
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 7113; -- Jaedenar Guardian
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 7114; -- Jaedenar Enforcer
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 7115; -- Jaedenar Adept
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 7118; -- Jaedenar Darkweaver
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 7120; -- Jaedenar Warlock
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 7125; -- Jaedenar Hound
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 7126; -- Jaedenar Hunter
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 7138; -- Irontree Wanderer
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 7139; -- Irontree Stomper
UPDATE creature_template SET HealthMultiplier = 1.6 WHERE Entry = 7149; -- Withered Protector
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 7153; -- Deadwood Warrior
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 7154; -- Deadwood Gardener
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 7155; -- Deadwood Pathfinder
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 7156; -- Deadwood Den Watcher
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 7157; -- Deadwood Avenger
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 7158; -- Deadwood Shaman
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 7268; -- Sandfury Guardian
UPDATE creature_template SET HealthMultiplier = 1.0 WHERE Entry = 7269; -- Scarab
UPDATE creature_template SET HealthMultiplier = 7.0 WHERE Entry = 7271; -- Witch Doctor Zum'rah
UPDATE creature_template SET PowerMultiplier = 4.0 WHERE Entry = 7271; -- Witch Doctor Zum'rah
UPDATE creature_template SET HealthMultiplier = 10.0 WHERE Entry = 7273; -- Gahz'rilla
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 7274; -- Sandfury Executioner
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 7288; -- Grand Foreman Puzik Gallywix
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 7307; -- Venture Co. Lookout
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 7335; -- Death's Head Geomancer
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 7335; -- Death's Head Geomancer
UPDATE creature_template SET HealthMultiplier = 0.25 WHERE Entry = 7343; -- Splinterbone Skeleton
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 7344; -- Splinterbone Warrior
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 7349; -- Tomb Fiend
UPDATE creature_template SET HealthMultiplier = 1.06 WHERE Entry = 7360; -- Dun Garok Soldier
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 7369; -- Deadwind Brute
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 7371; -- Deadwind Mauler
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 7372; -- Deadwind Warlock
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 7376; -- Sky Shadow
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 7429; -- Frostmaul Preserver
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 7430; -- Frostsaber Cub
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 7431; -- Frostsaber
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 7432; -- Frostsaber Stalker
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 7433; -- Frostsaber Huntress
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 7434; -- Frostsaber Pride Watcher
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 7435; -- Cobalt Wyrmkin
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 7436; -- Cobalt Scalebane
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 7437; -- Cobalt Mageweaver
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 7438; -- Winterfall Ursa
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 7439; -- Winterfall Shaman
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 7440; -- Winterfall Den Watcher
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 7441; -- Winterfall Totemic
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 7442; -- Winterfall Pathfinder
UPDATE creature_template SET HealthMultiplier = 1.5 WHERE Entry = 7444; -- Shardtooth Bear
UPDATE creature_template SET HealthMultiplier = 1.6 WHERE Entry = 7445; -- Elder Shardtooth
UPDATE creature_template SET HealthMultiplier = 1.6 WHERE Entry = 7446; -- Rabid Shardtooth
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 7447; -- Fledgling Chillwind
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 7448; -- Chillwind Chimaera
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 7449; -- Chillwind Ravager
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 7450; -- Ragged Owlbeast
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 7451; -- Raging Owlbeast
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 7452; -- Crazed Owlbeast
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 7453; -- Moontouched Owlbeast
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 7454; -- Berserk Owlbeast
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 7456; -- Winterspring Screecher
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 7457; -- Rogue Ice Thistle
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 7458; -- Ice Thistle Yeti
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 7459; -- Ice Thistle Matriarch
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 7460; -- Ice Thistle Patriarch
UPDATE creature_template SET HealthMultiplier = 1.7 WHERE Entry = 7584; -- Wandering Forest Walker
UPDATE creature_template SET HealthMultiplier = 10.0 WHERE Entry = 7604; -- Sergeant Bly
UPDATE creature_template SET HealthMultiplier = 3.5 WHERE Entry = 7605; -- Raven
UPDATE creature_template SET HealthMultiplier = 3.5 WHERE Entry = 7608; -- Murta Grimgut
UPDATE creature_template SET HealthMultiplier = 10.0 WHERE Entry = 7664; -- Razelikh the Defiler
UPDATE creature_template SET HealthMultiplier = 8.0 WHERE Entry = 7665; -- Grol the Destroyer
UPDATE creature_template SET HealthMultiplier = 6.0 WHERE Entry = 7666; -- Archmage Allistarj
UPDATE creature_template SET PowerMultiplier = 20.0 WHERE Entry = 7666; -- Archmage Allistarj
UPDATE creature_template SET HealthMultiplier = 9.0 WHERE Entry = 7667; -- Lady Sevine
UPDATE creature_template SET PowerMultiplier = 12.0 WHERE Entry = 7667; -- Lady Sevine
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 7668; -- Servant of Razelikh
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 7669; -- Servant of Grol
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 7670; -- Servant of Allistarj
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 7671; -- Servant of Sevine
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 7725; -- Grimtotem Raider
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 7727; -- Grimtotem Shaman
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 7774; -- Shay Leafrunner
UPDATE creature_template SET HealthMultiplier = 0.75 WHERE Entry = 7787; -- Sandfury Slave
UPDATE creature_template SET HealthMultiplier = 2.1 WHERE Entry = 7789; -- Sandfury Cretin
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 7795; -- Hydromancer Velratha
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 7795; -- Hydromancer Velratha
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 7796; -- Nekrum Gutchewer
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 7803; -- Scorpid Duneburrower
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 7808; -- Marauding Owlbeast
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 7809; -- Vilebranch Ambusher
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 7847; -- Caliph Scorpidsting
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 7848; -- Lurking Feral Scar
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 7855; -- Southsea Pirate
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 7856; -- Southsea Freebooter
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 7857; -- Southsea Dock Worker
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 7858; -- Southsea Swashbuckler
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 7868; -- Sarah Tanner
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 7883; -- Andre Firebeard
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 7885; -- Spitelash Battlemaster
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 7886; -- Spitelash Enchantress
UPDATE creature_template SET HealthMultiplier = 1.9 WHERE Entry = 7942; -- Faralorn
UPDATE creature_template SET HealthMultiplier = 1.8 WHERE Entry = 8121; -- Jaxxil Sparks
UPDATE creature_template SET HealthMultiplier = 1.8 WHERE Entry = 8122; -- Kizzak Sparks
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 8136; -- Lord Shalzaru
UPDATE creature_template SET HealthMultiplier = 2.4 WHERE Entry = 8149; -- Sul'lithuz Warder
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 8196; -- Occulus
UPDATE creature_template SET HealthMultiplier = 12.0 WHERE Entry = 8197; -- Chronalis
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 8199; -- Warleader Krazzilak
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 8200; -- Jin'Zallah the Sandbringer
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 8200; -- Jin'Zallah the Sandbringer
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 8202; -- Cyclok the Mad
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 8205; -- Haarka the Ravenous
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 8207; -- Greater Firebird
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 8208; -- Murderous Blisterpaw
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 8210; -- Razortalon
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 8211; -- Old Cliff Jumper
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 8213; -- Ironback
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 8215; -- Grimungous
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 8216; -- Retherokk the Berserker
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 8217; -- Mith'rethis the Enchanter
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 8217; -- Mith'rethis the Enchanter
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 8218; -- Witherheart the Stalker
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 8219; -- Zul'arek Hatefowler
UPDATE creature_template SET HealthMultiplier = 0.5 WHERE Entry = 8257; -- Oozeling
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 8280; -- Shleipnarr
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 8282; -- Highlord Mastrogonde
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 8282; -- Highlord Mastrogonde
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 8283; -- Slave Master Blackheart
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 8296; -- Mojo the Twisted
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 8298; -- Akubar the Seer
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 8300; -- Ravage
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 8301; -- Clack the Reaver
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 8302; -- Deatheye
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 8303; -- Grunter
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 8304; -- Dreadscorn
UPDATE creature_template SET HealthMultiplier = 0.75 WHERE Entry = 8311; -- Slime Maggot
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 8318; -- Atal'ai Slave
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 8324; -- Atal'ai Skeleton
UPDATE creature_template SET HealthMultiplier = 0.75 WHERE Entry = 8337; -- Dark Iron Steelshifter
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 8338; -- Dark Iron Marksman
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 8384; -- Deep Lurker
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 8408; -- Warlord Krellian
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 8409; -- Caravan Master Tset
UPDATE creature_template SET HealthMultiplier = 3.5 WHERE Entry = 8438; -- Hakkari Bloodkeeper
UPDATE creature_template SET PowerMultiplier = 1.0 WHERE Entry = 8438; -- Hakkari Bloodkeeper
UPDATE creature_template SET HealthMultiplier = 4.0 WHERE Entry = 8497; -- Nightmare Suppressor
UPDATE creature_template SET PowerMultiplier = 1.0 WHERE Entry = 8497; -- Nightmare Suppressor
UPDATE creature_template SET HealthMultiplier = 10.0 WHERE Entry = 8516; -- Belnistrasz
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 8518; -- Rynthariel the Keymaster
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 8519; -- Blighted Surge
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 8520; -- Plague Ravager
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 8521; -- Blighted Horror
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 8522; -- Plague Monstrosity
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 8523; -- Scourge Soldier
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 8525; -- Scourge Warder
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 8527; -- Scourge Guard
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 8529; -- Scourge Champion
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 8530; -- Cannibal Ghoul
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 8531; -- Gibbering Ghoul
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 8534; -- Putrid Gargoyle
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 8542; -- Death Singer
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 8543; -- Stitched Horror
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 8544; -- Gangled Golem
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 8545; -- Stitched Golem
UPDATE creature_template SET HealthMultiplier = 1.33 WHERE Entry = 8547; -- Death Cultist
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 8555; -- Crypt Stalker
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 8556; -- Crypt Walker
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 8558; -- Crypt Slayer
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 8560; -- Mossflayer Scout
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 8561; -- Mossflayer Shadowhunter
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 8562; -- Mossflayer Cannibal
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 8566; -- Dark Iron Lookout
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 8578; -- Magus Rimtori
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 8596; -- Plaguehound Runt
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 8597; -- Plaguehound
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 8598; -- Frenzied Plaguehound
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 8600; -- Plaguebat
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 8601; -- Noxious Plaguebat
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 8602; -- Monstrous Plaguebat
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 8603; -- Carrion Grub
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 8605; -- Carrion Devourer
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 8606; -- Living Decay
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 8607; -- Rotting Sludge
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 8616; -- Infernal Servant
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 8637; -- Dark Iron Watchman
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 8660; -- The Evalcharr
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 8667; -- Gusting Vortex
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 8675; -- Felbeast
UPDATE creature_template SET PowerMultiplier = 5.0 WHERE Entry = 8716; -- Dreadlord
UPDATE creature_template SET HealthMultiplier = 16.0 WHERE Entry = 8718; -- Manahound
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 8757; -- Shahiar
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 8758; -- Zaman
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 8759; -- Mosshoof Runner
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 8761; -- Mosshoof Courser
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 8762; -- Timberweb Recluse
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 8763; -- Mistwing Rogue
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 8764; -- Mistwing Ravager
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 8766; -- Forest Ooze
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 8837; -- Muck Splash
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 8877; -- Sandfury Zealot
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 8890; -- Anvilrage Warden
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 8891; -- Anvilrage Guardsman
UPDATE creature_template SET PowerMultiplier = 1.95 WHERE Entry = 8894; -- Anvilrage Medic
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 8900; -- Doomforge Arcanasmith
UPDATE creature_template SET PowerMultiplier = 1.0 WHERE Entry = 8900; -- Doomforge Arcanasmith
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 8904; -- Shadowforge Senator
UPDATE creature_template SET PowerMultiplier = 1.0 WHERE Entry = 8904; -- Shadowforge Senator
UPDATE creature_template SET HealthMultiplier = 5.5 WHERE Entry = 8908; -- Molten War Golem
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 8908; -- Molten War Golem
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 8910; -- Blazing Fireguard
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 8910; -- Blazing Fireguard
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 8912; -- Twilight's Hammer Torturer
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 8912; -- Twilight's Hammer Torturer
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 8915; -- Twilight's Hammer Ambassador
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 8921; -- Bloodhound
UPDATE creature_template SET HealthMultiplier = 1.8 WHERE Entry = 8925; -- Dredge Worm
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 8926; -- Deep Stinger
UPDATE creature_template SET HealthMultiplier = 1.0 WHERE Entry = 8927; -- Dark Screecher
UPDATE creature_template SET HealthMultiplier = 1.0 WHERE Entry = 8932; -- Borer Beetle
UPDATE creature_template SET HealthMultiplier = 1.5 WHERE Entry = 8956; -- Angerclaw Bear
UPDATE creature_template SET HealthMultiplier = 1.5 WHERE Entry = 8958; -- Angerclaw Mauler
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 8959; -- Felpaw Wolf
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 8960; -- Felpaw Scavenger
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 8961; -- Felpaw Ravager
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 8976; -- Hematos
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 8979; -- Gruklash
UPDATE creature_template SET HealthMultiplier = 1.6 WHERE Entry = 8996; -- Voidwalker Minion
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 9018; -- High Interrogator Gerstahn
UPDATE creature_template SET PowerMultiplier = 5.0 WHERE Entry = 9018; -- High Interrogator Gerstahn
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 9020; -- Commander Gor'shak
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 9022; -- Dughal Stormwing
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 9024; -- Pyromancer Loregrain
UPDATE creature_template SET PowerMultiplier = 5.0 WHERE Entry = 9024; -- Pyromancer Loregrain
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 9025; -- Lord Roccor
UPDATE creature_template SET HealthMultiplier = 8.5 WHERE Entry = 9032; -- Hedrum the Creeper
UPDATE creature_template SET HealthMultiplier = 4.5 WHERE Entry = 9034; -- Hate'rel
UPDATE creature_template SET PowerMultiplier = 5.0 WHERE Entry = 9034; -- Hate'rel
UPDATE creature_template SET HealthMultiplier = 4.5 WHERE Entry = 9035; -- Anger'rel
UPDATE creature_template SET HealthMultiplier = 4.5 WHERE Entry = 9036; -- Vile'rel
UPDATE creature_template SET PowerMultiplier = 6.0 WHERE Entry = 9036; -- Vile'rel
UPDATE creature_template SET HealthMultiplier = 4.5 WHERE Entry = 9037; -- Gloom'rel
UPDATE creature_template SET HealthMultiplier = 4.5 WHERE Entry = 9038; -- Seeth'rel
UPDATE creature_template SET PowerMultiplier = 5.0 WHERE Entry = 9038; -- Seeth'rel
UPDATE creature_template SET HealthMultiplier = 6.0 WHERE Entry = 9039; -- Doom'rel
UPDATE creature_template SET PowerMultiplier = 8.0 WHERE Entry = 9039; -- Doom'rel
UPDATE creature_template SET HealthMultiplier = 4.5 WHERE Entry = 9040; -- Dope'rel
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 9045; -- Scarshield Acolyte
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 9083; -- Razal'blade
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 9085; -- Initiate Amakkar
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 9096; -- Rage Talon Dragonspawn
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 9097; -- Scarshield Legionnaire
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 9098; -- Scarshield Spellbinder
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 9098; -- Scarshield Spellbinder
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 9162; -- Young Diemetradon
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 9163; -- Diemetradon
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 9165; -- Fledgling Pterrordax
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 9166; -- Pterrordax
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 9176; -- Gor'tesh
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 9178; -- Burning Spirit
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 9197; -- Spirestone Battle Mage
UPDATE creature_template SET PowerMultiplier = 5.0 WHERE Entry = 9197; -- Spirestone Battle Mage
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 9199; -- Spirestone Enforcer
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 9201; -- Spirestone Ogre Magus
UPDATE creature_template SET PowerMultiplier = 5.0 WHERE Entry = 9201; -- Spirestone Ogre Magus
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 9216; -- Spirestone Warlord
UPDATE creature_template SET HealthMultiplier = 6.0 WHERE Entry = 9217; -- Spirestone Lord Magus
UPDATE creature_template SET PowerMultiplier = 6.0 WHERE Entry = 9217; -- Spirestone Lord Magus
UPDATE creature_template SET HealthMultiplier = 6.0 WHERE Entry = 9218; -- Spirestone Battle Lord
UPDATE creature_template SET HealthMultiplier = 6.0 WHERE Entry = 9219; -- Spirestone Butcher
UPDATE creature_template SET HealthMultiplier = 9.0 WHERE Entry = 9236; -- Shadow Hunter Vosh'gajin
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 9239; -- Smolderthorn Mystic
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 9240; -- Smolderthorn Shadow Priest
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 9241; -- Smolderthorn Headhunter
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 9257; -- Scarshield Warlock
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 9259; -- Firebrand Grunt
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 9260; -- Firebrand Legionnaire
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 9261; -- Firebrand Darkweaver
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 9262; -- Firebrand Invoker
UPDATE creature_template SET PowerMultiplier = 1.5 WHERE Entry = 9262; -- Firebrand Invoker
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 9263; -- Firebrand Dreadweaver
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 9264; -- Firebrand Pyromancer
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 9265; -- Smolderthorn Shadow Hunter
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 9266; -- Smolderthorn Witch Doctor
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 9267; -- Smolderthorn Axe Thrower
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 9268; -- Smolderthorn Berserker
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 9269; -- Smolderthorn Seer
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 9318; -- Incendosaur
UPDATE creature_template SET HealthMultiplier = 4.5 WHERE Entry = 9319; -- Houndmaster Grebmar
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 9376; -- Blazerunner
UPDATE creature_template SET HealthMultiplier = 1.11 WHERE Entry = 9377; -- Swirling Vortex
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 9396; -- Ground Pounder
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 9416; -- Scarshield Worg
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 9447; -- Scarlet Warder
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 9448; -- Scarlet Praetorian
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 9449; -- Scarlet Cleric
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 9450; -- Scarlet Curate
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 9451; -- Scarlet Archmage
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 9452; -- Scarlet Enchanter
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 9453; -- Aquementas
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 9454; -- Xavathras
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 9456; -- Warlord Krom'zar
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 9462; -- Chieftain Bloodmaw
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 9464; -- Overlord Ror
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 9498; -- Gorishi Grub
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 9499; -- Plugger Spazzring
UPDATE creature_template SET PowerMultiplier = 8.0 WHERE Entry = 9499; -- Plugger Spazzring
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 9500; -- Mistress Nagmara
UPDATE creature_template SET HealthMultiplier = 7.0 WHERE Entry = 9502; -- Phalanx
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 9516; -- Lord Banehollow
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 9516; -- Lord Banehollow
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 9517; -- Shadow Lord Fel'dan
UPDATE creature_template SET HealthMultiplier = 1.5 WHERE Entry = 9518; -- Rakaiah
UPDATE creature_template SET PowerMultiplier = 1.5 WHERE Entry = 9518; -- Rakaiah
UPDATE creature_template SET HealthMultiplier = 8.0 WHERE Entry = 9520; -- Grark Lorkrub
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 9541; -- Blackbreath Crony
UPDATE creature_template SET HealthMultiplier = 11.0 WHERE Entry = 9568; -- Overlord Wyrmthalak
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 9583; -- Bloodaxe Veteran
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 9596; -- Bannok Grimaxe
UPDATE creature_template SET HealthMultiplier = 1.5 WHERE Entry = 9598; -- Arei
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 9622; -- U'cha
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 9623; -- A-Me 01
UPDATE creature_template SET HealthMultiplier = 1.6 WHERE Entry = 9660; -- Agnar Beastamer
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 9690; -- Ember Worg
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 9691; -- Venomtip Scorpid
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 9692; -- Bloodaxe Raider
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 9693; -- Bloodaxe Evoker
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 9697; -- Giant Ember Worg
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 9698; -- Firetail Scorpid
UPDATE creature_template SET HealthMultiplier = 0.5 WHERE Entry = 9708; -- Burning Imp
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 9716; -- Bloodaxe Warmonger
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 9717; -- Bloodaxe Summoner
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 9718; -- Ghok Bashguud
UPDATE creature_template SET HealthMultiplier = 8.0 WHERE Entry = 9736; -- Quartermaster Zigris
UPDATE creature_template SET HealthMultiplier = 0.4 WHERE Entry = 9777; -- Flamekin Sprite
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 9817; -- Blackhand Dreadweaver
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 9818; -- Blackhand Summoner
UPDATE creature_template SET PowerMultiplier = 1.0 WHERE Entry = 9818; -- Blackhand Summoner
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 9819; -- Blackhand Veteran
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 9860; -- Salia
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 9861; -- Moora
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 9862; -- Jaedenar Legionnaire
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 9877; -- Prince Xavalis
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 9878; -- Entropic Beast
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 9916; -- Jarquia
UPDATE creature_template SET HealthMultiplier = 0.3 WHERE Entry = 9956; -- Shadowforge Flame Keeper
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 10040; -- Gorishi Hive Guard
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 10041; -- Gorishi Hive Queen
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 10078; -- Terrorspark
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 10080; -- Sandarr Dunereaver
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 10082; -- Zerillis
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 10083; -- Rage Talon Flamescale
UPDATE creature_template SET HealthMultiplier = 4.5 WHERE Entry = 10096; -- High Justice Grimstone
UPDATE creature_template SET HealthMultiplier = 115.0 WHERE Entry = 10162; -- Lord Victor Nefarius
UPDATE creature_template SET PowerMultiplier = 100.0 WHERE Entry = 10162; -- Lord Victor Nefarius
UPDATE creature_template SET HealthMultiplier = 330.0 WHERE Entry = 10184; -- Onyxia
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 10196; -- General Colbatann
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 10197; -- Mezzir the Howler
UPDATE creature_template SET HealthMultiplier = 11.0 WHERE Entry = 10201; -- Lady Hederine
UPDATE creature_template SET PowerMultiplier = 4.0 WHERE Entry = 10201; -- Lady Hederine
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 10202; -- Azurous
UPDATE creature_template SET HealthMultiplier = 8.0 WHERE Entry = 10220; -- Halycon
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 10221; -- Bloodaxe Worg Pup
UPDATE creature_template SET HealthMultiplier = 3.5 WHERE Entry = 10258; -- Rookery Guardian
UPDATE creature_template SET HealthMultiplier = 4.0 WHERE Entry = 10263; -- Burning Felguard
UPDATE creature_template SET HealthMultiplier = 8.0 WHERE Entry = 10264; -- Solakar Flamewreath
UPDATE creature_template SET HealthMultiplier = 10.0 WHERE Entry = 10268; -- Gizrul the Slavener
UPDATE creature_template SET HealthMultiplier = 1.8 WHERE Entry = 10278; -- Thrag Stonehoof
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 10299; -- Scarshield Infiltrator
UPDATE creature_template SET HealthMultiplier = 2.5 WHERE Entry = 10316; -- Blackhand Incarcerator
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 10317; -- Blackhand Elite
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 10318; -- Blackhand Assassin
UPDATE creature_template SET HealthMultiplier = 4.0 WHERE Entry = 10319; -- Blackhand Iron Guard
UPDATE creature_template SET HealthMultiplier = 10.0 WHERE Entry = 10321; -- Emberstrife
UPDATE creature_template SET HealthMultiplier = 10.0 WHERE Entry = 10339; -- Gyth
UPDATE creature_template SET HealthMultiplier = 6.0 WHERE Entry = 10366; -- Rage Talon Dragon Guard
UPDATE creature_template SET HealthMultiplier = 6.0 WHERE Entry = 10371; -- Rage Talon Captain
UPDATE creature_template SET HealthMultiplier = 6.0 WHERE Entry = 10372; -- Rage Talon Fire Tongue
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 10376; -- Crystal Fang
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 10382; -- Mangled Cadaver
UPDATE creature_template SET HealthMultiplier = 2.0 WHERE Entry = 10384; -- Spectral Citizen
UPDATE creature_template SET HealthMultiplier = 0.1 WHERE Entry = 10389; -- Wrath Phantom
UPDATE creature_template SET PowerMultiplier = 1.0 WHERE Entry = 10389; -- Wrath Phantom
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 10390; -- Skeletal Guardian
UPDATE creature_template SET HealthMultiplier = 6.5 WHERE Entry = 10393; -- Skul
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 10393; -- Skul
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 10398; -- Thuzadin Shadowcaster
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 10405; -- Plague Ghoul
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 10406; -- Ghoul Ravener
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 10408; -- Rockwing Gargoyle
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 10409; -- Rockwing Screecher
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 10412; -- Crypt Crawler
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 10413; -- Crypt Beast
UPDATE creature_template SET HealthMultiplier = 6.0 WHERE Entry = 10414; -- Patchwork Horror
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 10417; -- Venom Belcher
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 10418; -- Crimson Guardsman
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 10419; -- Crimson Conjuror
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 10419; -- Crimson Conjuror
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 10420; -- Crimson Initiate
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 10420; -- Crimson Initiate
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 10421; -- Crimson Defender
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 10421; -- Crimson Defender
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 10422; -- Crimson Sorcerer
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 10422; -- Crimson Sorcerer
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 10423; -- Crimson Priest
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 10423; -- Crimson Priest
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 10424; -- Crimson Gallant
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 10424; -- Crimson Gallant
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 10425; -- Crimson Battle Mage
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 10425; -- Crimson Battle Mage
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 10426; -- Crimson Inquisitor
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 10426; -- Crimson Inquisitor
UPDATE creature_template SET HealthMultiplier = 10.0 WHERE Entry = 10432; -- Vectus
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 10432; -- Vectus
UPDATE creature_template SET HealthMultiplier = 10.0 WHERE Entry = 10433; -- Marduk Blackpool
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 10433; -- Marduk Blackpool
UPDATE creature_template SET HealthMultiplier = 10.0 WHERE Entry = 10435; -- Magistrate Barthilas
UPDATE creature_template SET HealthMultiplier = 10.0 WHERE Entry = 10437; -- Nerub'enkan
UPDATE creature_template SET HealthMultiplier = 10.0 WHERE Entry = 10438; -- Maleki the Pallid
UPDATE creature_template SET PowerMultiplier = 1.5 WHERE Entry = 10438; -- Maleki the Pallid
UPDATE creature_template SET HealthMultiplier = 1.5 WHERE Entry = 10442; -- Chromatic Whelp
UPDATE creature_template SET PowerMultiplier = 3.0 WHERE Entry = 10442; -- Chromatic Whelp
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 10447; -- Chromatic Dragonspawn
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 10463; -- Shrieking Banshee
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 10469; -- Scholomance Adept
UPDATE creature_template SET PowerMultiplier = 3.0 WHERE Entry = 10469; -- Scholomance Adept
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 10470; -- Scholomance Neophyte
UPDATE creature_template SET PowerMultiplier = 3.0 WHERE Entry = 10470; -- Scholomance Neophyte
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 10471; -- Scholomance Acolyte
UPDATE creature_template SET PowerMultiplier = 3.0 WHERE Entry = 10471; -- Scholomance Acolyte
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 10472; -- Scholomance Occultist
UPDATE creature_template SET PowerMultiplier = 3.0 WHERE Entry = 10472; -- Scholomance Occultist
UPDATE creature_template SET HealthMultiplier = 6.0 WHERE Entry = 10475; -- Scholomance Student
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 10476; -- Scholomance Necrolyte
UPDATE creature_template SET PowerMultiplier = 3.0 WHERE Entry = 10476; -- Scholomance Necrolyte
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 10477; -- Scholomance Necromancer
UPDATE creature_template SET PowerMultiplier = 3.0 WHERE Entry = 10477; -- Scholomance Necromancer
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 10478; -- Splintered Skeleton
UPDATE creature_template SET HealthMultiplier = 0.5 WHERE Entry = 10481; -- Reanimated Corpse
UPDATE creature_template SET HealthMultiplier = 0.75 WHERE Entry = 10485; -- Risen Aberration
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 10486; -- Risen Warrior
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 10487; -- Risen Protector
UPDATE creature_template SET PowerMultiplier = 3.0 WHERE Entry = 10487; -- Risen Protector
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 10488; -- Risen Construct
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 10489; -- Risen Guard
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 10491; -- Risen Bonewarder
UPDATE creature_template SET PowerMultiplier = 3.0 WHERE Entry = 10491; -- Risen Bonewarder
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 10495; -- Diseased Ghoul
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 10497; -- Ragged Ghoul
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 10498; -- Spectral Tutor
UPDATE creature_template SET PowerMultiplier = 3.0 WHERE Entry = 10498; -- Spectral Tutor
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 10499; -- Spectral Researcher
UPDATE creature_template SET PowerMultiplier = 3.0 WHERE Entry = 10499; -- Spectral Researcher
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 10500; -- Spectral Teacher
UPDATE creature_template SET PowerMultiplier = 3.0 WHERE Entry = 10500; -- Spectral Teacher
UPDATE creature_template SET HealthMultiplier = 11.0 WHERE Entry = 10502; -- Lady Illucia Barov
UPDATE creature_template SET PowerMultiplier = 3.0 WHERE Entry = 10502; -- Lady Illucia Barov
UPDATE creature_template SET HealthMultiplier = 12.0 WHERE Entry = 10503; -- Jandice Barov
UPDATE creature_template SET PowerMultiplier = 3.0 WHERE Entry = 10503; -- Jandice Barov
UPDATE creature_template SET HealthMultiplier = 14.0 WHERE Entry = 10505; -- Instructor Malicia
UPDATE creature_template SET PowerMultiplier = 3.0 WHERE Entry = 10505; -- Instructor Malicia
UPDATE creature_template SET HealthMultiplier = 12.0 WHERE Entry = 10507; -- The Ravenian
UPDATE creature_template SET HealthMultiplier = 0.3 WHERE Entry = 10536; -- Plagued Maggot
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 10559; -- Lady Vespia
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 10580; -- Fetid Zombie
UPDATE creature_template SET HealthMultiplier = 8.0 WHERE Entry = 10584; -- Urok Doomhowl
UPDATE creature_template SET HealthMultiplier = 8.0 WHERE Entry = 10596; -- Mother Smolderweb
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 10601; -- Urok Enforcer
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 10602; -- Urok Ogre Magus
UPDATE creature_template SET PowerMultiplier = 5.0 WHERE Entry = 10602; -- Urok Ogre Magus
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 10605; -- Scarlet Medic
UPDATE creature_template SET HealthMultiplier = 1.09 WHERE Entry = 10638; -- Kanati Greycloud
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 10639; -- Rorgish Jowl
UPDATE creature_template SET HealthMultiplier = 1.5 WHERE Entry = 10647; -- Prince Raze
UPDATE creature_template SET PowerMultiplier = 1.25 WHERE Entry = 10647; -- Prince Raze
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 10648; -- Xavaric
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 10659; -- Cobalt Whelp
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 10660; -- Cobalt Broodling
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 10661; -- Spell Eater
UPDATE creature_template SET HealthMultiplier = 6.0 WHERE Entry = 10662; -- Spellmaw
UPDATE creature_template SET HealthMultiplier = 6.0 WHERE Entry = 10663; -- Manaclaw
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 10683; -- Rookery Hatcher
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 10742; -- Blackhand Dragon Handler
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 10757; -- Boiling Elemental
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 10758; -- Grimtotem Bandit
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 10760; -- Grimtotem Geomancer
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 10761; -- Grimtotem Reaver
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 10801; -- Jabbering Ghoul
UPDATE creature_template SET HealthMultiplier = 8.25 WHERE Entry = 10808; -- Timmy the Cruel
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 10809; -- Stonespine
UPDATE creature_template SET HealthMultiplier = 8.0 WHERE Entry = 10811; -- Archivist Galford
UPDATE creature_template SET PowerMultiplier = 3.0 WHERE Entry = 10811; -- Archivist Galford
UPDATE creature_template SET HealthMultiplier = 10.0 WHERE Entry = 10812; -- Grand Crusader Dathrohan
UPDATE creature_template SET PowerMultiplier = 3.0 WHERE Entry = 10812; -- Grand Crusader Dathrohan
UPDATE creature_template SET HealthMultiplier = 8.0 WHERE Entry = 10814; -- Chromatic Elite Guard
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 10816; -- Wandering Skeleton
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 10817; -- Duggan Wildhammer
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 10821; -- Hed'mush the Rotting
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 10822; -- Warlord Thresh'jin
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 10824; -- Ranger Lord Hawkspear
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 10826; -- Lord Darkscythe
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 10827; -- Deathspeaker Selendre
UPDATE creature_template SET HealthMultiplier = 3.5 WHERE Entry = 10828; -- High General Abbendis
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 10828; -- High General Abbendis
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 10836; -- Farmer Dalson
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 10839; -- Argent Officer Garush
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 10840; -- Argent Officer Pureheart
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 10896; -- Arnak Grimtotem
UPDATE creature_template SET HealthMultiplier = 4.0 WHERE Entry = 10899; -- Goraluk Anvilcrack
UPDATE creature_template SET HealthMultiplier = 9.0 WHERE Entry = 10901; -- Lorekeeper Polkelt
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 10916; -- Winterfall Runner
UPDATE creature_template SET PowerMultiplier = 1.5 WHERE Entry = 10917; -- Aurius
UPDATE creature_template SET HealthMultiplier = 11.0 WHERE Entry = 10938; -- Redpath the Corrupted
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 10946; -- Horgus the Ravager
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 10948; -- Darrowshire Defender
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 10951; -- Marauding Corpse
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 10952; -- Marauding Skeleton
UPDATE creature_template SET HealthMultiplier = 2.5 WHERE Entry = 10954; -- Bloodletter
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 10992; -- Enraged Panther
UPDATE creature_template SET HealthMultiplier = 12.0 WHERE Entry = 10997; -- Cannon Master Willey
UPDATE creature_template SET HealthMultiplier = 4.0 WHERE Entry = 11022; -- Alexi Barov
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 11024; -- Della
UPDATE creature_template SET HealthMultiplier = 1.8 WHERE Entry = 11026; -- Sprite Jumpsprocket
UPDATE creature_template SET HealthMultiplier = 1.8 WHERE Entry = 11028; -- Jemma Quikswitch
UPDATE creature_template SET HealthMultiplier = 0.4 WHERE Entry = 11030; -- Mindless Undead
UPDATE creature_template SET HealthMultiplier = 7.0 WHERE Entry = 11032; -- Malor the Zealous
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 11032; -- Malor the Zealous
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 11039; -- Duke Nicholas Zverenhoff
UPDATE creature_template SET HealthMultiplier = 1.8 WHERE Entry = 11041; -- Milla Fairancora
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 11043; -- Crimson Monk
UPDATE creature_template SET HealthMultiplier = 1.8 WHERE Entry = 11048; -- Victor Ward
UPDATE creature_template SET HealthMultiplier = 9.0 WHERE Entry = 11058; -- Fras Siabi
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 11075; -- Cauldron Lord Bilemaw
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 11076; -- Cauldron Lord Razarch
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 11077; -- Cauldron Lord Malvinious
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 11078; -- Cauldron Lord Soulwrath
UPDATE creature_template SET HealthMultiplier = 1.8 WHERE Entry = 11083; -- Darianna
UPDATE creature_template SET HealthMultiplier = 1.8 WHERE Entry = 11096; -- Randal Worth
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 11120; -- Crimson Hammersmith
UPDATE creature_template SET HealthMultiplier = 6.5 WHERE Entry = 11143; -- Postmaster Malown
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 11198; -- Broken Exile
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 11257; -- Scholomance Handler
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 11257; -- Scholomance Handler
UPDATE creature_template SET HealthMultiplier = 10.0 WHERE Entry = 11261; -- Doctor Theolen Krastinov
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 11285; -- Rory
UPDATE creature_template SET HealthMultiplier = 0.4 WHERE Entry = 11288; -- Spectral Betrayer
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 11289; -- Spectral Defender
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 11318; -- Ragefire Trogg
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 11320; -- Earthborer
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 11321; -- Molten Elemental
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 11322; -- Searing Blade Cultist
UPDATE creature_template SET PowerMultiplier = 1.5 WHERE Entry = 11322; -- Searing Blade Cultist
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 11323; -- Searing Blade Enforcer
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 11324; -- Searing Blade Warlock
UPDATE creature_template SET HealthMultiplier = 10.0 WHERE Entry = 11339; -- Hakkari Shadow Hunter
UPDATE creature_template SET PowerMultiplier = 6.0 WHERE Entry = 11339; -- Hakkari Shadow Hunter
UPDATE creature_template SET HealthMultiplier = 6.0 WHERE Entry = 11340; -- Hakkari Blood Priest
UPDATE creature_template SET PowerMultiplier = 5.0 WHERE Entry = 11340; -- Hakkari Blood Priest
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 11346; -- Hakkari Oracle
UPDATE creature_template SET PowerMultiplier = 3.0 WHERE Entry = 11346; -- Hakkari Oracle
UPDATE creature_template SET HealthMultiplier = 7.0 WHERE Entry = 11350; -- Gurubashi Axe Thrower
UPDATE creature_template SET HealthMultiplier = 7.0 WHERE Entry = 11351; -- Gurubashi Headhunter
UPDATE creature_template SET HealthMultiplier = 15.0 WHERE Entry = 11352; -- Gurubashi Berserker
UPDATE creature_template SET HealthMultiplier = 6.0 WHERE Entry = 11353; -- Gurubashi Blood Drinker
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 11355; -- Gurubashi Warrior
UPDATE creature_template SET HealthMultiplier = 10.0 WHERE Entry = 11356; -- Gurubashi Champion
UPDATE creature_template SET HealthMultiplier = 14.0 WHERE Entry = 11359; -- Soulflayer
UPDATE creature_template SET HealthMultiplier = 10.0 WHERE Entry = 11370; -- Razzashi Broodwidow
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 11371; -- Razzashi Serpent
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 11372; -- Razzashi Adder
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 11373; -- Razzashi Cobra
UPDATE creature_template SET HealthMultiplier = 120.0 WHERE Entry = 11380; -- Jin'do the Hexxer
UPDATE creature_template SET PowerMultiplier = 10.0 WHERE Entry = 11380; -- Jin'do the Hexxer
UPDATE creature_template SET HealthMultiplier = 140.0 WHERE Entry = 11382; -- Bloodlord Mandokir
UPDATE creature_template SET HealthMultiplier = 4.5 WHERE Entry = 11383; -- High Priestess Hai'watna
UPDATE creature_template SET PowerMultiplier = 3.0 WHERE Entry = 11383; -- High Priestess Hai'watna
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 11437; -- Minor Infernal
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 11441; -- Gordok Brute
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 11444; -- Gordok Mage-Lord
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 11444; -- Gordok Mage-Lord
UPDATE creature_template SET HealthMultiplier = 6.0 WHERE Entry = 11445; -- Gordok Captain
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 11445; -- Gordok Captain
UPDATE creature_template SET HealthMultiplier = 20.0 WHERE Entry = 11447; -- Mushgog
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 11448; -- Gordok Warlock
UPDATE creature_template SET PowerMultiplier = 3.0 WHERE Entry = 11448; -- Gordok Warlock
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 11450; -- Gordok Reaver
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 11451; -- Wildspawn Satyr
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 11452; -- Wildspawn Rogue
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 11453; -- Wildspawn Trickster
UPDATE creature_template SET PowerMultiplier = 1.5 WHERE Entry = 11453; -- Wildspawn Trickster
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 11454; -- Wildspawn Betrayer
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 11455; -- Wildspawn Felsworn
UPDATE creature_template SET PowerMultiplier = 1.5 WHERE Entry = 11455; -- Wildspawn Felsworn
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 11456; -- Wildspawn Shadowstalker
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 11457; -- Wildspawn Hellcaller
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 11457; -- Wildspawn Hellcaller
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 11458; -- Petrified Treant
UPDATE creature_template SET HealthMultiplier = 6.0 WHERE Entry = 11459; -- Ironbark Protector
UPDATE creature_template SET HealthMultiplier = 0.25 WHERE Entry = 11460; -- Alzzin's Minion
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 11461; -- Warpwood Guardian
UPDATE creature_template SET PowerMultiplier = 1.5 WHERE Entry = 11461; -- Warpwood Guardian
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 11464; -- Warpwood Tangler
UPDATE creature_template SET PowerMultiplier = 1.5 WHERE Entry = 11464; -- Warpwood Tangler
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 11465; -- Warpwood Stomper
UPDATE creature_template SET PowerMultiplier = 3.0 WHERE Entry = 11466; -- Highborne Summoner
UPDATE creature_template SET HealthMultiplier = 6.0 WHERE Entry = 11467; -- Tsu'zee
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 11469; -- Eldreth Seether
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 11470; -- Eldreth Sorcerer
UPDATE creature_template SET PowerMultiplier = 3.0 WHERE Entry = 11470; -- Eldreth Sorcerer
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 11472; -- Eldreth Spirit
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 11476; -- Skeletal Highborne
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 11483; -- Mana Remnant
UPDATE creature_template SET PowerMultiplier = 4.0 WHERE Entry = 11483; -- Mana Remnant
UPDATE creature_template SET HealthMultiplier = 7.0 WHERE Entry = 11488; -- Illyanna Ravenoak
UPDATE creature_template SET PowerMultiplier = 3.0 WHERE Entry = 11488; -- Illyanna Ravenoak
UPDATE creature_template SET HealthMultiplier = 14.0 WHERE Entry = 11492; -- Alzzin the Wildshaper
UPDATE creature_template SET PowerMultiplier = 5.0 WHERE Entry = 11492; -- Alzzin the Wildshaper
UPDATE creature_template SET HealthMultiplier = 12.0 WHERE Entry = 11496; -- Immol'thar
UPDATE creature_template SET HealthMultiplier = 30.0 WHERE Entry = 11497; -- The Razza
UPDATE creature_template SET PowerMultiplier = 10.0 WHERE Entry = 11497; -- The Razza
UPDATE creature_template SET HealthMultiplier = 20.0 WHERE Entry = 11498; -- Skarr the Unbreakable
UPDATE creature_template SET HealthMultiplier = 330.0 WHERE Entry = 11502; -- Ragnaros
UPDATE creature_template SET HealthMultiplier = 4.0 WHERE Entry = 11517; -- Oggleflint
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 11518; -- Jergosh the Invoker
UPDATE creature_template SET HealthMultiplier = 4.25 WHERE Entry = 11519; -- Bazzalan
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 11551; -- Necrofiend
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 11560; -- Magrami Spectre
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 11582; -- Scholomance Dark Summoner
UPDATE creature_template SET PowerMultiplier = 3.0 WHERE Entry = 11582; -- Scholomance Dark Summoner
UPDATE creature_template SET HealthMultiplier = 650.0 WHERE Entry = 11583; -- Nefarian
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 11611; -- Cavalier Durgen
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 11614; -- Bloodshot
UPDATE creature_template SET HealthMultiplier = 0.4 WHERE Entry = 11620; -- Spectral Marauder
UPDATE creature_template SET HealthMultiplier = 12.0 WHERE Entry = 11622; -- Rattlegore
UPDATE creature_template SET PowerMultiplier = 3.0 WHERE Entry = 11622; -- Rattlegore
UPDATE creature_template SET HealthMultiplier = 40.0 WHERE Entry = 11658; -- Molten Giant
UPDATE creature_template SET HealthMultiplier = 45.0 WHERE Entry = 11659; -- Molten Destroyer
UPDATE creature_template SET HealthMultiplier = 30.0 WHERE Entry = 11661; -- Flamewaker
UPDATE creature_template SET PowerMultiplier = 10.0 WHERE Entry = 11661; -- Flamewaker
UPDATE creature_template SET HealthMultiplier = 30.0 WHERE Entry = 11662; -- Flamewaker Priest
UPDATE creature_template SET PowerMultiplier = 12.0 WHERE Entry = 11662; -- Flamewaker Priest
UPDATE creature_template SET HealthMultiplier = 40.0 WHERE Entry = 11663; -- Flamewaker Healer
UPDATE creature_template SET PowerMultiplier = 12.0 WHERE Entry = 11663; -- Flamewaker Healer
UPDATE creature_template SET HealthMultiplier = 40.0 WHERE Entry = 11664; -- Flamewaker Elite
UPDATE creature_template SET PowerMultiplier = 12.0 WHERE Entry = 11664; -- Flamewaker Elite
UPDATE creature_template SET HealthMultiplier = 30.0 WHERE Entry = 11665; -- Lava Annihilator
UPDATE creature_template SET HealthMultiplier = 25.0 WHERE Entry = 11666; -- Firewalker
UPDATE creature_template SET HealthMultiplier = 25.0 WHERE Entry = 11667; -- Flameguard
UPDATE creature_template SET HealthMultiplier = 30.0 WHERE Entry = 11668; -- Firelord
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 11669; -- Flame Imp
UPDATE creature_template SET HealthMultiplier = 15.0 WHERE Entry = 11671; -- Core Hound
UPDATE creature_template SET HealthMultiplier = 25.0 WHERE Entry = 11672; -- Core Rager
UPDATE creature_template SET HealthMultiplier = 35.0 WHERE Entry = 11673; -- Ancient Core Hound
UPDATE creature_template SET HealthMultiplier = 1.04 WHERE Entry = 11680; -- Horde Scout
UPDATE creature_template SET HealthMultiplier = 2.0 WHERE Entry = 11690; -- Gnarlpine Instigator
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 11735; -- Stonelash Scorpid
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 11736; -- Stonelash Pincer
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 11737; -- Stonelash Flayer
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 11738; -- Sand Skitterer
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 11739; -- Rock Stalker
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 11740; -- Dredge Striker
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 11741; -- Dredge Crusher
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 11744; -- Dust Stormer
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 11745; -- Cyclone Warrior
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 11746; -- Desert Rumbler
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 11747; -- Desert Rager
UPDATE creature_template SET HealthMultiplier = 1.6 WHERE Entry = 11752; -- Blaise Montgomery
UPDATE creature_template SET HealthMultiplier = 1.0 WHERE Entry = 11789; -- Deep Borer
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 11791; -- Putridus Trickster
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 11792; -- Putridus Shadowstalker
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 11793; -- Celebrian Dryad
UPDATE creature_template SET PowerMultiplier = 1.5 WHERE Entry = 11793; -- Celebrian Dryad
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 11794; -- Sister of Celebrian
UPDATE creature_template SET PowerMultiplier = 1.15 WHERE Entry = 11798; -- Bunthen Plainswind
UPDATE creature_template SET PowerMultiplier = 1.15 WHERE Entry = 11800; -- Silva Fil'naveth
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 11803; -- Twilight Keeper Exeter
UPDATE creature_template SET HealthMultiplier = 1.45 WHERE Entry = 11804; -- Twilight Keeper Havunth
UPDATE creature_template SET PowerMultiplier = 1.0 WHERE Entry = 11822; -- Moonglade Warden
UPDATE creature_template SET HealthMultiplier = 7.0 WHERE Entry = 11830; -- Hakkari Priest
UPDATE creature_template SET PowerMultiplier = 5.0 WHERE Entry = 11830; -- Hakkari Priest
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 11873; -- Spectral Attendant
UPDATE creature_template SET PowerMultiplier = 11.0 WHERE Entry = 11878; -- Nathanos Blightcaller
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 11882; -- Twilight Stonecaller
UPDATE creature_template SET HealthMultiplier = 2.0 WHERE Entry = 11886; -- Mercutio Filthgorger
UPDATE creature_template SET HealthMultiplier = 2.0 WHERE Entry = 11887; -- Crypt Robber
UPDATE creature_template SET PowerMultiplier = 4.0 WHERE Entry = 11898; -- Crusader Lord Valdelmar
UPDATE creature_template SET HealthMultiplier = 1.0 WHERE Entry = 11918; -- Gogger Stonepounder
UPDATE creature_template SET HealthMultiplier = 300.0 WHERE Entry = 11981; -- Flamegor
UPDATE creature_template SET HealthMultiplier = 248.0 WHERE Entry = 11982; -- Magmadar
UPDATE creature_template SET HealthMultiplier = 300.0 WHERE Entry = 11983; -- Firemaw
UPDATE creature_template SET HealthMultiplier = 248.0 WHERE Entry = 11988; -- Golemagg the Incinerator
UPDATE creature_template SET HealthMultiplier = 275.0 WHERE Entry = 12017; -- Broodlord Lashlayer
UPDATE creature_template SET HealthMultiplier = 200.0 WHERE Entry = 12018; -- Majordomo Executus
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 12046; -- Gor'marok the Ravager
UPDATE creature_template SET HealthMultiplier = 176.0 WHERE Entry = 12056; -- Baron Geddon
UPDATE creature_template SET HealthMultiplier = 198.0 WHERE Entry = 12057; -- Garr
UPDATE creature_template SET HealthMultiplier = 25.0 WHERE Entry = 12076; -- Lava Elemental
UPDATE creature_template SET HealthMultiplier = 132.0 WHERE Entry = 12098; -- Sulfuron Harbinger
UPDATE creature_template SET HealthMultiplier = 20.0 WHERE Entry = 12099; -- Firesworn
UPDATE creature_template SET HealthMultiplier = 25.0 WHERE Entry = 12100; -- Lava Reaver
UPDATE creature_template SET HealthMultiplier = 30.0 WHERE Entry = 12101; -- Lava Surger
UPDATE creature_template SET HealthMultiplier = 132.0 WHERE Entry = 12118; -- Lucifron
UPDATE creature_template SET PowerMultiplier = 15.0 WHERE Entry = 12118; -- Lucifron
UPDATE creature_template SET HealthMultiplier = 35.0 WHERE Entry = 12119; -- Flamewaker Protector
UPDATE creature_template SET PowerMultiplier = 10.0 WHERE Entry = 12119; -- Flamewaker Protector
UPDATE creature_template SET HealthMultiplier = 30.0 WHERE Entry = 12126; -- Lord Tirion Fordring
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 12128; -- Crimson Elite
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 12128; -- Crimson Elite
UPDATE creature_template SET HealthMultiplier = 25.0 WHERE Entry = 12129; -- Onyxian Warder
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 12140; -- Guardian of Elune
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 12143; -- Son of Flame
UPDATE creature_template SET HealthMultiplier = 2.0 WHERE Entry = 12144; -- Lunaclaw Spirit
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 12199; -- Shade of Ambermoon
UPDATE creature_template SET HealthMultiplier = 5.5 WHERE Entry = 12207; -- Thessala Hydra
UPDATE creature_template SET HealthMultiplier = 0.3 WHERE Entry = 12208; -- Conquered Soul of the Blightcaller
UPDATE creature_template SET HealthMultiplier = 0.75 WHERE Entry = 12216; -- Poison Sprite
UPDATE creature_template SET HealthMultiplier = 0.75 WHERE Entry = 12217; -- Corruptor
UPDATE creature_template SET PowerMultiplier = 1.45 WHERE Entry = 12224; -- Cavern Shambler
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 12239; -- Spirit of Gelk
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 12240; -- Spirit of Kolk
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 12241; -- Spirit of Magra
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 12248; -- Infiltrator Hameya
UPDATE creature_template SET HealthMultiplier = 132.0 WHERE Entry = 12259; -- Gehennas
UPDATE creature_template SET PowerMultiplier = 15.0 WHERE Entry = 12259; -- Gehennas
UPDATE creature_template SET HealthMultiplier = 132.0 WHERE Entry = 12264; -- Shazzrah
UPDATE creature_template SET PowerMultiplier = 15.0 WHERE Entry = 12264; -- Shazzrah
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 12265; -- Lava Spawn
UPDATE creature_template SET HealthMultiplier = 6.0 WHERE Entry = 12337; -- Crimson Courier
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 12337; -- Crimson Courier
UPDATE creature_template SET HealthMultiplier = 12.0 WHERE Entry = 12339; -- Demetria
UPDATE creature_template SET PowerMultiplier = 6.0 WHERE Entry = 12339; -- Demetria
UPDATE creature_template SET HealthMultiplier = 0.7 WHERE Entry = 12352; -- Scarlet Trooper
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 12369; -- Lord Kragaru
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 12387; -- Large Vile Slime
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 12387; -- Large Vile Slime
UPDATE creature_template SET HealthMultiplier = 20.0 WHERE Entry = 12396; -- Doomguard Commander
UPDATE creature_template SET PowerMultiplier = 5.0 WHERE Entry = 12396; -- Doomguard Commander
UPDATE creature_template SET HealthMultiplier = 110.0 WHERE Entry = 12397; -- Lord Kazzak
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 12416; -- Blackwing Legionnaire
UPDATE creature_template SET HealthMultiplier = 1.0 WHERE Entry = 12418; -- Gordok Hyena
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 12420; -- Blackwing Mage
UPDATE creature_template SET PowerMultiplier = 5.0 WHERE Entry = 12420; -- Blackwing Mage
UPDATE creature_template SET HealthMultiplier = 15.0 WHERE Entry = 12422; -- Death Talon Dragonspawn
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 12425; -- Flint Shadowmore
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 12432; -- Old Vicejaw
UPDATE creature_template SET HealthMultiplier = 135.0 WHERE Entry = 12435; -- Razorgore the Untamed
UPDATE creature_template SET HealthMultiplier = 35.0 WHERE Entry = 12457; -- Blackwing Spellbinder
UPDATE creature_template SET PowerMultiplier = 10.0 WHERE Entry = 12457; -- Blackwing Spellbinder
UPDATE creature_template SET HealthMultiplier = 20.0 WHERE Entry = 12458; -- Blackwing Taskmaster
UPDATE creature_template SET PowerMultiplier = 10.0 WHERE Entry = 12458; -- Blackwing Taskmaster
UPDATE creature_template SET HealthMultiplier = 35.0 WHERE Entry = 12459; -- Blackwing Warlock
UPDATE creature_template SET PowerMultiplier = 10.0 WHERE Entry = 12459; -- Blackwing Warlock
UPDATE creature_template SET HealthMultiplier = 65.0 WHERE Entry = 12460; -- Death Talon Wyrmguard
UPDATE creature_template SET HealthMultiplier = 50.0 WHERE Entry = 12461; -- Death Talon Overseer
UPDATE creature_template SET HealthMultiplier = 40.0 WHERE Entry = 12463; -- Death Talon Flamescale
UPDATE creature_template SET HealthMultiplier = 35.0 WHERE Entry = 12464; -- Death Talon Seether
UPDATE creature_template SET HealthMultiplier = 35.0 WHERE Entry = 12465; -- Death Talon Wyrmkin
UPDATE creature_template SET PowerMultiplier = 10.0 WHERE Entry = 12465; -- Death Talon Wyrmkin
UPDATE creature_template SET HealthMultiplier = 75.0 WHERE Entry = 12467; -- Death Talon Captain
UPDATE creature_template SET HealthMultiplier = 35.0 WHERE Entry = 12468; -- Death Talon Hatcher
UPDATE creature_template SET PowerMultiplier = 10.0 WHERE Entry = 12468; -- Death Talon Hatcher
UPDATE creature_template SET HealthMultiplier = 25.0 WHERE Entry = 12474; -- Emeraldon Boughguard
UPDATE creature_template SET HealthMultiplier = 25.0 WHERE Entry = 12475; -- Emeraldon Tree Warder
UPDATE creature_template SET HealthMultiplier = 25.0 WHERE Entry = 12476; -- Emeraldon Oracle
UPDATE creature_template SET PowerMultiplier = 10.0 WHERE Entry = 12476; -- Emeraldon Oracle
UPDATE creature_template SET PowerMultiplier = 10.0 WHERE Entry = 12478; -- Verdantine Oracle
UPDATE creature_template SET HealthMultiplier = 25.0 WHERE Entry = 12496; -- Dreamtracker
UPDATE creature_template SET HealthMultiplier = 25.0 WHERE Entry = 12497; -- Dreamroarer
UPDATE creature_template SET HealthMultiplier = 25.0 WHERE Entry = 12498; -- Dreamstalker
UPDATE creature_template SET HealthMultiplier = 1.01 WHERE Entry = 12576; -- Grish Longrunner
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 12676; -- Sharptalon
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 12677; -- Shadumbra
UPDATE creature_template SET HealthMultiplier = 10.0 WHERE Entry = 12800; -- Chimaerok
UPDATE creature_template SET HealthMultiplier = 10.0 WHERE Entry = 12801; -- Arcane Chimaerok
UPDATE creature_template SET HealthMultiplier = 7.0 WHERE Entry = 12802; -- Chimaerok Devourer
UPDATE creature_template SET HealthMultiplier = 100.0 WHERE Entry = 12803; -- Lord Lakmaeran
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 12836; -- Wandering Protector
UPDATE creature_template SET HealthMultiplier = 2.0 WHERE Entry = 12860; -- Duriel Moonfire
UPDATE creature_template SET HealthMultiplier = 2.0 WHERE Entry = 12866; -- Myriam Moonsinger
UPDATE creature_template SET HealthMultiplier = 12.0 WHERE Entry = 12899; -- Axtroz
UPDATE creature_template SET HealthMultiplier = 2.0 WHERE Entry = 12940; -- Vorsha the Lasher
UPDATE creature_template SET HealthMultiplier = 1000.0 WHERE Entry = 13020; -- Vaelastrasz the Corrupt
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 13036; -- Gordok Mastiff
UPDATE creature_template SET HealthMultiplier = 0.32 WHERE Entry = 13099; -- Irondeep Explorer
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 13118; -- Crimson Bodyguard
UPDATE creature_template SET HealthMultiplier = 10.0 WHERE Entry = 13280; -- Hydrospawn
UPDATE creature_template SET PowerMultiplier = 3.0 WHERE Entry = 13280; -- Hydrospawn
UPDATE creature_template SET HealthMultiplier = 6.0 WHERE Entry = 13285; -- Death Lash
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 13323; -- Subterranean Diemetradon
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 13602; -- The Abominable Greench
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 13718; -- The Nameless Prophet
UPDATE creature_template SET HealthMultiplier = 2.0 WHERE Entry = 13737; -- Marandis' Sister
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 13738; -- Veng
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 13739; -- Maraudos
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 13740; -- Magra
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 13741; -- Gelk
UPDATE creature_template SET HealthMultiplier = 3.5 WHERE Entry = 13896; -- Scalebeard
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 13976; -- Tortured Drake
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 13996; -- Blackwing Technician
UPDATE creature_template SET HealthMultiplier = 550.0 WHERE Entry = 14020; -- Chromaggus
UPDATE creature_template SET HealthMultiplier = 1.5 WHERE Entry = 14023; -- Corrupted Green Whelp
UPDATE creature_template SET HealthMultiplier = 1.5 WHERE Entry = 14024; -- Corrupted Blue Whelp
UPDATE creature_template SET HealthMultiplier = 30.0 WHERE Entry = 14101; -- Enraged Felguard
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 14123; -- Steeljaw Snapper
UPDATE creature_template SET HealthMultiplier = 1.09 WHERE Entry = 14222; -- Araga
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 14223; -- Cranky Benj
UPDATE creature_template SET HealthMultiplier = 1.1 WHERE Entry = 14225; -- Prince Kellen
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 14227; -- Hissperak
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 14231; -- Drogoth the Roamer
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 14232; -- Dart
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 14241; -- Ironbark the Redeemed
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 14261; -- Blue Drakonid
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 14262; -- Green Drakonid
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 14264; -- Red Drakonid
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 14265; -- Black Drakonid
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 14267; -- Emogg the Crusher
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 14276; -- Scargil
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 14279; -- Creepthess
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 14280; -- Big Samras
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 14281; -- Jimmy the Bleeder
UPDATE creature_template SET HealthMultiplier = 2.5 WHERE Entry = 14303; -- Petrified Guardian
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 14308; -- Ferra
UPDATE creature_template SET HealthMultiplier = 8.0 WHERE Entry = 14321; -- Guard Fengus
UPDATE creature_template SET HealthMultiplier = 8.0 WHERE Entry = 14322; -- Stomper Kreeg
UPDATE creature_template SET HealthMultiplier = 8.0 WHERE Entry = 14323; -- Guard Slip'kik
UPDATE creature_template SET HealthMultiplier = 8.0 WHERE Entry = 14324; -- Cho'Rush the Observer
UPDATE creature_template SET PowerMultiplier = 4.0 WHERE Entry = 14324; -- Cho'Rush the Observer
UPDATE creature_template SET HealthMultiplier = 9.0 WHERE Entry = 14325; -- Captain Kromcrush
UPDATE creature_template SET HealthMultiplier = 8.0 WHERE Entry = 14327; -- Lethtendris
UPDATE creature_template SET PowerMultiplier = 4.0 WHERE Entry = 14327; -- Lethtendris
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 14339; -- Death Howl
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 14340; -- Alshirr Banebreath
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 14342; -- Ragepaw
UPDATE creature_template SET HealthMultiplier = 1.5 WHERE Entry = 14344; -- Mongress
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 14351; -- Gordok Bushwacker
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 14353; -- Mizzle the Crafty
UPDATE creature_template SET HealthMultiplier = 6.0 WHERE Entry = 14354; -- Pusillin
UPDATE creature_template SET PowerMultiplier = 6.0 WHERE Entry = 14354; -- Pusillin
UPDATE creature_template SET PowerMultiplier = 1.0 WHERE Entry = 14364; -- Shen'dralar Spirit
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 14372; -- Winterfall Ambusher
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 14397; -- Mana Burst
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 14398; -- Eldreth Darter
UPDATE creature_template SET PowerMultiplier = 3.0 WHERE Entry = 14398; -- Eldreth Darter
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 14401; -- Master Elemental Shaper Krixix
UPDATE creature_template SET HealthMultiplier = 1.05 WHERE Entry = 14424; -- Mirelow
UPDATE creature_template SET HealthMultiplier = 0.95 WHERE Entry = 14425; -- Gnawbone
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 14426; -- Harb Foulmountain
UPDATE creature_template SET HealthMultiplier = 1.02 WHERE Entry = 14433; -- Sludginn
UPDATE creature_template SET HealthMultiplier = 3.5 WHERE Entry = 14445; -- Lord Captain Wyrmak
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 14446; -- Fingat
UPDATE creature_template SET HealthMultiplier = 1.5 WHERE Entry = 14448; -- Molt Thorn
UPDATE creature_template SET HealthMultiplier = 10.0 WHERE Entry = 14456; -- Blackwing Guardsman
UPDATE creature_template SET HealthMultiplier = 10.0 WHERE Entry = 14471; -- Setis
UPDATE creature_template SET HealthMultiplier = 4.0 WHERE Entry = 14473; -- Lapress
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 14474; -- Zora
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 14475; -- Rex Ashil
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 14477; -- Grubthor
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 14478; -- Huricanian
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 14479; -- Twilight Lord Everun
UPDATE creature_template SET HealthMultiplier = 0.7 WHERE Entry = 14484; -- Injured Peasant
UPDATE creature_template SET HealthMultiplier = 0.7 WHERE Entry = 14485; -- Plagued Peasant
UPDATE creature_template SET HealthMultiplier = 1.15 WHERE Entry = 14488; -- Roloch
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 14490; -- Rippa
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 14492; -- Verifonix
UPDATE creature_template SET HealthMultiplier = 10.0 WHERE Entry = 14502; -- Xorothian Dreadsteed
UPDATE creature_template SET HealthMultiplier = 12.0 WHERE Entry = 14506; -- Lord Hel'nurath
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 14506; -- Lord Hel'nurath
UPDATE creature_template SET HealthMultiplier = 80.0 WHERE Entry = 14507; -- High Priest Venoxis
UPDATE creature_template SET PowerMultiplier = 10.0 WHERE Entry = 14507; -- High Priest Venoxis
UPDATE creature_template SET HealthMultiplier = 1.6 WHERE Entry = 14508; -- Short John Mithril
UPDATE creature_template SET HealthMultiplier = 50.0 WHERE Entry = 14509; -- High Priest Thekal
UPDATE creature_template SET PowerMultiplier = 5.0 WHERE Entry = 14509; -- High Priest Thekal
UPDATE creature_template SET HealthMultiplier = 125.0 WHERE Entry = 14510; -- High Priestess Mar'li
UPDATE creature_template SET PowerMultiplier = 5.0 WHERE Entry = 14510; -- High Priestess Mar'li
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 14511; -- Shadowed Spirit
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 14511; -- Shadowed Spirit
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 14512; -- Corrupted Spirit
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 14513; -- Malicious Spirit
UPDATE creature_template SET HealthMultiplier = 105.0 WHERE Entry = 14515; -- High Priestess Arlokk
UPDATE creature_template SET PowerMultiplier = 5.0 WHERE Entry = 14515; -- High Priestess Arlokk
UPDATE creature_template SET HealthMultiplier = 15.0 WHERE Entry = 14516; -- Death Knight Darkreaver
UPDATE creature_template SET PowerMultiplier = 4.0 WHERE Entry = 14516; -- Death Knight Darkreaver
UPDATE creature_template SET PowerMultiplier = 10.0 WHERE Entry = 14517; -- High Priestess Jeklik
UPDATE creature_template SET HealthMultiplier = 6.0 WHERE Entry = 14518; -- Aspect of Banality
UPDATE creature_template SET PowerMultiplier = 4.0 WHERE Entry = 14518; -- Aspect of Banality
UPDATE creature_template SET HealthMultiplier = 6.0 WHERE Entry = 14520; -- Aspect of Malice
UPDATE creature_template SET HealthMultiplier = 6.0 WHERE Entry = 14521; -- Aspect of Shadow
UPDATE creature_template SET PowerMultiplier = 4.0 WHERE Entry = 14521; -- Aspect of Shadow
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 14523; -- Ulathek
UPDATE creature_template SET PowerMultiplier = 5.0 WHERE Entry = 14527; -- Simone the Inconspicuous
UPDATE creature_template SET HealthMultiplier = 8.0 WHERE Entry = 14531; -- Artorius the Amiable
UPDATE creature_template SET HealthMultiplier = 4.0 WHERE Entry = 14532; -- Razzashi Venombrood
UPDATE creature_template SET HealthMultiplier = 8.0 WHERE Entry = 14535; -- Artorius the Doombringer
UPDATE creature_template SET PowerMultiplier = 5.0 WHERE Entry = 14536; -- Nelson the Nice
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 14538; -- Precious the Devourer
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 14564; -- Terrordale Spirit
UPDATE creature_template SET HealthMultiplier = 300.0 WHERE Entry = 14601; -- Ebonroc
UPDATE creature_template SET HealthMultiplier = 2.0 WHERE Entry = 14605; -- Bone Construct
UPDATE creature_template SET HealthMultiplier = 0.98 WHERE Entry = 14662; -- Corrupted Fire Nova Totem V
UPDATE creature_template SET HealthMultiplier = 9.0 WHERE Entry = 14682; -- Sever
UPDATE creature_template SET HealthMultiplier = 10.0 WHERE Entry = 14695; -- Lord Blackwood
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 14715; -- Silverwing Elite
UPDATE creature_template SET HealthMultiplier = 1.25 WHERE Entry = 14748; -- Vilebranch Kidnapper
UPDATE creature_template SET HealthMultiplier = 10.0 WHERE Entry = 14750; -- Gurubashi Bat Rider
UPDATE creature_template SET HealthMultiplier = 20.25 WHERE Entry = 14762; -- Dun Baldar North Marshal
UPDATE creature_template SET HealthMultiplier = 50.0 WHERE Entry = 14781; -- Captain Shatterskull
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 14821; -- Razzashi Raptor
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 14825; -- Withered Mistress
UPDATE creature_template SET PowerMultiplier = 4.0 WHERE Entry = 14825; -- Withered Mistress
UPDATE creature_template SET HealthMultiplier = 0.25 WHERE Entry = 14826; -- Sacrificed Troll
UPDATE creature_template SET HealthMultiplier = 405.0 WHERE Entry = 14834; -- Hakkar
UPDATE creature_template SET PowerMultiplier = 100.0 WHERE Entry = 14834; -- Hakkar
UPDATE creature_template SET HealthMultiplier = 6.0 WHERE Entry = 14861; -- Blood Steward of Kirtonos
UPDATE creature_template SET PowerMultiplier = 6.0 WHERE Entry = 14861; -- Blood Steward of Kirtonos
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 14862; -- Emissary Roman'khan
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 14862; -- Emissary Roman'khan
UPDATE creature_template SET HealthMultiplier = 1.5 WHERE Entry = 14880; -- Razzashi Skitterer
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 14882; -- Atal'ai Mistress
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 14883; -- Voodoo Slave
UPDATE creature_template SET PowerMultiplier = 4.0 WHERE Entry = 14883; -- Voodoo Slave
UPDATE creature_template SET HealthMultiplier = 250.0 WHERE Entry = 14887; -- Ysondre
UPDATE creature_template SET HealthMultiplier = 250.0 WHERE Entry = 14888; -- Lethon
UPDATE creature_template SET HealthMultiplier = 250.0 WHERE Entry = 14889; -- Emeriss
UPDATE creature_template SET HealthMultiplier = 250.0 WHERE Entry = 14890; -- Taerar
UPDATE creature_template SET HealthMultiplier = 0.5 WHERE Entry = 14986; -- Shade of Jin'do
UPDATE creature_template SET HealthMultiplier = 7.0 WHERE Entry = 15067; -- Zulian Stalker
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 15080; -- Servant of the Hand
UPDATE creature_template SET HealthMultiplier = 100.0 WHERE Entry = 15082; -- Gri'lek
UPDATE creature_template SET HealthMultiplier = 100.0 WHERE Entry = 15083; -- Hazza'rah
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 15083; -- Hazza'rah
UPDATE creature_template SET HealthMultiplier = 100.0 WHERE Entry = 15084; -- Renataki
UPDATE creature_template SET HealthMultiplier = 110.0 WHERE Entry = 15085; -- Wushoolay
UPDATE creature_template SET PowerMultiplier = 12.0 WHERE Entry = 15085; -- Wushoolay
UPDATE creature_template SET PowerMultiplier = 4.0 WHERE Entry = 15111; -- Mad Servant
UPDATE creature_template SET HealthMultiplier = 100.0 WHERE Entry = 15114; -- Gahz'ranka
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 15162; -- Scarlet Inquisitor
UPDATE creature_template SET PowerMultiplier = 1.0 WHERE Entry = 15191; -- Windcaller Proudhorn
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 15196; -- Deathclasp
UPDATE creature_template SET HealthMultiplier = 1.45 WHERE Entry = 15200; -- Twilight Keeper Mayna
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 15201; -- Twilight Flamereaver
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 15202; -- Vyral the Vile
UPDATE creature_template SET HealthMultiplier = 26.0 WHERE Entry = 15229; -- Vekniss Soldier
UPDATE creature_template SET HealthMultiplier = 20.0 WHERE Entry = 15233; -- Vekniss Guardian
UPDATE creature_template SET HealthMultiplier = 20.0 WHERE Entry = 15235; -- Vekniss Stinger
UPDATE creature_template SET HealthMultiplier = 10.0 WHERE Entry = 15236; -- Vekniss Wasp
UPDATE creature_template SET HealthMultiplier = 30.0 WHERE Entry = 15240; -- Vekniss Hive Crawler
UPDATE creature_template SET HealthMultiplier = 40.0 WHERE Entry = 15246; -- Qiraji Mindslayer
UPDATE creature_template SET HealthMultiplier = 25.0 WHERE Entry = 15247; -- Qiraji Brainwasher
UPDATE creature_template SET HealthMultiplier = 30.0 WHERE Entry = 15249; -- Qiraji Lasher
UPDATE creature_template SET HealthMultiplier = 40.0 WHERE Entry = 15250; -- Qiraji Slayer
UPDATE creature_template SET HealthMultiplier = 80.0 WHERE Entry = 15252; -- Qiraji Champion
UPDATE creature_template SET PowerMultiplier = 10.0 WHERE Entry = 15262; -- Obsidian Eradicator
UPDATE creature_template SET HealthMultiplier = 175.0 WHERE Entry = 15263; -- The Prophet Skeram
UPDATE creature_template SET PowerMultiplier = 150.0 WHERE Entry = 15263; -- The Prophet Skeram
UPDATE creature_template SET HealthMultiplier = 35.0 WHERE Entry = 15264; -- Anubisath Sentinel
UPDATE creature_template SET HealthMultiplier = 650.0 WHERE Entry = 15275; -- Emperor Vek'nilash
UPDATE creature_template SET HealthMultiplier = 650.0 WHERE Entry = 15276; -- Emperor Vek'lor
UPDATE creature_template SET PowerMultiplier = 180.0 WHERE Entry = 15276; -- Emperor Vek'lor
UPDATE creature_template SET HealthMultiplier = 150.0 WHERE Entry = 15277; -- Anubisath Defender
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 15293; -- Aendel Windspear
UPDATE creature_template SET HealthMultiplier = 600.0 WHERE Entry = 15299; -- Viscidus
UPDATE creature_template SET HealthMultiplier = 2.0 WHERE Entry = 15300; -- Vekniss Drone
UPDATE creature_template SET HealthMultiplier = 3.45 WHERE Entry = 15308; -- Twilight Prophet
UPDATE creature_template SET PowerMultiplier = 2.0 WHERE Entry = 15308; -- Twilight Prophet
UPDATE creature_template SET HealthMultiplier = 90.0 WHERE Entry = 15311; -- Anubisath Warder
UPDATE creature_template SET PowerMultiplier = 21.0 WHERE Entry = 15312; -- Obsidian Nullifier
UPDATE creature_template SET HealthMultiplier = 4.0 WHERE Entry = 15318; -- Hive'Zara Drone
UPDATE creature_template SET HealthMultiplier = 8.0 WHERE Entry = 15319; -- Hive'Zara Collector
UPDATE creature_template SET HealthMultiplier = 10.0 WHERE Entry = 15320; -- Hive'Zara Soldier
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 15323; -- Hive'Zara Sandstalker
UPDATE creature_template SET HealthMultiplier = 16.0 WHERE Entry = 15324; -- Qiraji Gladiator
UPDATE creature_template SET HealthMultiplier = 8.0 WHERE Entry = 15325; -- Hive'Zara Wasp
UPDATE creature_template SET HealthMultiplier = 16.0 WHERE Entry = 15327; -- Hive'Zara Stinger
UPDATE creature_template SET HealthMultiplier = 16.0 WHERE Entry = 15335; -- Flesh Hunter
UPDATE creature_template SET HealthMultiplier = 9.0 WHERE Entry = 15336; -- Hive'Zara Tail Lasher
UPDATE creature_template SET HealthMultiplier = 20.0 WHERE Entry = 15338; -- Obsidian Destroyer
UPDATE creature_template SET HealthMultiplier = 150.0 WHERE Entry = 15339; -- Ossirian the Unscarred
UPDATE creature_template SET HealthMultiplier = 130.0 WHERE Entry = 15340; -- Moam
UPDATE creature_template SET HealthMultiplier = 125.0 WHERE Entry = 15341; -- General Rajaxx
UPDATE creature_template SET HealthMultiplier = 8.0 WHERE Entry = 15343; -- Qiraji Swarmguard
UPDATE creature_template SET HealthMultiplier = 4.0 WHERE Entry = 15344; -- Swarmguard Needler
UPDATE creature_template SET HealthMultiplier = 100.0 WHERE Entry = 15348; -- Kurinnaxx
UPDATE creature_template SET HealthMultiplier = 19.0 WHERE Entry = 15355; -- Anubisath Guardian
UPDATE creature_template SET HealthMultiplier = 100.0 WHERE Entry = 15369; -- Ayamiss the Hunter
UPDATE creature_template SET HealthMultiplier = 250.0 WHERE Entry = 15370; -- Buru the Gorger
UPDATE creature_template SET PowerMultiplier = 30.0 WHERE Entry = 15378; -- Merithra of the Dream
UPDATE creature_template SET PowerMultiplier = 30.0 WHERE Entry = 15379; -- Caelestrasz
UPDATE creature_template SET HealthMultiplier = 600.0 WHERE Entry = 15380; -- Arygos
UPDATE creature_template SET PowerMultiplier = 30.0 WHERE Entry = 15380; -- Arygos
UPDATE creature_template SET HealthMultiplier = 0.3 WHERE Entry = 15383; -- Sergeant Stonebrow
UPDATE creature_template SET HealthMultiplier = 17.0 WHERE Entry = 15385; -- Colonel Zerran
UPDATE creature_template SET HealthMultiplier = 17.0 WHERE Entry = 15386; -- Major Yeggeth
UPDATE creature_template SET HealthMultiplier = 10.0 WHERE Entry = 15387; -- Qiraji Warrior
UPDATE creature_template SET HealthMultiplier = 17.0 WHERE Entry = 15388; -- Major Pakkon
UPDATE creature_template SET HealthMultiplier = 17.0 WHERE Entry = 15389; -- Captain Drenn
UPDATE creature_template SET HealthMultiplier = 17.0 WHERE Entry = 15390; -- Captain Xurrem
UPDATE creature_template SET HealthMultiplier = 17.0 WHERE Entry = 15391; -- Captain Qeez
UPDATE creature_template SET HealthMultiplier = 17.0 WHERE Entry = 15392; -- Captain Tuubid
UPDATE creature_template SET HealthMultiplier = 10.0 WHERE Entry = 15424; -- Anubisath Conqueror
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 15426; -- Ahn'Qiraj Trigger
UPDATE creature_template SET PowerMultiplier = 5.0 WHERE Entry = 15443; -- Janela Stouthammer
UPDATE creature_template SET PowerMultiplier = 5.0 WHERE Entry = 15444; -- Arcanist Nozzlespring
UPDATE creature_template SET HealthMultiplier = 50.0 WHERE Entry = 15449; -- Hive'Zora Abomination
UPDATE creature_template SET HealthMultiplier = 0.3 WHERE Entry = 15451; -- Sentinel Silversky
UPDATE creature_template SET HealthMultiplier = 0.3 WHERE Entry = 15455; -- Slicky Gastronome
UPDATE creature_template SET HealthMultiplier = 0.3 WHERE Entry = 15459; -- Miner Cromwell
UPDATE creature_template SET HealthMultiplier = 4.0 WHERE Entry = 15461; -- Shrieker Scarab
UPDATE creature_template SET HealthMultiplier = 800.0 WHERE Entry = 15491; -- Eranikus, Tyrant of the Dream
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 15505; -- Canal Frenzy
UPDATE creature_template SET HealthMultiplier = 300.0 WHERE Entry = 15509; -- Princess Huhuran
UPDATE creature_template SET HealthMultiplier = 300.0 WHERE Entry = 15510; -- Fankriss the Unyielding
UPDATE creature_template SET HealthMultiplier = 80.0 WHERE Entry = 15511; -- Lord Kri
UPDATE creature_template SET HealthMultiplier = 225.0 WHERE Entry = 15516; -- Battleguard Sartura
UPDATE creature_template SET HealthMultiplier = 600.0 WHERE Entry = 15517; -- Ouro
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 15521; -- Hive'Zara Hatchling
UPDATE creature_template SET HealthMultiplier = 0.3 WHERE Entry = 15533; -- Bloodguard Rawtar
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 15535; -- Chief Sharpclaw
UPDATE creature_template SET HealthMultiplier = 0.59 WHERE Entry = 15539; -- General Zog
UPDATE creature_template SET HealthMultiplier = 3.45 WHERE Entry = 15541; -- Twilight Marauder Morna
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 15542; -- Twilight Marauder
UPDATE creature_template SET HealthMultiplier = 90.0 WHERE Entry = 15543; -- Princess Yauj
UPDATE creature_template SET HealthMultiplier = 130.0 WHERE Entry = 15544; -- Vem
UPDATE creature_template SET HealthMultiplier = 0.1 WHERE Entry = 15546; -- Hive'Zara Swarmer
UPDATE creature_template SET PowerMultiplier = 80.0 WHERE Entry = 15552; -- Doctor Weavil
UPDATE creature_template SET HealthMultiplier = 25.0 WHERE Entry = 15554; -- Number Two
UPDATE creature_template SET HealthMultiplier = 1.0 WHERE Entry = 15555; -- Hive'Zara Larva
UPDATE creature_template SET HealthMultiplier = 350.0 WHERE Entry = 15571; -- Maws
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 15590; -- Ossirian Crystal Trigger
UPDATE creature_template SET HealthMultiplier = 8.0 WHERE Entry = 15591; -- Minion of Weavil
UPDATE creature_template SET PowerMultiplier = 5.0 WHERE Entry = 15613; -- Merok Longstride
UPDATE creature_template SET PowerMultiplier = 5.0 WHERE Entry = 15615; -- Shadow Priestess Shai
UPDATE creature_template SET HealthMultiplier = 50.0 WHERE Entry = 15620; -- Hive'Regal Hunter-Killer
UPDATE creature_template SET HealthMultiplier = 8.0 WHERE Entry = 15623; -- Xandivious
UPDATE creature_template SET PowerMultiplier = 3.0 WHERE Entry = 15623; -- Xandivious
UPDATE creature_template SET HealthMultiplier = 18.0 WHERE Entry = 15629; -- Nightmare Phantasm
UPDATE creature_template SET HealthMultiplier = 10.0 WHERE Entry = 15630; -- Spawn of Fankriss
UPDATE creature_template SET PowerMultiplier = 25.0 WHERE Entry = 15634; -- Priestess of the Moon
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 15685; -- Southsea Kidnapper
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 15695; -- Vek Twins Trigger
UPDATE creature_template SET HealthMultiplier = 0.4 WHERE Entry = 15696; -- War Effort Recruit
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 15702; -- Senior Sergeant Taiga
UPDATE creature_template SET HealthMultiplier = 300.0 WHERE Entry = 15727; -- C'Thun
UPDATE creature_template SET HealthMultiplier = 1000.0 WHERE Entry = 15740; -- Colossus of Zora
UPDATE creature_template SET HealthMultiplier = 1000.0 WHERE Entry = 15741; -- Colossus of Regal
UPDATE creature_template SET HealthMultiplier = 1000.0 WHERE Entry = 15742; -- Colossus of Ashi
UPDATE creature_template SET HealthMultiplier = 0.4 WHERE Entry = 15749; -- Lesser Silithid Flayer
UPDATE creature_template SET HealthMultiplier = 8.0 WHERE Entry = 15751; -- Anubisath Warbringer
UPDATE creature_template SET HealthMultiplier = 2.0 WHERE Entry = 15752; -- Silithid Flayer
UPDATE creature_template SET HealthMultiplier = 10.0 WHERE Entry = 15754; -- Greater Anubisath Warbringer
UPDATE creature_template SET HealthMultiplier = 9.0 WHERE Entry = 15775; -- Christmas Emperor Dagran Thaurissan
UPDATE creature_template SET HealthMultiplier = 0.35 WHERE Entry = 15815; -- Qiraji Captain Ka'ark
UPDATE creature_template SET HealthMultiplier = 20.0 WHERE Entry = 15863; -- Darkspear Shaman
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 15882; -- Pat's Firework Guy - RED
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 15883; -- Pat's Firework Guy - YELLOW
UPDATE creature_template SET HealthMultiplier = 2.19 WHERE Entry = 15892; -- Lunar Festival Emissary
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 15893; -- Lunar Firework Credit Marker
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 15894; -- Lunar Cluster Credit Marker
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 15902; -- Giant Spotlight
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 15918; -- Pat's Firework Cluster Guy (ELUNE)
UPDATE creature_template SET HealthMultiplier = 150.0 WHERE Entry = 15929; -- Stalagg
UPDATE creature_template SET HealthMultiplier = 150.0 WHERE Entry = 15930; -- Feugen
UPDATE creature_template SET HealthMultiplier = 650.0 WHERE Entry = 15931; -- Grobbulus
UPDATE creature_template SET HealthMultiplier = 500.0 WHERE Entry = 15932; -- Gluth
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 15933; -- Poison Cloud
UPDATE creature_template SET HealthMultiplier = 15.0 WHERE Entry = 15934; -- Hive'Zara Hornet
UPDATE creature_template SET HealthMultiplier = 550.0 WHERE Entry = 15936; -- Heigan the Unclean
UPDATE creature_template SET HealthMultiplier = 450.0 WHERE Entry = 15952; -- Maexxna
UPDATE creature_template SET HealthMultiplier = 400.0 WHERE Entry = 15953; -- Grand Widow Faerlina
UPDATE creature_template SET HealthMultiplier = 500.0 WHERE Entry = 15956; -- Anub'Rekhan
UPDATE creature_template SET HealthMultiplier = 15.0 WHERE Entry = 15974; -- Dread Creeper
UPDATE creature_template SET HealthMultiplier = 18.0 WHERE Entry = 15975; -- Carrion Spinner
UPDATE creature_template SET HealthMultiplier = 30.0 WHERE Entry = 15976; -- Venom Stalker
UPDATE creature_template SET HealthMultiplier = 45.0 WHERE Entry = 15978; -- Crypt Reaver
UPDATE creature_template SET HealthMultiplier = 35.0 WHERE Entry = 15979; -- Tomb Horror
UPDATE creature_template SET HealthMultiplier = 12.0 WHERE Entry = 15980; -- Naxxramas Cultist
UPDATE creature_template SET PowerMultiplier = 10.0 WHERE Entry = 15980; -- Naxxramas Cultist
UPDATE creature_template SET HealthMultiplier = 12.0 WHERE Entry = 15981; -- Naxxramas Acolyte
UPDATE creature_template SET PowerMultiplier = 10.0 WHERE Entry = 15981; -- Naxxramas Acolyte
UPDATE creature_template SET HealthMultiplier = 30.0 WHERE Entry = 15984; -- Sartura's Royal Guard
UPDATE creature_template SET HealthMultiplier = 950.0 WHERE Entry = 15989; -- Sapphiron
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 16006; -- InCombat Trigger
UPDATE creature_template SET HealthMultiplier = 1600.0 WHERE Entry = 16011; -- Loatheb
UPDATE creature_template SET HealthMultiplier = 2.06 WHERE Entry = 16013; -- Deliana
UPDATE creature_template SET HealthMultiplier = 28.0 WHERE Entry = 16017; -- Patchwork Golem
UPDATE creature_template SET HealthMultiplier = 34.0 WHERE Entry = 16018; -- Bile Retcher
UPDATE creature_template SET HealthMultiplier = 14.0 WHERE Entry = 16021; -- Living Monstrosity
UPDATE creature_template SET HealthMultiplier = 14.0 WHERE Entry = 16022; -- Surgical Assistant
UPDATE creature_template SET HealthMultiplier = 4.0 WHERE Entry = 16024; -- Embalming Slime
UPDATE creature_template SET HealthMultiplier = 45.0 WHERE Entry = 16025; -- Stitched Spewer
UPDATE creature_template SET HealthMultiplier = 9.0 WHERE Entry = 16027; -- Living Poison
UPDATE creature_template SET HealthMultiplier = 1200.0 WHERE Entry = 16028; -- Patchwerk
UPDATE creature_template SET HealthMultiplier = 25.0 WHERE Entry = 16029; -- Sludge Belcher
UPDATE creature_template SET HealthMultiplier = 18.0 WHERE Entry = 16034; -- Plague Beast
UPDATE creature_template SET HealthMultiplier = 3.5 WHERE Entry = 16036; -- Frenzied Bat
UPDATE creature_template SET HealthMultiplier = 3.5 WHERE Entry = 16037; -- Plagued Bat
UPDATE creature_template SET HealthMultiplier = 45.0 WHERE Entry = 16042; -- Lord Valthalak
UPDATE creature_template SET PowerMultiplier = 1.33 WHERE Entry = 16051; -- Snokh Blackspine
UPDATE creature_template SET HealthMultiplier = 3.5 WHERE Entry = 16052; -- Malgen Longspear
UPDATE creature_template SET PowerMultiplier = 2.24 WHERE Entry = 16052; -- Malgen Longspear
UPDATE creature_template SET HealthMultiplier = 3.5 WHERE Entry = 16053; -- Korv
UPDATE creature_template SET PowerMultiplier = 2.24 WHERE Entry = 16053; -- Korv
UPDATE creature_template SET HealthMultiplier = 3.5 WHERE Entry = 16055; -- Va'jashni
UPDATE creature_template SET PowerMultiplier = 1.33 WHERE Entry = 16055; -- Va'jashni
UPDATE creature_template SET HealthMultiplier = 3.5 WHERE Entry = 16058; -- Volida
UPDATE creature_template SET PowerMultiplier = 1.33 WHERE Entry = 16058; -- Volida
UPDATE creature_template SET HealthMultiplier = 3.5 WHERE Entry = 16059; -- Theldren
UPDATE creature_template SET HealthMultiplier = 150.0 WHERE Entry = 16060; -- Gothik the Harvester
UPDATE creature_template SET PowerMultiplier = 100.0 WHERE Entry = 16060; -- Gothik the Harvester
UPDATE creature_template SET HealthMultiplier = 600.0 WHERE Entry = 16061; -- Instructor Razuvious
UPDATE creature_template SET HealthMultiplier = 160.0 WHERE Entry = 16062; -- Highlord Mograine
UPDATE creature_template SET HealthMultiplier = 150.0 WHERE Entry = 16063; -- Sir Zeliek
UPDATE creature_template SET HealthMultiplier = 150.0 WHERE Entry = 16065; -- Lady Blaumeux
UPDATE creature_template SET HealthMultiplier = 0.5 WHERE Entry = 16066; -- Spectral Assassin
UPDATE creature_template SET HealthMultiplier = 14.0 WHERE Entry = 16067; -- Deathcharger Steed
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 16072; -- Tidelord Rrurgaz
UPDATE creature_template SET HealthMultiplier = 1.8 WHERE Entry = 16096; -- Steamwheedle Bruiser
UPDATE creature_template SET HealthMultiplier = 10.0 WHERE Entry = 16097; -- Isalien
UPDATE creature_template SET PowerMultiplier = 15.0 WHERE Entry = 16097; -- Isalien
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 16098; -- Empyrean
UPDATE creature_template SET HealthMultiplier = 6.0 WHERE Entry = 16102; -- Sothos
UPDATE creature_template SET PowerMultiplier = 15.0 WHERE Entry = 16102; -- Sothos
UPDATE creature_template SET HealthMultiplier = 2.0 WHERE Entry = 16103; -- Spirit of Jarien
UPDATE creature_template SET PowerMultiplier = 15.0 WHERE Entry = 16103; -- Spirit of Jarien
UPDATE creature_template SET HealthMultiplier = 2.0 WHERE Entry = 16104; -- Spirit of Sothos
UPDATE creature_template SET PowerMultiplier = 15.0 WHERE Entry = 16104; -- Spirit of Sothos
UPDATE creature_template SET PowerMultiplier = 100.0 WHERE Entry = 16113; -- Father Inigo Montoy
UPDATE creature_template SET PowerMultiplier = 4.0 WHERE Entry = 16114; -- Scarlet Commander Marjhan
UPDATE creature_template SET PowerMultiplier = 5.0 WHERE Entry = 16115; -- Commander Eligor Dawnbringer
UPDATE creature_template SET PowerMultiplier = 30.0 WHERE Entry = 16116; -- Archmage Angela Dosantos
UPDATE creature_template SET HealthMultiplier = 1.3 WHERE Entry = 16117; -- Plagued Swine
UPDATE creature_template SET HealthMultiplier = 0.5 WHERE Entry = 16119; -- Bone Minion
UPDATE creature_template SET HealthMultiplier = 6.5 WHERE Entry = 16125; -- Unrelenting Deathknight
UPDATE creature_template SET HealthMultiplier = 10.0 WHERE Entry = 16126; -- Unrelenting Rider
UPDATE creature_template SET PowerMultiplier = 5.0 WHERE Entry = 16126; -- Unrelenting Rider
UPDATE creature_template SET PowerMultiplier = 4.0 WHERE Entry = 16132; -- Huntsman Leopold
UPDATE creature_template SET PowerMultiplier = 4.0 WHERE Entry = 16133; -- Mataus the Wrathcaster
UPDATE creature_template SET PowerMultiplier = 4.0 WHERE Entry = 16134; -- Rimblat Earthshatter
UPDATE creature_template SET PowerMultiplier = 4.0 WHERE Entry = 16135; -- Rayne
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 16141; -- Ghoul Berserker
UPDATE creature_template SET HealthMultiplier = 30.0 WHERE Entry = 16145; -- Deathknight Captain
UPDATE creature_template SET HealthMultiplier = 24.0 WHERE Entry = 16146; -- Deathknight
UPDATE creature_template SET HealthMultiplier = 5.0 WHERE Entry = 16148; -- Spectral Deathknight
UPDATE creature_template SET HealthMultiplier = 3.0 WHERE Entry = 16150; -- Spectral Rider
UPDATE creature_template SET HealthMultiplier = 8.0 WHERE Entry = 16154; -- Risen Deathknight
UPDATE creature_template SET HealthMultiplier = 8.0 WHERE Entry = 16157; -- Doom Touched Warrior
UPDATE creature_template SET HealthMultiplier = 45.0 WHERE Entry = 16163; -- Deathknight Cavalier
UPDATE creature_template SET PowerMultiplier = 5.0 WHERE Entry = 16163; -- Deathknight Cavalier
UPDATE creature_template SET HealthMultiplier = 18.0 WHERE Entry = 16165; -- Necro Knight
UPDATE creature_template SET PowerMultiplier = 18.0 WHERE Entry = 16165; -- Necro Knight
UPDATE creature_template SET HealthMultiplier = 12.0 WHERE Entry = 16167; -- Bony Construct
UPDATE creature_template SET HealthMultiplier = 6.0 WHERE Entry = 16184; -- Nerubian Overseer
UPDATE creature_template SET HealthMultiplier = 16.0 WHERE Entry = 16193; -- Skeletal Smith
UPDATE creature_template SET HealthMultiplier = 36.0 WHERE Entry = 16194; -- Unholy Axe
UPDATE creature_template SET HealthMultiplier = 28.0 WHERE Entry = 16215; -- Unholy Staff
UPDATE creature_template SET HealthMultiplier = 30.0 WHERE Entry = 16216; -- Unholy Swords
UPDATE creature_template SET HealthMultiplier = 45.0 WHERE Entry = 16243; -- Plague Slime
UPDATE creature_template SET HealthMultiplier = 30.0 WHERE Entry = 16244; -- Infectious Ghoul
UPDATE creature_template SET PowerMultiplier = 4.0 WHERE Entry = 16284; -- Argent Medic
UPDATE creature_template SET HealthMultiplier = 16.0 WHERE Entry = 16290; -- Fallout Slime
UPDATE creature_template SET HealthMultiplier = 8.0 WHERE Entry = 16297; -- Mutated Grub
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 16299; -- Skeletal Shocktrooper
UPDATE creature_template SET HealthMultiplier = 2.0 WHERE Entry = 16359; -- Argent Messenger
UPDATE creature_template SET HealthMultiplier = 25.0 WHERE Entry = 16368; -- Necropolis Acolyte
UPDATE creature_template SET PowerMultiplier = 10.0 WHERE Entry = 16368; -- Necropolis Acolyte
UPDATE creature_template SET HealthMultiplier = 50.0 WHERE Entry = 16375; -- Sewage Slime
UPDATE creature_template SET HealthMultiplier = 2.5 WHERE Entry = 16379; -- Spirit of the Damned
UPDATE creature_template SET HealthMultiplier = 2.5 WHERE Entry = 16380; -- Bone Witch
UPDATE creature_template SET HealthMultiplier = 1.2 WHERE Entry = 16399; -- Bloodsail Traitor
UPDATE creature_template SET HealthMultiplier = 500.0 WHERE Entry = 16441; -- Guardian of Icecrown
UPDATE creature_template SET HealthMultiplier = 30.0 WHERE Entry = 16447; -- Plagued Ghoul
UPDATE creature_template SET HealthMultiplier = 22.0 WHERE Entry = 16448; -- Plagued Deathhound
UPDATE creature_template SET HealthMultiplier = 35.0 WHERE Entry = 16449; -- Spirit of Naxxramas
UPDATE creature_template SET HealthMultiplier = 26.0 WHERE Entry = 16453; -- Necro Stalker
UPDATE creature_template SET HealthMultiplier = 0.2 WHERE Entry = 16479; -- Polymorph Clone
UPDATE creature_template SET HealthMultiplier = 40.0 WHERE Entry = 16506; -- Naxxramas Worshipper
UPDATE creature_template SET PowerMultiplier = 10.0 WHERE Entry = 16506; -- Naxxramas Worshipper
UPDATE creature_template SET HealthMultiplier = 65.0 WHERE Entry = 16573; -- Crypt Guard
UPDATE creature_template SET HealthMultiplier = 30.0 WHERE Entry = 16803; -- Deathknight Understudy
UPDATE creature_template SET HealthMultiplier = 1.35 WHERE Entry = 16980; -- The Lich King
UPDATE creature_template SET HealthMultiplier = 8.0 WHERE Entry = 16981; -- Plagued Guardian
UPDATE creature_template SET PowerMultiplier = 18.0 WHERE Entry = 16981; -- Plagued Guardian
UPDATE creature_template SET HealthMultiplier = 0.8 WHERE Entry = 17055; -- Maexxna Spiderling
UPDATE creature_template SET HealthMultiplier = 0.45 WHERE Entry = 17252; -- Felguard


UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3; -- Flesh Eater
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 79; -- Narg the Taskmaster
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 92; -- Rock Elemental
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 193; -- Blue Dragonspawn
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 202; -- Skeletal Horror
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 206; -- Nightbane Vile Fang
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 212; -- Splinter Fist Warrior
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 215; -- Defias Night Runner
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 228; -- Avette Fellwood
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 232; -- Farmer Ray
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 268; -- Sirra Von'Indi
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 334; -- Gath'Ilzogg
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 335; -- Singe
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 412; -- Stitches
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 431; -- Shadowhide Slayer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 432; -- Shadowhide Brute
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 435; -- Blackrock Champion
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 448; -- Hogger
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 469; -- Lieutenant Doren
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 503; -- Lord Malathrom
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 514; -- Smith Argus
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 521; -- Lupos
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 531; -- Skeletal Fiend
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 568; -- Shadowhide Warrior
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 574; -- Naraxis
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 579; -- Shadowhide Assassin
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 587; -- Bloodscalp Warrior
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 604; -- Plague Spreader
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 615; -- Blackrock Tracker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 616; -- Chatter
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 622; -- Goblin Engineer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 628; -- Black Ravager
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 634; -- Defias Overseer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 642; -- Sneed's Shredder
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 643; -- Sneed
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 644; -- Rhahk'Zor
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 645; -- Cookie
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 646; -- Mr. Smite
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 660; -- Bloodscalp Witch Doctor
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 667; -- Skullsplitter Warrior
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 669; -- Skullsplitter Hunter
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 670; -- Skullsplitter Witch Doctor
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 672; -- Skullsplitter Spiritchaser
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 674; -- Venture Co. Strip Miner
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 675; -- Venture Co. Foreman
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 676; -- Venture Co. Surveyor
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 682; -- Stranglethorn Tiger
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 684; -- Shadowmaw Panther
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 685; -- Stranglethorn Raptor
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 686; -- Lashtail Raptor
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 687; -- Jungle Stalker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 690; -- Cold Eye Basilisk
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 694; -- Bloodscalp Axe Thrower
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 696; -- Skullsplitter Axe Thrower
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 697; -- Bloodscalp Shaman
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 701; -- Bloodscalp Mystic
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 736; -- Panther
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 741; -- Dreaming Whelp
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 750; -- Marsh Inkspewer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 751; -- Marsh Flesheater
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 757; -- Lost One Fisherman
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 761; -- Lost One Seer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 763; -- Lost One Chieftain
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 768; -- Shadow Panther
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 769; -- Deathstrike Tarantula
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 771; -- Commander Felstrom
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 772; -- Stranglethorn Tigress
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 775; -- Kurzen's Agent
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 780; -- Skullsplitter Mystic
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 781; -- Skullsplitter Headhunter
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 782; -- Skullsplitter Scout
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 783; -- Skullsplitter Berserker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 784; -- Skullsplitter Beastmaster
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 822; -- Young Forest Bear
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 856; -- Young Lashtail Raptor
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 889; -- Splinter Fist Ogre
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 891; -- Splinter Fist Fire Weaver
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 892; -- Splinter Fist Taskmaster
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 909; -- Defias Night Blade
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 910; -- Defias Enchanter
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 920; -- Nightbane Tainted One
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 922; -- Silt Crawler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 923; -- Young Black Ravager
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 930; -- Black Widow Hatchling
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 937; -- Kurzen Jungle Fighter
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 940; -- Kurzen Medicine Man
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 941; -- Kurzen Headshrinker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 943; -- Kurzen Wrangler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 948; -- Rotted One
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 949; -- Carrion Recluse
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 950; -- Swamp Talker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 976; -- Kurzen War Tiger
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 977; -- Kurzen War Panther
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1011; -- Mosshide Trapper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1012; -- Mosshide Brute
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1014; -- Mosshide Alpha
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1015; -- Highland Raptor
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1016; -- Highland Lashtail
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1017; -- Highland Scytheclaw
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1018; -- Highland Razormaw
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1019; -- Elder Razormaw
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1021; -- Mottled Screecher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1022; -- Mottled Scytheclaw
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1027; -- Bluegill Warrior
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1028; -- Bluegill Muckdweller
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1031; -- Crimson Ooze
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1032; -- Black Ooze
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1033; -- Monstrous Ooze
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1040; -- Fen Creeper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1041; -- Fen Lord
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1042; -- Red Whelp
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1045; -- Red Dragonspawn
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1046; -- Red Wyrmkin
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1047; -- Red Scalebane
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1048; -- Scalebane Lieutenant
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1049; -- Wyrmkin Firebrand
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1050; -- Scalebane Royal Guard
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1059; -- Ana'thek the Cruel
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1060; -- Mogh the Undying
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1062; -- Nezzliok the Dire
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1081; -- Mire Lord
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1082; -- Sawtooth Crocolisk
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1084; -- Young Sawtooth Crocolisk
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1087; -- Sawtooth Snapper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1106; -- Lost One Cook
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1108; -- Mistvale Gorilla
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1110; -- Skeletal Raider
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1112; -- Leech Widow
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1114; -- Jungle Thunderer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1151; -- Saltwater Crocolisk
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1152; -- Snapjaw Crocolisk
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1159; -- First Mate Snellig
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1160; -- Captain Halyndor
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1200; -- Morbent Fel
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1210; -- Chok'sul
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1258; -- Black Ravager Mastiff
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1270; -- Fetid Corpse
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1271; -- Old Icebeard
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1353; -- Sarltooth
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1400; -- Wetlands Crocolisk
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1411; -- Ian Strom
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1466; -- Gretta Finespindle
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1475; -- Menethil Guard
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1511; -- Enraged Silverback Gorilla
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1514; -- Mokk the Savage
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1516; -- Konda
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1550; -- Thrashtail Basilisk
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1551; -- Ironjaw Basilisk
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1552; -- Scale Belly
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1557; -- Elder Mistvale Gorilla
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1558; -- Silverback Patriarch
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1652; -- Deathguard Burgess
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1702; -- Bronk Guzzlegear
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1703; -- Uthrar Threx
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1713; -- Elder Shadowmaw Panther
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1731; -- Goblin Craftsman
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1744; -- Deathguard Mort
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1763; -- Gilnid
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1783; -- Skeletal Flayer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1784; -- Skeletal Sorcerer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1785; -- Skeletal Terror
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1789; -- Skeletal Acolyte
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1791; -- Slavering Ghoul
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1793; -- Rotting Ghoul
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1794; -- Soulless Ghoul
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1796; -- Freezing Ghoul
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1802; -- Hungering Wraith
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1804; -- Wailing Death
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1805; -- Flesh Golem
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1806; -- Vile Slime
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1808; -- Devouring Ooze
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1809; -- Carrion Vulture
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1812; -- Rotting Behemoth
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1815; -- Diseased Black Bear
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1816; -- Diseased Grizzly
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1817; -- Diseased Wolf
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1821; -- Carrion Lurker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1822; -- Venom Mist Lurker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1824; -- Plague Lurker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1831; -- Scarlet Hunter
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1833; -- Scarlet Knight
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1835; -- Scarlet Invoker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1837; -- Scarlet Judge
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1839; -- Scarlet High Clerist
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1840; -- Grand Inquisitor Isillien
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1842; -- Highlord Taelan Fordring
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1844; -- Foreman Marcrid
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1845; -- High Protector Tarsen
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1846; -- High Protector Lorik
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1847; -- Foulmane
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1850; -- Putridius
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1851; -- The Husk
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1852; -- Araj the Summoner
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1883; -- Scarlet Worker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1884; -- Scarlet Lumberjack
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1888; -- Dalaran Watcher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1891; -- Pyrewood Watcher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1892; -- Moonrage Watcher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1893; -- Moonrage Sentry
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1894; -- Pyrewood Sentry
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1895; -- Pyrewood Elder
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1911; -- Deeb
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1948; -- Snarlmane
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2058; -- Deathstalker Faerleia
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2061; -- Councilman Thatcher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2062; -- Councilman Hendricks
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2063; -- Councilman Wilhelm
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2065; -- Councilman Cooper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2066; -- Councilman Higarth
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2067; -- Councilman Brunswick
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2068; -- Lord Mayor Morrison
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2106; -- Apothecary Berard
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2130; -- Marion Call
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2136; -- Oliver Dwor
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2165; -- Grizzled Thistle Bear
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2191; -- Licillin
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2209; -- Deathguard Gavin
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2210; -- Deathguard Royann
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2240; -- Syndicate Footpad
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2242; -- Syndicate Spy
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2245; -- Syndicate Saboteur
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2246; -- Syndicate Assassin
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2247; -- Syndicate Enforcer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2250; -- Mountain Yeti
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2251; -- Giant Yeti
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2258; -- Stone Fury
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2264; -- Hillsbrad Tailor
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2267; -- Hillsbrad Peasant
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2268; -- Hillsbrad Footman
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2270; -- Hillsbrad Sentry
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2272; -- Dalaran Theurgist
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2274; -- Stanley
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2275; -- Enraged Stanley
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2283; -- Ravenclaw Regent
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2303; -- Lyranne Feathersong
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2319; -- Syndicate Wizard
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2349; -- Giant Moss Creeper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2358; -- Dalaran Summoner
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2371; -- Daggerspine Siren
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2384; -- Starving Mountain Lion
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2385; -- Feral Mountain Lion
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2387; -- Hillsbrad Councilman
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2403; -- Farmer Getz
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2407; -- Hulking Mountain Lion
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2411; -- Ricter
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2412; -- Alina
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2417; -- Grel'borg the Miser
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2423; -- Lord Aliden Perenolde
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2427; -- Jailor Eston
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2428; -- Jailor Marlgen
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2431; -- Jailor Borhuin
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2447; -- Narillasanz
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2449; -- Citizen Wilkes
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2451; -- Farmer Kalaba
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2453; -- Lo'Grosh
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2477; -- Gradok
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2503; -- Hillsbrad Foreman
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2505; -- Saltwater Snapjaw
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2530; -- Yenniku
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2534; -- Zanzil the Outcast
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2535; -- Maury "Club Foot" Wilkins
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2536; -- Jon-Jon the Crow
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2537; -- Chucky "Ten Thumbs"
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2544; -- Southern Sand Crawler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2551; -- Brutus
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2553; -- Witherbark Shadowcaster
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2554; -- Witherbark Axe Thrower
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2555; -- Witherbark Witch Doctor
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2557; -- Witherbark Shadow Hunter
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2560; -- Highland Thrasher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2562; -- Boulderfist Ogre
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2563; -- Plains Creeper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2564; -- Boulderfist Enforcer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2565; -- Giant Plains Creeper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2566; -- Boulderfist Brute
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2567; -- Boulderfist Magus
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2572; -- Drywhisker Kobold
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2575; -- Dark Iron Supplier
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2577; -- Dark Iron Shadowcaster
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2580; -- Elder Mesa Buzzard
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2587; -- Syndicate Pathstalker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2592; -- Rumbling Exile
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2595; -- Daggerspine Raider
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2596; -- Daggerspine Sorceress
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2600; -- Singer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2604; -- Molok the Crusher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2605; -- Zalas Witherbark
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2606; -- Nimar the Slayer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2628; -- Dalaran Worker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2639; -- Vilebranch Axe Thrower
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2640; -- Vilebranch Witch Doctor
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2649; -- Witherbark Scalper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2650; -- Witherbark Zealot
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2651; -- Witherbark Hideskinner
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2652; -- Witherbark Venomblood
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2653; -- Witherbark Sadist
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2655; -- Green Sludge
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2656; -- Jade Ooze
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2657; -- Trained Razorbeak
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2658; -- Razorbeak Gryphon
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2659; -- Razorbeak Skylord
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2667; -- Ward of Laze
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2678; -- Mechanical Dragonling
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2682; -- Fradd Swiftgear
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2683; -- Namdo Bizzfizzle
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2686; -- Witherbark Broodguard
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2701; -- Dustbelcher Ogre
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2707; -- Shadra
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2714; -- Forsaken Courier
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2715; -- Dustbelcher Brute
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2716; -- Dustbelcher Wyrmhunter
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2717; -- Dustbelcher Mauler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2718; -- Dustbelcher Shaman
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2719; -- Dustbelcher Lord
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2720; -- Dustbelcher Ogre Mage
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2721; -- Forsaken Bodyguard
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2723; -- Stone Golem
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2725; -- Scalding Whelp
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2726; -- Scorched Guardian
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2727; -- Crag Coyote
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2728; -- Feral Crag Coyote
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2730; -- Rabid Crag Coyote
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2732; -- Ridge Huntress
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2734; -- Ridge Stalker Patriarch
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2735; -- Lesser Rock Elemental
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2736; -- Greater Rock Elemental
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2739; -- Shadowforge Tunneler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2740; -- Shadowforge Darkweaver
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2743; -- Shadowforge Warrior
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2749; -- Siege Golem
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2752; -- Rumbler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2754; -- Anathemus
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2759; -- Hematus
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2760; -- Burning Exile
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2762; -- Thundering Exile
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2767; -- First Mate Nilzlix
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2775; -- Daggerspine Marauder
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2778; -- Deckhand Moishe
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2779; -- Prince Nazjak
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2791; -- Enraged Rock Elemental
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2793; -- Kor'gresh Coldrage
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2829; -- Starving Buzzard
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2830; -- Buzzard
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2831; -- Giant Buzzard
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2850; -- Broken Tooth
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2855; -- Snang
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2893; -- Stonevault Bonesnapper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2894; -- Stonevault Shaman
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2923; -- Mangy Silvermane
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2924; -- Silvermane Wolf
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2925; -- Silvermane Howler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2926; -- Silvermane Stalker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2927; -- Vicious Owlbeast
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2928; -- Primitive Owlbeast
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2931; -- Zaricotl
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2937; -- Dagun the Ravenous
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2944; -- Boss Tho'grun
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2945; -- Murdaloc
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2946; -- Puppet of Helcular
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3008; -- Mak
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3058; -- Arra'chea
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3078; -- Kennah Hawkseye
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3135; -- Malissa
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3165; -- Ghrawt
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3183; -- Yarrog Baneshadow
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3190; -- Rhinag
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3209; -- Brave Windfeather
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3217; -- Brave Dawneagle
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3218; -- Brave Swiftwind
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3219; -- Brave Leaping Deer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3253; -- Silithid Harvester
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3291; -- Greishan Ironstove
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3376; -- Bael'dun Soldier
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3377; -- Bael'dun Rifleman
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3398; -- Gesharahan
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3435; -- Lok Orcbane
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3443; -- Grub
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3447; -- Pawe Mistrunner
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3459; -- Razormane Warfrenzy
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3472; -- Washte Pawne
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3473; -- Owatanka
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3476; -- Isha Awak
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3492; -- Vexspindle
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3497; -- Kilxx
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3510; -- Twain
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3523; -- Bowen Brisboise
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3528; -- Pyrewood Armorer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3529; -- Moonrage Armorer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3531; -- Moonrage Tailor
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3532; -- Pyrewood Leatherworker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3586; -- Miner Johnson
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3616; -- Onu
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3636; -- Deviate Ravager
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3637; -- Deviate Guardian
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3664; -- Ilkrud Magthrull
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3669; -- Lord Cobrahn
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3671; -- Lady Anacondra
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3696; -- Ran Bloodtooth
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3736; -- Darkslayer Mordenthal
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3745; -- Foulweald Pathfinder
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3746; -- Foulweald Den Watcher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3749; -- Foulweald Ursa
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3752; -- Xavian Rogue
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3758; -- Felmusk Satyr
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3767; -- Bleakheart Trickster
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3770; -- Bleakheart Shadowstalker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3782; -- Shadethicket Stone Mover
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3783; -- Shadethicket Raincaller
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3806; -- Forsaken Infiltrator
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3807; -- Forsaken Assassin
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3820; -- Wildthorn Venomspitter
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3824; -- Ghostpaw Howler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3825; -- Ghostpaw Alpha
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3834; -- Crazed Ancient
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3851; -- Shadowfang Whitescalp
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3861; -- Bleak Worg
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3884; -- Jhawna Oatwind
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3893; -- Forsaken Scout
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3898; -- Aligar the Tormentor
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3914; -- Rethilgore
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3915; -- Dagri
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3931; -- Shadethicket Oracle
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3955; -- Shandrina
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3956; -- Harklan Moongrove
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3962; -- Haljan Oakheart
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3965; -- Cylania Rootstalker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3974; -- Houndmaster Loksey
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3983; -- Interrogator Vishas
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3984; -- Nancy Vishas
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3985; -- Grandpa Vishas
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3987; -- Dal Bloodclaw
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4003; -- Windshear Geomancer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4013; -- Pridewing Skyhunter
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4015; -- Pridewing Patriarch
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4019; -- Great Courser
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4021; -- Corrosive Sap Beast
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4022; -- Bloodfury Harpy
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4023; -- Bloodfury Roguefeather
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4031; -- Fledgling Chimaera
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4037; -- Burning Ravager
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4041; -- Scorched Basilisk
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4042; -- Singed Basilisk
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4057; -- Son of Cenarius
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4066; -- Nal'taszar
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4067; -- Twilight Runner
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4073; -- XT:4
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4074; -- XT:9
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4083; -- Jeeda
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4084; -- Chylina
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4085; -- Nizzik
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4086; -- Veenix
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4093; -- Galak Wrangler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4094; -- Galak Scout
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4095; -- Galak Mauler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4101; -- Screeching Roguefeather
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4104; -- Screeching Windcaller
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4110; -- Highperch Patriarch
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4112; -- Gravelsnout Vermin
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4114; -- Gravelsnout Forager
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4116; -- Gravelsnout Surveyor
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4124; -- Needles Cougar
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4126; -- Crag Stalker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4130; -- Silithid Searcher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4133; -- Silithid Hive Drone
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4139; -- Scorpid Terror
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4144; -- Sparkleshell Borer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4151; -- Saltstone Crystalhide
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4158; -- Salt Flats Vulture
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4190; -- Kyndri
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4202; -- Gerenzo Wrenchwhistle
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4243; -- Nightshade
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4250; -- Galak Packhound
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4260; -- Venture Co. Shredder
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4287; -- Scarlet Gallant
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4288; -- Scarlet Beastmaster
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4293; -- Scarlet Scryer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4294; -- Scarlet Sorcerer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4296; -- Scarlet Adept
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4300; -- Scarlet Wizard
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4301; -- Scarlet Centurion
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4306; -- Scarlet Torturer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4341; -- Drywallow Crocolisk
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4343; -- Drywallow Snapper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4344; -- Mottled Drywallow Crocolisk
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4346; -- Noxious Flayer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4347; -- Noxious Reaver
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4348; -- Noxious Shredder
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4355; -- Bloodfen Scytheclaw
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4358; -- Mirefin Puddlejumper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4360; -- Mirefin Warrior
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4364; -- Strashaz Warrior
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4366; -- Strashaz Serpent Guard
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4368; -- Strashaz Myrmidon
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4370; -- Strashaz Sorceress
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4371; -- Strashaz Siren
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4374; -- Strashaz Hydra
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4387; -- Withervine Mire Beast
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4392; -- Corrosive Swamp Ooze
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4393; -- Acidic Swamp Ooze
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4398; -- Mudrock Burrower
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4399; -- Mudrock Borer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4402; -- Muckshell Snapclaw
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4405; -- Muckshell Razorclaw
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4413; -- Darkfang Spider
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4435; -- Razorfen Warrior
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4457; -- Murkgill Forager
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4458; -- Murkgill Hunter
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4461; -- Murkgill Warrior
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4466; -- Vilebranch Scalper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4467; -- Vilebranch Soothsayer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4472; -- Haunting Vision
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4474; -- Rotting Cadaver
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4475; -- Blighted Zombie
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4479; -- Fardel Dabyrie
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4493; -- Scarlet Avenger
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4494; -- Scarlet Spellbinder
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4504; -- Frostmaw
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4511; -- Agam'ar
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4542; -- High Inquisitor Fairbanks
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4546; -- Bor'zehn
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4619; -- Geltharis
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4638; -- Magram Scout
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4639; -- Magram Outrunner
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4640; -- Magram Wrangler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4641; -- Magram Windchaser
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4642; -- Magram Stormer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4644; -- Magram Marauder
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4645; -- Magram Mauler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4646; -- Gelkis Outrunner
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4647; -- Gelkis Scout
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4648; -- Gelkis Stamper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4649; -- Gelkis Windchaser
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4651; -- Gelkis Earthcaller
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4652; -- Gelkis Mauler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4653; -- Gelkis Marauder
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4654; -- Maraudine Scout
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4657; -- Maraudine Windchaser
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4658; -- Maraudine Stormer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4659; -- Maraudine Marauder
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4660; -- Maraudine Bonepaw
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4662; -- Magram Bonepaw
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4665; -- Burning Blade Adept
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4667; -- Burning Blade Shadowmage
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4673; -- Hatefury Betrayer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4674; -- Hatefury Shadowstalker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4675; -- Hatefury Hellcaller
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4678; -- Mana Eater
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4681; -- Mage Hunter
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4682; -- Nether Sister
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4684; -- Nether Sorceress
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4686; -- Deepstrider Giant
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4687; -- Deepstrider Searcher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4688; -- Bonepaw Hyena
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4690; -- Rabid Bonepaw
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4692; -- Dread Swoop
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4694; -- Dread Ripper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4695; -- Carrion Horror
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4699; -- Scorpashi Venomlash
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4705; -- Burning Blade Invoker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4711; -- Slitherblade Naga
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4712; -- Slitherblade Sorceress
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4713; -- Slitherblade Warrior
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4715; -- Slitherblade Razortail
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4718; -- Slitherblade Oracle
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4719; -- Slitherblade Sea Witch
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4723; -- Foreman Cozzle
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4729; -- Hulking Gritjaw Basilisk
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4784; -- Argent Guard Manados
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5046; -- Lieutenant Caldwell
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5047; -- Ellaercia
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5048; -- Deviate Adder
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5185; -- Hammerhead Shark
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5226; -- Murk Worm
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5228; -- Saturated Ooze
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5229; -- Gordunni Ogre
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5232; -- Gordunni Brute
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5234; -- Gordunni Mauler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5236; -- Gordunni Shaman
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5238; -- Gordunni Battlemaster
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5240; -- Gordunni Warlock
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5241; -- Gordunni Warlord
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5244; -- Zukk'ash Stinger
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5245; -- Zukk'ash Wasp
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5246; -- Zukk'ash Worker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5247; -- Zukk'ash Tunneler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5249; -- Woodpaw Mongrel
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5251; -- Woodpaw Trapper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5253; -- Woodpaw Brute
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5254; -- Woodpaw Mystic
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5255; -- Woodpaw Reaver
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5258; -- Woodpaw Alpha
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5260; -- Groddoc Ape
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5262; -- Groddoc Thunderer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5268; -- Ironfur Bear
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5274; -- Ironfur Patriarch
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5278; -- Sprite Darter
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5286; -- Longtooth Runner
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5287; -- Longtooth Howler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5288; -- Rabid Longtooth
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5292; -- Feral Scar Yeti
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5293; -- Hulking Feral Scar
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5296; -- Rage Scar Yeti
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5299; -- Ferocious Rage Scar
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5300; -- Frayfeather Hippogryph
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5304; -- Frayfeather Stagwing
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5305; -- Frayfeather Skystormer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5306; -- Frayfeather Patriarch
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5307; -- Vale Screecher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5308; -- Rogue Vale Screecher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5312; -- Lethlas
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5314; -- Phantim
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5317; -- Jademir Oracle
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5319; -- Jademir Tree Warder
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5320; -- Jademir Boughguard
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5331; -- Hatecrest Warrior
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5332; -- Hatecrest Wave Rider
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5333; -- Hatecrest Serpent Guard
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5334; -- Hatecrest Myrmidon
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5335; -- Hatecrest Screamer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5336; -- Hatecrest Sorceress
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5337; -- Hatecrest Siren
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5343; -- Lady Szallah
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5349; -- Arash-ethis
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5350; -- Qirot
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5352; -- Old Grizzlegut
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5356; -- Snarler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5357; -- Land Walker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5358; -- Cliff Giant
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5359; -- Shore Strider
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5361; -- Wave Strider
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5362; -- Northspring Harpy
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5363; -- Northspring Roguefeather
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5409; -- Harvester Swarm
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5419; -- Glasshide Basilisk
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5420; -- Glasshide Gazer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5421; -- Glasshide Petrifier
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5422; -- Scorpid Hunter
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5423; -- Scorpid Tail Lasher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5424; -- Scorpid Dunestalker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5425; -- Starving Blisterpaw
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5426; -- Blisterpaw Hyena
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5427; -- Rabid Blisterpaw
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5428; -- Roc
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5429; -- Fire Roc
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5431; -- Surf Glider
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5432; -- Giant Surf Glider
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5435; -- Sand Shark
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5441; -- Hazzali Wasp
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5450; -- Hazzali Stinger
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5451; -- Hazzali Swarmer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5452; -- Hazzali Worker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5453; -- Hazzali Tunneler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5455; -- Centipaar Wasp
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5456; -- Centipaar Stinger
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5457; -- Centipaar Swarmer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5458; -- Centipaar Worker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5459; -- Centipaar Tunneler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5460; -- Centipaar Sandreaver
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5461; -- Sea Elemental
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5462; -- Sea Spray
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5465; -- Land Rager
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5466; -- Coast Strider
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5469; -- Dune Smasher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5470; -- Raging Dune Smasher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5471; -- Dunemaul Ogre
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5472; -- Dunemaul Enforcer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5473; -- Dunemaul Ogre Mage
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5475; -- Dunemaul Warlock
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5477; -- Noboru the Cudgel
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5490; -- Gnarled Thistleshrub
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5598; -- Atal'ai Exile
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5611; -- Barkeep Morag
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5648; -- Sandfury Shadowcaster
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5649; -- Sandfury Blood Drinker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5650; -- Sandfury Witch Doctor
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5676; -- Summoned Voidwalker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5683; -- Comar Villard
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5694; -- High Sorcerer Andromath
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5718; -- Rothos
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5760; -- Lord Azrethoc
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5771; -- Jugkar Grim'rod
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5781; -- Silithid Creeper Egg
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5785; -- Sister Hatelash
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5787; -- Enforcer Emilgund
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5824; -- Captain Flat Tusk
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5827; -- Brontus
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5828; -- Humar the Pridelord
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5830; -- Sister Rathtalon
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5831; -- Swiftmane
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5839; -- Dark Iron Geologist
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5840; -- Dark Iron Steamsmith
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5844; -- Dark Iron Slaver
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5846; -- Dark Iron Taskmaster
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5848; -- Malgin Barleybrew
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5849; -- Digger Flameforge
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5850; -- Blazing Elemental
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5851; -- Captain Gerogg Hammertoe
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5852; -- Inferno Elemental
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5854; -- Heavy War Golem
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5855; -- Magma Elemental
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5857; -- Searing Lava Spider
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5858; -- Greater Lava Spider
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5859; -- Hagg Taurenbane
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5928; -- Sorrow Wing
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5930; -- Sister Riven
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5931; -- Foreman Rigger
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5933; -- Achellios the Banished
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5934; -- Heartrazor
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5935; -- Ironeye the Invincible
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5937; -- Vile Sting
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5939; -- Vira Younghoof
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5976; -- Dreadmaul Brute
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5977; -- Dreadmaul Mauler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5978; -- Dreadmaul Warlock
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5983; -- Bonepicker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5984; -- Starving Snickerfang
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5985; -- Snickerfang Hyena
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5991; -- Redstone Crystalhide
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5992; -- Ashmane Boar
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5993; -- Helboar
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6004; -- Shadowsworn Cultist
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6005; -- Shadowsworn Thug
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6006; -- Shadowsworn Adept
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6007; -- Shadowsworn Enforcer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6008; -- Shadowsworn Warlock
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6009; -- Shadowsworn Dreadweaver
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6011; -- Felguard Sentry
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6069; -- Maraudine Khan Guard
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6071; -- Legion Hound
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6073; -- Searing Infernal
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6115; -- Roaming Felguard
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6118; -- Varo'then's Ghost
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6119; -- Tog Rustsprocket
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6121; -- Remen Marcot
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6125; -- Haldarr Satyr
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6126; -- Haldarr Trickster
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6129; -- Draconic Magelord
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6130; -- Blue Scalebane
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6131; -- Draconic Mageweaver
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6135; -- Arkkoran Clacker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6136; -- Arkkoran Muckdweller
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6137; -- Arkkoran Pincer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6138; -- Arkkoran Oracle
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6143; -- Servant of Arkkoroc
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6144; -- Son of Arkkoroc
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6146; -- Cliff Breaker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6147; -- Cliff Thunderer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6148; -- Cliff Walker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6166; -- Yorus Barleybrew
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6170; -- Gutspill
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6180; -- Defias Raider
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6187; -- Timbermaw Den Watcher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6193; -- Spitelash Screamer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6194; -- Spitelash Serpent Guard
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6196; -- Spitelash Myrmidon
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6200; -- Legashi Satyr
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6201; -- Legashi Rogue
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6202; -- Legashi Hellcaller
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6289; -- Rand Rhobart
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6348; -- Wavethrasher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6349; -- Great Wavethrasher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6350; -- Makrinni Razorclaw
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6370; -- Makrinni Scrabbler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6375; -- Thunderhead Hippogryph
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6377; -- Thunderhead Stagwing
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6379; -- Thunderhead Patriarch
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6380; -- Thunderhead Consort
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6498; -- Devilsaur
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6499; -- Ironhide Devilsaur
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6500; -- Tyrant Devilsaur
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6501; -- Stegodon
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6502; -- Plated Stegodon
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6503; -- Spiked Stegodon
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6505; -- Ravasaur
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6506; -- Ravasaur Runner
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6507; -- Ravasaur Hunter
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6508; -- Venomhide Ravasaur
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6509; -- Bloodpetal Lasher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6510; -- Bloodpetal Flayer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6511; -- Bloodpetal Thresher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6512; -- Bloodpetal Trapper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6513; -- Un'Goro Stomper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6514; -- Un'Goro Gorilla
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6516; -- Un'Goro Thunderer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6520; -- Scorching Elemental
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6521; -- Living Blaze
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6546; -- Tabetha
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6549; -- Demon of the Orb
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6551; -- Gorishi Wasp
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6552; -- Gorishi Worker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6553; -- Gorishi Reaver
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6554; -- Gorishi Stinger
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6555; -- Gorishi Tunneler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6556; -- Muculent Ooze
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6557; -- Primal Ooze
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6559; -- Glutinous Ooze
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6560; -- Stone Guardian
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6581; -- Ravasaur Matriarch
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6582; -- Clutchmother Zavas
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6583; -- Gruff
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6585; -- Uhk'loc
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6649; -- Lady Sesspira
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6668; -- Lord Cyrik Blackforge
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6738; -- Innkeeper Kimlya
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6766; -- Ravenholdt Guard
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6768; -- Lord Jorach Ravenholdt
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6771; -- Ravenholdt Assassin
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6866; -- Defias Bodyguard
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7009; -- Arantir
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7025; -- Blackrock Soldier
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7026; -- Blackrock Sorcerer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7027; -- Blackrock Slayer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7028; -- Blackrock Warlock
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7029; -- Blackrock Battlemaster
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7031; -- Obsidian Elemental
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7033; -- Firegut Ogre
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7034; -- Firegut Ogre Mage
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7035; -- Firegut Brute
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7039; -- War Reaver
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7047; -- Black Broodling
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7048; -- Scalding Broodling
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7049; -- Flamescale Broodling
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7052; -- Defias Tower Patroller
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7055; -- Blackrock Worg
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7056; -- Defias Tower Sentry
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7057; -- Digmaster Shovelphlange
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7068; -- Condemned Acolyte
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7069; -- Condemned Monk
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7071; -- Cursed Paladin
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7075; -- Writhing Mage
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7092; -- Tainted Ooze
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7093; -- Vile Ooze
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7097; -- Ironbeak Owl
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7098; -- Ironbeak Screecher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7099; -- Ironbeak Hunter
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7100; -- Warpwood Moss Flayer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7101; -- Warpwood Shredder
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7104; -- Dessecus
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7105; -- Jadefire Satyr
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7106; -- Jadefire Rogue
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7107; -- Jadefire Trickster
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7108; -- Jadefire Betrayer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7109; -- Jadefire Felsworn
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7110; -- Jadefire Shadowstalker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7111; -- Jadefire Hellcaller
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7113; -- Jaedenar Guardian
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7114; -- Jaedenar Enforcer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7115; -- Jaedenar Adept
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7118; -- Jaedenar Darkweaver
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7120; -- Jaedenar Warlock
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7125; -- Jaedenar Hound
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7126; -- Jaedenar Hunter
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7138; -- Irontree Wanderer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7139; -- Irontree Stomper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7149; -- Withered Protector
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7153; -- Deadwood Warrior
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7154; -- Deadwood Gardener
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7155; -- Deadwood Pathfinder
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7156; -- Deadwood Den Watcher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7157; -- Deadwood Avenger
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7158; -- Deadwood Shaman
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7271; -- Witch Doctor Zum'rah
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7273; -- Gahz'rilla
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7274; -- Sandfury Executioner
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7288; -- Grand Foreman Puzik Gallywix
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7307; -- Venture Co. Lookout
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7343; -- Splinterbone Skeleton
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7349; -- Tomb Fiend
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7369; -- Deadwind Brute
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7371; -- Deadwind Mauler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7372; -- Deadwind Warlock
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7376; -- Sky Shadow
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7429; -- Frostmaul Preserver
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7430; -- Frostsaber Cub
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7431; -- Frostsaber
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7432; -- Frostsaber Stalker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7433; -- Frostsaber Huntress
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7434; -- Frostsaber Pride Watcher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7435; -- Cobalt Wyrmkin
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7436; -- Cobalt Scalebane
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7437; -- Cobalt Mageweaver
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7438; -- Winterfall Ursa
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7439; -- Winterfall Shaman
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7440; -- Winterfall Den Watcher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7441; -- Winterfall Totemic
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7442; -- Winterfall Pathfinder
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7444; -- Shardtooth Bear
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7445; -- Elder Shardtooth
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7446; -- Rabid Shardtooth
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7447; -- Fledgling Chillwind
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7448; -- Chillwind Chimaera
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7449; -- Chillwind Ravager
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7450; -- Ragged Owlbeast
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7451; -- Raging Owlbeast
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7452; -- Crazed Owlbeast
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7453; -- Moontouched Owlbeast
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7454; -- Berserk Owlbeast
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7456; -- Winterspring Screecher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7457; -- Rogue Ice Thistle
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7458; -- Ice Thistle Yeti
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7460; -- Ice Thistle Patriarch
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7584; -- Wandering Forest Walker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7604; -- Sergeant Bly
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7605; -- Raven
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7608; -- Murta Grimgut
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7664; -- Razelikh the Defiler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7665; -- Grol the Destroyer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7666; -- Archmage Allistarj
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7667; -- Lady Sevine
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7668; -- Servant of Razelikh
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7669; -- Servant of Grol
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7670; -- Servant of Allistarj
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7671; -- Servant of Sevine
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7725; -- Grimtotem Raider
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7727; -- Grimtotem Shaman
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7774; -- Shay Leafrunner
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7787; -- Sandfury Slave
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7795; -- Hydromancer Velratha
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7803; -- Scorpid Duneburrower
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7808; -- Marauding Owlbeast
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7809; -- Vilebranch Ambusher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7847; -- Caliph Scorpidsting
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7848; -- Lurking Feral Scar
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7855; -- Southsea Pirate
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7856; -- Southsea Freebooter
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7857; -- Southsea Dock Worker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7858; -- Southsea Swashbuckler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7868; -- Sarah Tanner
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7883; -- Andre Firebeard
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7885; -- Spitelash Battlemaster
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7886; -- Spitelash Enchantress
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7942; -- Faralorn
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8121; -- Jaxxil Sparks
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8122; -- Kizzak Sparks
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8136; -- Lord Shalzaru
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8149; -- Sul'lithuz Warder
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8196; -- Occulus
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8197; -- Chronalis
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8199; -- Warleader Krazzilak
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8200; -- Jin'Zallah the Sandbringer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8202; -- Cyclok the Mad
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8205; -- Haarka the Ravenous
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8207; -- Greater Firebird
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8208; -- Murderous Blisterpaw
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8210; -- Razortalon
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8211; -- Old Cliff Jumper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8213; -- Ironback
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8215; -- Grimungous
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8216; -- Retherokk the Berserker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8217; -- Mith'rethis the Enchanter
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8218; -- Witherheart the Stalker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8219; -- Zul'arek Hatefowler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8257; -- Oozeling
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8280; -- Shleipnarr
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8282; -- Highlord Mastrogonde
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8283; -- Slave Master Blackheart
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8296; -- Mojo the Twisted
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8298; -- Akubar the Seer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8300; -- Ravage
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8301; -- Clack the Reaver
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8302; -- Deatheye
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8303; -- Grunter
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8304; -- Dreadscorn
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8311; -- Slime Maggot
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8318; -- Atal'ai Slave
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8324; -- Atal'ai Skeleton
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8337; -- Dark Iron Steelshifter
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8338; -- Dark Iron Marksman
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8408; -- Warlord Krellian
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8409; -- Caravan Master Tset
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8518; -- Rynthariel the Keymaster
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8519; -- Blighted Surge
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8520; -- Plague Ravager
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8521; -- Blighted Horror
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8522; -- Plague Monstrosity
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8523; -- Scourge Soldier
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8525; -- Scourge Warder
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8527; -- Scourge Guard
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8529; -- Scourge Champion
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8530; -- Cannibal Ghoul
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8531; -- Gibbering Ghoul
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8534; -- Putrid Gargoyle
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8542; -- Death Singer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8543; -- Stitched Horror
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8544; -- Gangled Golem
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8545; -- Stitched Golem
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8555; -- Crypt Stalker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8556; -- Crypt Walker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8558; -- Crypt Slayer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8560; -- Mossflayer Scout
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8561; -- Mossflayer Shadowhunter
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8562; -- Mossflayer Cannibal
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8566; -- Dark Iron Lookout
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8578; -- Magus Rimtori
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8596; -- Plaguehound Runt
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8597; -- Plaguehound
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8598; -- Frenzied Plaguehound
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8600; -- Plaguebat
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8601; -- Noxious Plaguebat
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8602; -- Monstrous Plaguebat
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8603; -- Carrion Grub
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8605; -- Carrion Devourer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8606; -- Living Decay
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8607; -- Rotting Sludge
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8616; -- Infernal Servant
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8637; -- Dark Iron Watchman
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8660; -- The Evalcharr
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8667; -- Gusting Vortex
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8675; -- Felbeast
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8718; -- Manahound
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8757; -- Shahiar
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8758; -- Zaman
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8759; -- Mosshoof Runner
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8761; -- Mosshoof Courser
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8762; -- Timberweb Recluse
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8763; -- Mistwing Rogue
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8764; -- Mistwing Ravager
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8766; -- Forest Ooze
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8837; -- Muck Splash
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8877; -- Sandfury Zealot
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8890; -- Anvilrage Warden
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8891; -- Anvilrage Guardsman
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8912; -- Twilight's Hammer Torturer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8915; -- Twilight's Hammer Ambassador
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8921; -- Bloodhound
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8956; -- Angerclaw Bear
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8958; -- Angerclaw Mauler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8959; -- Felpaw Wolf
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8960; -- Felpaw Scavenger
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8961; -- Felpaw Ravager
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8976; -- Hematos
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8979; -- Gruklash
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8996; -- Voidwalker Minion
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9018; -- High Interrogator Gerstahn
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9020; -- Commander Gor'shak
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9022; -- Dughal Stormwing
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9024; -- Pyromancer Loregrain
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9025; -- Lord Roccor
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9034; -- Hate'rel
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9035; -- Anger'rel
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9036; -- Vile'rel
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9037; -- Gloom'rel
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9038; -- Seeth'rel
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9039; -- Doom'rel
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9040; -- Dope'rel
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9045; -- Scarshield Acolyte
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9083; -- Razal'blade
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9085; -- Initiate Amakkar
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9096; -- Rage Talon Dragonspawn
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9097; -- Scarshield Legionnaire
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9098; -- Scarshield Spellbinder
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9162; -- Young Diemetradon
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9163; -- Diemetradon
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9165; -- Fledgling Pterrordax
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9166; -- Pterrordax
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9176; -- Gor'tesh
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9178; -- Burning Spirit
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9197; -- Spirestone Battle Mage
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9199; -- Spirestone Enforcer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9201; -- Spirestone Ogre Magus
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9216; -- Spirestone Warlord
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9217; -- Spirestone Lord Magus
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9218; -- Spirestone Battle Lord
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9219; -- Spirestone Butcher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9236; -- Shadow Hunter Vosh'gajin
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9239; -- Smolderthorn Mystic
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9240; -- Smolderthorn Shadow Priest
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9241; -- Smolderthorn Headhunter
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9257; -- Scarshield Warlock
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9259; -- Firebrand Grunt
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9260; -- Firebrand Legionnaire
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9261; -- Firebrand Darkweaver
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9262; -- Firebrand Invoker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9263; -- Firebrand Dreadweaver
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9264; -- Firebrand Pyromancer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9265; -- Smolderthorn Shadow Hunter
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9266; -- Smolderthorn Witch Doctor
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9267; -- Smolderthorn Axe Thrower
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9268; -- Smolderthorn Berserker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9269; -- Smolderthorn Seer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9318; -- Incendosaur
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9319; -- Houndmaster Grebmar
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9376; -- Blazerunner
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9396; -- Ground Pounder
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9416; -- Scarshield Worg
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9447; -- Scarlet Warder
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9448; -- Scarlet Praetorian
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9449; -- Scarlet Cleric
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9450; -- Scarlet Curate
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9451; -- Scarlet Archmage
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9452; -- Scarlet Enchanter
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9453; -- Aquementas
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9454; -- Xavathras
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9456; -- Warlord Krom'zar
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9462; -- Chieftain Bloodmaw
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9464; -- Overlord Ror
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9498; -- Gorishi Grub
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9499; -- Plugger Spazzring
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9500; -- Mistress Nagmara
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9502; -- Phalanx
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9516; -- Lord Banehollow
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9517; -- Shadow Lord Fel'dan
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9518; -- Rakaiah
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9520; -- Grark Lorkrub
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9541; -- Blackbreath Crony
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9568; -- Overlord Wyrmthalak
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9583; -- Bloodaxe Veteran
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9596; -- Bannok Grimaxe
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9598; -- Arei
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9622; -- U'cha
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9623; -- A-Me 01
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9660; -- Agnar Beastamer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9690; -- Ember Worg
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9691; -- Venomtip Scorpid
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9692; -- Bloodaxe Raider
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9693; -- Bloodaxe Evoker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9697; -- Giant Ember Worg
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9698; -- Firetail Scorpid
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9708; -- Burning Imp
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9716; -- Bloodaxe Warmonger
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9717; -- Bloodaxe Summoner
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9718; -- Ghok Bashguud
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9736; -- Quartermaster Zigris
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9817; -- Blackhand Dreadweaver
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9819; -- Blackhand Veteran
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9860; -- Salia
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9861; -- Moora
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9862; -- Jaedenar Legionnaire
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9877; -- Prince Xavalis
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9878; -- Entropic Beast
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9916; -- Jarquia
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9956; -- Shadowforge Flame Keeper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10040; -- Gorishi Hive Guard
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10041; -- Gorishi Hive Queen
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10078; -- Terrorspark
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10080; -- Sandarr Dunereaver
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10082; -- Zerillis
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10083; -- Rage Talon Flamescale
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10096; -- High Justice Grimstone
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10161; -- Rookery Whelp
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10162; -- Lord Victor Nefarius
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10184; -- Onyxia
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10196; -- General Colbatann
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10197; -- Mezzir the Howler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10201; -- Lady Hederine
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10202; -- Azurous
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10220; -- Halycon
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10221; -- Bloodaxe Worg Pup
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10258; -- Rookery Guardian
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10263; -- Burning Felguard
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10264; -- Solakar Flamewreath
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10268; -- Gizrul the Slavener
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10278; -- Thrag Stonehoof
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10316; -- Blackhand Incarcerator
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10317; -- Blackhand Elite
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10318; -- Blackhand Assassin
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10319; -- Blackhand Iron Guard
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10321; -- Emberstrife
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10339; -- Gyth
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10366; -- Rage Talon Dragon Guard
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10371; -- Rage Talon Captain
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10372; -- Rage Talon Fire Tongue
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10376; -- Crystal Fang
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10382; -- Mangled Cadaver
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10384; -- Spectral Citizen
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10390; -- Skeletal Guardian
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10393; -- Skul
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10405; -- Plague Ghoul
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10406; -- Ghoul Ravener
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10408; -- Rockwing Gargoyle
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10409; -- Rockwing Screecher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10412; -- Crypt Crawler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10413; -- Crypt Beast
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10414; -- Patchwork Horror
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10417; -- Venom Belcher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10418; -- Crimson Guardsman
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10419; -- Crimson Conjuror
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10420; -- Crimson Initiate
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10421; -- Crimson Defender
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10422; -- Crimson Sorcerer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10423; -- Crimson Priest
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10424; -- Crimson Gallant
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10425; -- Crimson Battle Mage
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10432; -- Vectus
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10433; -- Marduk Blackpool
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10435; -- Magistrate Barthilas
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10437; -- Nerub'enkan
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10438; -- Maleki the Pallid
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10442; -- Chromatic Whelp
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10447; -- Chromatic Dragonspawn
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10463; -- Shrieking Banshee
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10469; -- Scholomance Adept
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10470; -- Scholomance Neophyte
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10471; -- Scholomance Acolyte
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10472; -- Scholomance Occultist
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10475; -- Scholomance Student
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10476; -- Scholomance Necrolyte
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10477; -- Scholomance Necromancer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10478; -- Splintered Skeleton
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10481; -- Reanimated Corpse
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10485; -- Risen Aberration
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10486; -- Risen Warrior
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10487; -- Risen Protector
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10488; -- Risen Construct
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10489; -- Risen Guard
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10491; -- Risen Bonewarder
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10495; -- Diseased Ghoul
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10498; -- Spectral Tutor
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10499; -- Spectral Researcher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10500; -- Spectral Teacher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10502; -- Lady Illucia Barov
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10503; -- Jandice Barov
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10505; -- Instructor Malicia
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10507; -- The Ravenian
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10536; -- Plagued Maggot
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10559; -- Lady Vespia
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10580; -- Fetid Zombie
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10584; -- Urok Doomhowl
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10596; -- Mother Smolderweb
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10601; -- Urok Enforcer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10602; -- Urok Ogre Magus
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10605; -- Scarlet Medic
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10639; -- Rorgish Jowl
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10647; -- Prince Raze
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10648; -- Xavaric
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10659; -- Cobalt Whelp
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10660; -- Cobalt Broodling
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10661; -- Spell Eater
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10662; -- Spellmaw
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10663; -- Manaclaw
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10683; -- Rookery Hatcher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10742; -- Blackhand Dragon Handler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10757; -- Boiling Elemental
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10758; -- Grimtotem Bandit
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10760; -- Grimtotem Geomancer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10761; -- Grimtotem Reaver
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10801; -- Jabbering Ghoul
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10809; -- Stonespine
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10811; -- Archivist Galford
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10812; -- Grand Crusader Dathrohan
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10814; -- Chromatic Elite Guard
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10816; -- Wandering Skeleton
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10817; -- Duggan Wildhammer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10821; -- Hed'mush the Rotting
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10822; -- Warlord Thresh'jin
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10824; -- Ranger Lord Hawkspear
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10826; -- Lord Darkscythe
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10827; -- Deathspeaker Selendre
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10828; -- High General Abbendis
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10836; -- Farmer Dalson
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10839; -- Argent Officer Garush
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10840; -- Argent Officer Pureheart
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10896; -- Arnak Grimtotem
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10899; -- Goraluk Anvilcrack
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10901; -- Lorekeeper Polkelt
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10916; -- Winterfall Runner
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10938; -- Redpath the Corrupted
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10946; -- Horgus the Ravager
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10951; -- Marauding Corpse
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10954; -- Bloodletter
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10992; -- Enraged Panther
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10997; -- Cannon Master Willey
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11022; -- Alexi Barov
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11024; -- Della
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11026; -- Sprite Jumpsprocket
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11028; -- Jemma Quikswitch
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11032; -- Malor the Zealous
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11039; -- Duke Nicholas Zverenhoff
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11041; -- Milla Fairancora
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11043; -- Crimson Monk
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11048; -- Victor Ward
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11058; -- Fras Siabi
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11075; -- Cauldron Lord Bilemaw
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11076; -- Cauldron Lord Razarch
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11077; -- Cauldron Lord Malvinious
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11078; -- Cauldron Lord Soulwrath
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11083; -- Darianna
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11096; -- Randal Worth
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11120; -- Crimson Hammersmith
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11143; -- Postmaster Malown
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11198; -- Broken Exile
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11257; -- Scholomance Handler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11261; -- Doctor Theolen Krastinov
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11285; -- Rory
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11318; -- Ragefire Trogg
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11320; -- Earthborer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11321; -- Molten Elemental
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11322; -- Searing Blade Cultist
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11323; -- Searing Blade Enforcer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11339; -- Hakkari Shadow Hunter
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11340; -- Hakkari Blood Priest
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11346; -- Hakkari Oracle
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11350; -- Gurubashi Axe Thrower
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11351; -- Gurubashi Headhunter
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11352; -- Gurubashi Berserker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11353; -- Gurubashi Blood Drinker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11356; -- Gurubashi Champion
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11359; -- Soulflayer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11370; -- Razzashi Broodwidow
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11371; -- Razzashi Serpent
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11372; -- Razzashi Adder
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11373; -- Razzashi Cobra
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11380; -- Jin'do the Hexxer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11382; -- Bloodlord Mandokir
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11383; -- High Priestess Hai'watna
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11437; -- Minor Infernal
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11441; -- Gordok Brute
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11444; -- Gordok Mage-Lord
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11445; -- Gordok Captain
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11446; -- Gordok Spirit
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11447; -- Mushgog
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11448; -- Gordok Warlock
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11450; -- Gordok Reaver
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11451; -- Wildspawn Satyr
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11452; -- Wildspawn Rogue
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11453; -- Wildspawn Trickster
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11454; -- Wildspawn Betrayer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11455; -- Wildspawn Felsworn
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11456; -- Wildspawn Shadowstalker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11457; -- Wildspawn Hellcaller
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11458; -- Petrified Treant
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11459; -- Ironbark Protector
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11460; -- Alzzin's Minion
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11461; -- Warpwood Guardian
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11464; -- Warpwood Tangler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11465; -- Warpwood Stomper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11467; -- Tsu'zee
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11469; -- Eldreth Seether
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11470; -- Eldreth Sorcerer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11472; -- Eldreth Spirit
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11476; -- Skeletal Highborne
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11483; -- Mana Remnant
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11488; -- Illyanna Ravenoak
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11492; -- Alzzin the Wildshaper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11496; -- Immol'thar
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11497; -- The Razza
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11498; -- Skarr the Unbreakable
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11502; -- Ragnaros
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11517; -- Oggleflint
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11519; -- Bazzalan
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11551; -- Necrofiend
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11560; -- Magrami Spectre
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11582; -- Scholomance Dark Summoner
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11583; -- Nefarian
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11611; -- Cavalier Durgen
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11614; -- Bloodshot
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11622; -- Rattlegore
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11658; -- Molten Giant
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11659; -- Molten Destroyer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11661; -- Flamewaker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11662; -- Flamewaker Priest
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11663; -- Flamewaker Healer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11664; -- Flamewaker Elite
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11665; -- Lava Annihilator
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11666; -- Firewalker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11667; -- Flameguard
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11668; -- Firelord
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11669; -- Flame Imp
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11671; -- Core Hound
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11672; -- Core Rager
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11673; -- Ancient Core Hound
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11690; -- Gnarlpine Instigator
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11735; -- Stonelash Scorpid
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11736; -- Stonelash Pincer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11737; -- Stonelash Flayer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11738; -- Sand Skitterer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11740; -- Dredge Striker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11741; -- Dredge Crusher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11744; -- Dust Stormer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11745; -- Cyclone Warrior
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11746; -- Desert Rumbler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11747; -- Desert Rager
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11752; -- Blaise Montgomery
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11792; -- Putridus Shadowstalker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11803; -- Twilight Keeper Exeter
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11804; -- Twilight Keeper Havunth
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11830; -- Hakkari Priest
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11873; -- Spectral Attendant
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11882; -- Twilight Stonecaller
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11886; -- Mercutio Filthgorger
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11887; -- Crypt Robber
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11981; -- Flamegor
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11982; -- Magmadar
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11983; -- Firemaw
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12017; -- Broodlord Lashlayer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12018; -- Majordomo Executus
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12046; -- Gor'marok the Ravager
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12056; -- Baron Geddon
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12057; -- Garr
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12076; -- Lava Elemental
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12098; -- Sulfuron Harbinger
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12099; -- Firesworn
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12100; -- Lava Reaver
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12101; -- Lava Surger
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12118; -- Lucifron
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12119; -- Flamewaker Protector
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12126; -- Lord Tirion Fordring
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12128; -- Crimson Elite
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12129; -- Onyxian Warder
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12138; -- Lunaclaw
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12140; -- Guardian of Elune
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12143; -- Son of Flame
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12144; -- Lunaclaw Spirit
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12199; -- Shade of Ambermoon
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12207; -- Thessala Hydra
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12239; -- Spirit of Gelk
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12240; -- Spirit of Kolk
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12241; -- Spirit of Magra
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12248; -- Infiltrator Hameya
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12259; -- Gehennas
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12264; -- Shazzrah
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12265; -- Lava Spawn
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12337; -- Crimson Courier
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12339; -- Demetria
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12352; -- Scarlet Trooper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12369; -- Lord Kragaru
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12387; -- Large Vile Slime
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12396; -- Doomguard Commander
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12397; -- Lord Kazzak
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12416; -- Blackwing Legionnaire
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12420; -- Blackwing Mage
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12422; -- Death Talon Dragonspawn
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12432; -- Old Vicejaw
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12435; -- Razorgore the Untamed
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12457; -- Blackwing Spellbinder
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12458; -- Blackwing Taskmaster
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12459; -- Blackwing Warlock
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12460; -- Death Talon Wyrmguard
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12461; -- Death Talon Overseer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12463; -- Death Talon Flamescale
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12464; -- Death Talon Seether
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12465; -- Death Talon Wyrmkin
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12467; -- Death Talon Captain
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12468; -- Death Talon Hatcher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12474; -- Emeraldon Boughguard
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12475; -- Emeraldon Tree Warder
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12476; -- Emeraldon Oracle
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12496; -- Dreamtracker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12497; -- Dreamroarer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12498; -- Dreamstalker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12576; -- Grish Longrunner
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12676; -- Sharptalon
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12677; -- Shadumbra
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12800; -- Chimaerok
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12801; -- Arcane Chimaerok
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12802; -- Chimaerok Devourer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12803; -- Lord Lakmaeran
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12836; -- Wandering Protector
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12860; -- Duriel Moonfire
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12899; -- Axtroz
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12940; -- Vorsha the Lasher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 13020; -- Vaelastrasz the Corrupt
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 13036; -- Gordok Mastiff
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 13118; -- Crimson Bodyguard
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 13280; -- Hydrospawn
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 13285; -- Death Lash
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 13602; -- The Abominable Greench
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 13718; -- The Nameless Prophet
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 13737; -- Marandis' Sister
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 13738; -- Veng
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 13739; -- Maraudos
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 13740; -- Magra
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 13741; -- Gelk
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 13896; -- Scalebeard
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 13976; -- Tortured Drake
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 13996; -- Blackwing Technician
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14020; -- Chromaggus
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14023; -- Corrupted Green Whelp
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14024; -- Corrupted Blue Whelp
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14101; -- Enraged Felguard
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14123; -- Steeljaw Snapper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14223; -- Cranky Benj
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14225; -- Prince Kellen
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14227; -- Hissperak
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14231; -- Drogoth the Roamer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14232; -- Dart
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14241; -- Ironbark the Redeemed
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14261; -- Blue Drakonid
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14262; -- Green Drakonid
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14264; -- Red Drakonid
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14265; -- Black Drakonid
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14267; -- Emogg the Crusher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14276; -- Scargil
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14279; -- Creepthess
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14280; -- Big Samras
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14281; -- Jimmy the Bleeder
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14303; -- Petrified Guardian
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14308; -- Ferra
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14321; -- Guard Fengus
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14322; -- Stomper Kreeg
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14323; -- Guard Slip'kik
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14324; -- Cho'Rush the Observer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14325; -- Captain Kromcrush
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14327; -- Lethtendris
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14339; -- Death Howl
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14340; -- Alshirr Banebreath
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14342; -- Ragepaw
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14344; -- Mongress
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14351; -- Gordok Bushwacker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14353; -- Mizzle the Crafty
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14354; -- Pusillin
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14372; -- Winterfall Ambusher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14398; -- Eldreth Darter
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14401; -- Master Elemental Shaper Krixix
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14424; -- Mirelow
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14425; -- Gnawbone
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14426; -- Harb Foulmountain
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14433; -- Sludginn
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14445; -- Lord Captain Wyrmak
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14446; -- Fingat
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14448; -- Molt Thorn
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14456; -- Blackwing Guardsman
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14471; -- Setis
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14473; -- Lapress
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14474; -- Zora
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14475; -- Rex Ashil
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14477; -- Grubthor
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14478; -- Huricanian
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14479; -- Twilight Lord Everun
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14488; -- Roloch
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14490; -- Rippa
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14492; -- Verifonix
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14502; -- Xorothian Dreadsteed
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14506; -- Lord Hel'nurath
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14507; -- High Priest Venoxis
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14509; -- High Priest Thekal
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14510; -- High Priestess Mar'li
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14511; -- Shadowed Spirit
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14512; -- Corrupted Spirit
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14513; -- Malicious Spirit
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14515; -- High Priestess Arlokk
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14516; -- Death Knight Darkreaver
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14518; -- Aspect of Banality
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14520; -- Aspect of Malice
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14521; -- Aspect of Shadow
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14523; -- Ulathek
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14531; -- Artorius the Amiable
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14532; -- Razzashi Venombrood
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14535; -- Artorius the Doombringer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14538; -- Precious the Devourer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14564; -- Terrordale Spirit
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14601; -- Ebonroc
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14605; -- Bone Construct
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14682; -- Sever
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14695; -- Lord Blackwood
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14715; -- Silverwing Elite
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14748; -- Vilebranch Kidnapper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14750; -- Gurubashi Bat Rider
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14781; -- Captain Shatterskull
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14821; -- Razzashi Raptor
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14825; -- Withered Mistress
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14826; -- Sacrificed Troll
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14834; -- Hakkar
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14861; -- Blood Steward of Kirtonos
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14862; -- Emissary Roman'khan
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14880; -- Razzashi Skitterer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14882; -- Atal'ai Mistress
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14883; -- Voodoo Slave
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14888; -- Lethon
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14986; -- Shade of Jin'do
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15067; -- Zulian Stalker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15080; -- Servant of the Hand
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15082; -- Gri'lek
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15083; -- Hazza'rah
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15084; -- Renataki
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15085; -- Wushoolay
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15114; -- Gahz'ranka
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15162; -- Scarlet Inquisitor
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15196; -- Deathclasp
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15200; -- Twilight Keeper Mayna
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15201; -- Twilight Flamereaver
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15202; -- Vyral the Vile
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15229; -- Vekniss Soldier
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15233; -- Vekniss Guardian
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15235; -- Vekniss Stinger
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15236; -- Vekniss Wasp
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15240; -- Vekniss Hive Crawler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15246; -- Qiraji Mindslayer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15247; -- Qiraji Brainwasher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15249; -- Qiraji Lasher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15250; -- Qiraji Slayer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15252; -- Qiraji Champion
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15263; -- The Prophet Skeram
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15264; -- Anubisath Sentinel
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15275; -- Emperor Vek'nilash
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15276; -- Emperor Vek'lor
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15277; -- Anubisath Defender
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15293; -- Aendel Windspear
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15299; -- Viscidus
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15300; -- Vekniss Drone
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15308; -- Twilight Prophet
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15311; -- Anubisath Warder
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15318; -- Hive'Zara Drone
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15319; -- Hive'Zara Collector
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15320; -- Hive'Zara Soldier
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15323; -- Hive'Zara Sandstalker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15324; -- Qiraji Gladiator
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15325; -- Hive'Zara Wasp
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15327; -- Hive'Zara Stinger
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15335; -- Flesh Hunter
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15336; -- Hive'Zara Tail Lasher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15338; -- Obsidian Destroyer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15339; -- Ossirian the Unscarred
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15340; -- Moam
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15341; -- General Rajaxx
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15343; -- Qiraji Swarmguard
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15344; -- Swarmguard Needler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15348; -- Kurinnaxx
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15355; -- Anubisath Guardian
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15369; -- Ayamiss the Hunter
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15370; -- Buru the Gorger
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15380; -- Arygos
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15385; -- Colonel Zerran
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15386; -- Major Yeggeth
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15387; -- Qiraji Warrior
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15388; -- Major Pakkon
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15389; -- Captain Drenn
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15390; -- Captain Xurrem
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15391; -- Captain Qeez
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15392; -- Captain Tuubid
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15424; -- Anubisath Conqueror
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15426; -- Ahn'Qiraj Trigger
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15449; -- Hive'Zora Abomination
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15461; -- Shrieker Scarab
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15491; -- Eranikus, Tyrant of the Dream
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15505; -- Canal Frenzy
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15509; -- Princess Huhuran
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15510; -- Fankriss the Unyielding
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15511; -- Lord Kri
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15516; -- Battleguard Sartura
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15517; -- Ouro
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15521; -- Hive'Zara Hatchling
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15535; -- Chief Sharpclaw
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15539; -- General Zog
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15541; -- Twilight Marauder Morna
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15542; -- Twilight Marauder
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15543; -- Princess Yauj
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15544; -- Vem
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15546; -- Hive'Zara Swarmer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15554; -- Number Two
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15555; -- Hive'Zara Larva
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15571; -- Maws
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15590; -- Ossirian Crystal Trigger
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15591; -- Minion of Weavil
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15620; -- Hive'Regal Hunter-Killer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15623; -- Xandivious
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15629; -- Nightmare Phantasm
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15630; -- Spawn of Fankriss
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15685; -- Southsea Kidnapper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15695; -- Vek Twins Trigger
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15696; -- War Effort Recruit
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15702; -- Senior Sergeant Taiga
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15727; -- C'Thun
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15740; -- Colossus of Zora
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15741; -- Colossus of Regal
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15742; -- Colossus of Ashi
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15751; -- Anubisath Warbringer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15752; -- Silithid Flayer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15754; -- Greater Anubisath Warbringer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15775; -- Christmas Emperor Dagran Thaurissan
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15863; -- Darkspear Shaman
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15882; -- Pat's Firework Guy - RED
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15883; -- Pat's Firework Guy - YELLOW
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15892; -- Lunar Festival Emissary
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15893; -- Lunar Firework Credit Marker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15894; -- Lunar Cluster Credit Marker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15902; -- Giant Spotlight
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15918; -- Pat's Firework Cluster Guy (ELUNE)
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15929; -- Stalagg
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15930; -- Feugen
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15931; -- Grobbulus
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15932; -- Gluth
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15933; -- Poison Cloud
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15934; -- Hive'Zara Hornet
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15936; -- Heigan the Unclean
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15952; -- Maexxna
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15953; -- Grand Widow Faerlina
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15956; -- Anub'Rekhan
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15974; -- Dread Creeper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15975; -- Carrion Spinner
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15976; -- Venom Stalker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15978; -- Crypt Reaver
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15979; -- Tomb Horror
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15980; -- Naxxramas Cultist
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15981; -- Naxxramas Acolyte
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15984; -- Sartura's Royal Guard
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15989; -- Sapphiron
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16006; -- InCombat Trigger
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16011; -- Loatheb
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16013; -- Deliana
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16017; -- Patchwork Golem
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16018; -- Bile Retcher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16021; -- Living Monstrosity
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16022; -- Surgical Assistant
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16024; -- Embalming Slime
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16025; -- Stitched Spewer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16027; -- Living Poison
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16028; -- Patchwerk
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16029; -- Sludge Belcher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16034; -- Plague Beast
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16036; -- Frenzied Bat
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16037; -- Plagued Bat
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16042; -- Lord Valthalak
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16052; -- Malgen Longspear
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16053; -- Korv
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16055; -- Va'jashni
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16058; -- Volida
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16059; -- Theldren
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16060; -- Gothik the Harvester
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16061; -- Instructor Razuvious
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16062; -- Highlord Mograine
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16063; -- Sir Zeliek
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16065; -- Lady Blaumeux
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16066; -- Spectral Assassin
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16067; -- Deathcharger Steed
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16072; -- Tidelord Rrurgaz
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16097; -- Isalien
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16098; -- Empyrean
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16102; -- Sothos
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16103; -- Spirit of Jarien
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16104; -- Spirit of Sothos
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16117; -- Plagued Swine
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16119; -- Bone Minion
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16125; -- Unrelenting Deathknight
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16126; -- Unrelenting Rider
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16141; -- Ghoul Berserker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16145; -- Deathknight Captain
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16146; -- Deathknight
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16148; -- Spectral Deathknight
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16150; -- Spectral Rider
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16154; -- Risen Deathknight
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16157; -- Doom Touched Warrior
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16163; -- Deathknight Cavalier
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16165; -- Necro Knight
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16167; -- Bony Construct
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16184; -- Nerubian Overseer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16193; -- Skeletal Smith
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16194; -- Unholy Axe
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16215; -- Unholy Staff
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16216; -- Unholy Swords
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16243; -- Plague Slime
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16244; -- Infectious Ghoul
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16290; -- Fallout Slime
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16297; -- Mutated Grub
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16299; -- Skeletal Shocktrooper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16359; -- Argent Messenger
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16368; -- Necropolis Acolyte
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16375; -- Sewage Slime
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16379; -- Spirit of the Damned
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16380; -- Bone Witch
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16399; -- Bloodsail Traitor
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16441; -- Guardian of Icecrown
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16447; -- Plagued Ghoul
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16448; -- Plagued Deathhound
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16449; -- Spirit of Naxxramas
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16453; -- Necro Stalker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16479; -- Polymorph Clone
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16506; -- Naxxramas Worshipper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16573; -- Crypt Guard
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16803; -- Deathknight Understudy
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16980; -- The Lich King
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16981; -- Plagued Guardian
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 17055; -- Maexxna Spiderling

-- NPC stats clean up
UPDATE creature, creature_template SET creature.curhealth = creature_template.MinLevelHealth, creature.curmana = creature_template.MinLevelMana WHERE creature.id = creature_template.entry AND creature_template.RegenerateStats & 1;
