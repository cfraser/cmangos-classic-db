-- Adjusted drop chance of required items for quest 4503 (Shizzle's Flyer) in Un'Goro Crater
-- some had too high drop chance, other one had too low
UPDATE `creature_loot_template` SET `ChanceOrQuestChance` = -20 WHERE `item` IN (11830,11831);

-- Adjusted drop chance of required item for quest 3882 (Roll the Bones) in Un'Goro Crater
UPDATE `creature_loot_template` SET `ChanceOrQuestChance` = -28 WHERE `item` = 11114 AND `entry` IN (9162, 9163);
