
SET @PHALANX := '9502';

-- ---------------------

UPDATE `creature` SET `modelid`='0', `position_x`='847.848', `position_y`='-230.0667', `position_z`='-43.61398', `orientation`='1.64061', `spawntimesecs`='604800' WHERE `id`=@PHALANX;
