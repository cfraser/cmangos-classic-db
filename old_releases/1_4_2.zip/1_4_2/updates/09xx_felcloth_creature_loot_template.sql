-- Increased drop chance of item 14256 (Felcloth) from Legashi Satyrs
-- because it should be slightly higher than Jaednar Satyrs of lower level
UPDATE `creature_loot_template` SET `ChanceOrQuestChance` = 5 WHERE `item` = 14256 AND `entry` IN (6200, 6201, 6202);
