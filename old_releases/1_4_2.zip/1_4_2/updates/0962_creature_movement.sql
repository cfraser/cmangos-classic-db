
DELETE FROM `creature_movement` WHERE `id`='30639' and`point`='9';
DELETE FROM `creature_movement` WHERE `id`='30639' and`point`='8';

UPDATE `creature_movement` SET `point`='8' WHERE `id`='30639' and`point`='10';
UPDATE `creature_movement` SET `point`='9' WHERE `id`='30639' and`point`='11';
UPDATE `creature_movement` SET `point`='10' WHERE `id`='30639' and`point`='12';
UPDATE `creature_movement` SET `point`='11' WHERE `id`='30639' and`point`='13';
UPDATE `creature_movement` SET `point`='12' WHERE `id`='30639' and`point`='14';
UPDATE `creature_movement` SET `point`='13' WHERE `id`='30639' and`point`='15';
UPDATE `creature_movement` SET `point`='14' WHERE `id`='30639' and`point`='16';
UPDATE `creature_movement` SET `point`='15' WHERE `id`='30639' and`point`='17';
