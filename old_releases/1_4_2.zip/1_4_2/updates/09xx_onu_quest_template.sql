-- Fixed quest 961 (Onu is meditating) that should only be available while quest 944 (The Master Glaive) is active
-- This closes #719. Thanks to TheTrueAnimal for reporting
UPDATE `quest_template` SET `PrevQuestId` = -944 WHERE `entry` = 961;
