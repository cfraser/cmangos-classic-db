-- Temporary fix for old quests for replacing original fast mounts in Classic by the new ones
-- The proper texts are nowhere to be found, so placeholders based on the existing texts 
-- were made for the quests missing theirs.
-- Thanks @shnibble for reporting. This closes #680

-- STALLIONS
UPDATE `quest_template` SET `Details` = '', `RequestItemsText` =
'If you bring me your white stallion, I\'ll trade you for one from the new herd. The new horse will be just as fast as your old one, but have a different look to it. You can look at the swift steeds here to see what it will look like.'
WHERE `entry` = 7677;

UPDATE `quest_template` SET `Details` = '', `RequestItemsText` = 
'[PH] If you bring me your palomino, I\'ll trade it in for one from the new herd. The new horse will be just as fast as your old one, but have a different look to it. You can look at the swift steeds here to see what it will look like.'
WHERE `entry` = 7678;

-- MECHANOSTRIDERS
UPDATE `quest_template` SET `Details` = '', `RequestItemsText` = 
'[PH] If you bring me your old fast mechanostrider, I will trade it in for one from the new pack.   The new mechanostrider will be just as fast as your old one, but have a different look to it.   You can look at the swift mechanostriders we already have around the yard here to see what it will look like.'
WHERE `entry` IN (7675, 7676);

-- RAMS
UPDATE `quest_template` SET `Details` = '', `RequestItemsText` = 
'[PH] Ye bring me yer old ram, I will trade it in for one from the new pack!  The new ram will be just as fast as yer old one, but with a new look to him.   You can look at the swift rams here to see what ye will have to choose from.'
WHERE `entry` IN (7673, 7674);

-- SABERS
UPDATE `quest_template` SET `Details` = '', `RequestItemsText` = 
'[PH] If you bring me your old frostsaber, I will trade it in for one from the new pack.   The new swift saber will be just as fast as your old one, but have a different look to it.   You can look at the swift sabers we already have around the yard here to see what it will look like.'
WHERE `entry` = 7671;

UPDATE `quest_template` SET `Details` = '', `RequestItemsText` = 
'[PH] If you bring me your old nightsaber, I will trade it in for one from the new pack.   The new swift saber will be just as fast as your old one, but have a different look to it.   You can look at the swift sabers we already have around the yard here to see what it will look like.'
WHERE `entry` = 7672;