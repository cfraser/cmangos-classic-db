-- Linking for Ambassador Flamelash
DELETE FROM creature_linking_template WHERE entry=9178;
INSERT INTO creature_linking_template VALUES
(9178,230,9156,4112,0);
