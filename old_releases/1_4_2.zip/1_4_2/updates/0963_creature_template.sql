
UPDATE `creature_template` SET `FactionAlliance`='7', `FactionHorde`='7', `MeleeBaseAttackTime`='2000', `RangedBaseAttackTime`='2000' WHERE `Entry`='9178';
