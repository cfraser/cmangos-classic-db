
UPDATE `quest_template` SET `RequiredRaces`='255', `RewMoneyMaxLevel`='4160' WHERE `entry`='3321';
