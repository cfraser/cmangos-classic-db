
UPDATE `dbscripts_on_quest_end` SET `command`='5' WHERE `id`='943' AND `delay`='0';
UPDATE `dbscripts_on_quest_end` SET `command`='4' WHERE `id`='943' AND `delay`='66';
