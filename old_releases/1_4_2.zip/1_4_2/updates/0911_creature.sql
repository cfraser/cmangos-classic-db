


-- --------------

UPDATE `creature` SET `spawndist`='30', `MovementType`='1' WHERE `id`='5937';
