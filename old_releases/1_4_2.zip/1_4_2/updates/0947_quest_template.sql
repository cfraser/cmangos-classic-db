
UPDATE `quest_template` SET `PrevQuestId`='3451' WHERE `entry`='3483';
