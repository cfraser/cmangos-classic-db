-- Fixed stats of some of the utility NPCs (spawners and triggers)
UPDATE `creature_template` SET `FactionAlliance` = 35, `FactionHorde` = 35, `MinLevel` = 1, `MaxLevel` = 1, `UnitFlags` = 33555200, `ExtraFlags` = 130, `MinLevelHealth` = 42, `MaxLevelHealth` = 42, `MinLevelMana` = 0, `MaxLevelMana` = 0, `MinMeleeDmg` = 2, `MaxMeleeDmg` = 2, `MinRangedDmg` = 0, `MaxRangedDmg` = 0, `Armor` = 0, `MeleeAttackPower` = 1, `RangedAttackPower` = 0, `SpeedWalk` = 1, `HealthMultiplier` = 1, `ArmorMultiplier` = 1 WHERE `name` LIKE 'Pat\'s Firework%';

UPDATE `creature_template` SET `MinLevel` = 1, `MaxLevel` = 1, `UnitFlags` = 33555200, `ExtraFlags` = 130, `MinLevelHealth` = 42, `MaxLevelHealth` = 42, `MinLevelMana` = 0, `MaxLevelMana` = 0, `MinMeleeDmg` = 2, `MaxMeleeDmg` = 2, `MinRangedDmg` = 0, `MaxRangedDmg` = 0, `Armor` = 0, `MeleeAttackPower` = 1, `RangedAttackPower` = 0, `SpeedWalk` = 1, `HealthMultiplier` = 1, `ArmorMultiplier` = 1 WHERE `name` LIKE '%trigger%';

UPDATE `creature_template` SET `MinLevel` = 1, `MaxLevel` = 1, `UnitFlags` = 33555200, `ExtraFlags` = 130, `MinLevelHealth` = 42, `MaxLevelHealth` = 42, `MinLevelMana` = 0, `MaxLevelMana` = 0, `MinMeleeDmg` = 2, `MaxMeleeDmg` = 2, `MinRangedDmg` = 0, `MaxRangedDmg` = 0, `Armor` = 0, `MeleeAttackPower` = 1, `RangedAttackPower` = 0, `SpeedWalk` = 1, `ArmorMultiplier` = 1 WHERE `name` LIKE '%spawner%';

UPDATE `creature_template` SET `MinLevel` = 1, `MaxLevel` = 1, `UnitFlags` = 33555200, `ExtraFlags` = 130, `MinLevelHealth` = 42, `MaxLevelHealth` = 42, `MinLevelMana` = 0, `MaxLevelMana` = 0, `MinMeleeDmg` = 2, `MaxMeleeDmg` = 2, `MinRangedDmg` = 0, `MaxRangedDmg` = 0, `Armor` = 0, `MeleeAttackPower` = 1, `RangedAttackPower` = 0, `SpeedWalk` = 1, `ArmorMultiplier` = 1 WHERE `name` LIKE '%Festival Flamekeeper Costume%';

UPDATE `creature_template` SET `MinLevel` = 1, `MaxLevel` = 1,  `MinLevelHealth` = 57, `MaxLevelHealth` = 57, `MinLevelMana` = 0, `MaxLevelMana` = 0, `MinMeleeDmg` = 2, `MaxMeleeDmg` = 2, `MinRangedDmg` = 0, `MaxRangedDmg` = 0, `Armor` = 0, `MeleeAttackPower` = 1, `RangedAttackPower` = 0, `SpeedWalk` = 1, `ArmorMultiplier` = 1 WHERE `Entry` = 12536;

UPDATE `creature_template` SET `MinLevelHealth` = 3052, `MaxLevelHealth` = 3052, `MinLevelMana` = 0, `MaxLevelMana` = 0, `ArmorMultiplier` = 1 WHERE `Entry` = 11446; -- Gordok Spirit

-- Waypoint (Only GM can see it)
UPDATE creature_template SET MinLevelHealth=42, MaxLevelHealth=42, MinLevelMana=0, MaxLevelMana=0, Minlevel=1, MaxLevel=1, UnitClass = 1, Rank=0 WHERE entry=1;

-- Spawnpoint (Only GM can see it)
UPDATE creature_template SET MinLevelHealth=42, MaxLevelHealth=42, MinLevelMana=0, MaxLevelMana=0, Minlevel=1, MaxLevel=1, UnitClass = 1, Rank=0, `ArmorMultiplier` = 1 WHERE entry=2;

-- NPC stats clean up
UPDATE creature, creature_template SET creature.curhealth = creature_template.MinLevelHealth, creature.curmana = creature_template.MinLevelMana WHERE creature.id = creature_template.entry AND creature_template.RegenerateStats & 1;
