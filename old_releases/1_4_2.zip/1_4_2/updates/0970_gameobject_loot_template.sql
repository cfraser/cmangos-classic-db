
UPDATE `gameobject_loot_template` SET `ChanceOrQuestChance`='-10' WHERE `entry`='9677' and`item`='10715';
UPDATE `gameobject_loot_template` SET `ChanceOrQuestChance`='-10' WHERE `entry`='9677' and`item`='10717';
UPDATE `gameobject_loot_template` SET `ChanceOrQuestChance`='-10' WHERE `entry`='9677' and`item`='10718';
UPDATE `gameobject_loot_template` SET `ChanceOrQuestChance`='-10' WHERE `entry`='9677' and`item`='10722';
