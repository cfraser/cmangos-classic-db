-- Source: http://www.wowwiki.com/Cenarion_Beacon

SET @CORRUPTED_DESPAWN   := 3595;
SET @CLEANSED_DESPAWN 	 := -3595;
SET @CLEANSED_REACTIVATE := 25 * 60;

-- ----------------------------
-- SONGLOWERS 
-- ----------------------------

SET @GUID := 900000;

-- Fixed wrong entries in Classic DB (backported from UDB and fixed)
DELETE FROM `gameobject_template` WHERE `name` LIKE '%Songflower';
INSERT INTO `gameobject_template` (`entry`, `type`, `displayId`, `name`, `faction`, `flags`, `size`, `data0`, `data1`, `data2`, `data3`, `data4`, `data5`, `data6`, `data7`, `data8`, `data9`, `data10`, `data11`, `data12`, `data13`, `data14`, `data15`, `data16`, `data17`, `data18`, `data19`, `data20`, `data21`, `data22`, `data23`, `mingold`, `maxgold`, `ScriptName`) VALUES 
(164886, 2, 3231, 'Corrupted Songflower', 0, 4, 2, 0, 2523, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(171939, 2, 3231, 'Corrupted Songflower', 0, 4, 2, 0, 4465, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(171942, 2, 3231, 'Corrupted Songflower', 0, 4, 2, 0, 4464, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(174594, 2, 3231, 'Corrupted Songflower', 0, 4, 2, 0, 2878, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(174595, 2, 3231, 'Corrupted Songflower', 0, 4, 2, 0, 3363, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(174596, 2, 3231, 'Corrupted Songflower', 0, 4, 2, 0, 4113, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(174597, 2, 3231, 'Corrupted Songflower', 0, 4, 2, 0, 4114, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(174598, 2, 3231, 'Corrupted Songflower', 0, 4, 2, 0, 4116, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(174712, 2, 3231, 'Corrupted Songflower', 0, 4, 2, 0, 4118, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(174713, 2, 3231, 'Corrupted Songflower', 0, 4, 2, 0, 4401, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),

(174714, 10, 3232, 'Cleansed Songflower', 0, 0, 2, 259, 0, 4276, 0, 0, 0, 0, 0, 0, 0, 15366, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(174715, 10, 3232, 'Cleansed Songflower', 0, 0, 2, 259, 0, 4280, 0, 0, 0, 0, 0, 0, 0, 15366, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(164882, 10, 3232, 'Cleansed Songflower', 0, 0, 2, 259, 0, 4059, 0, 0, 0, 0, 0, 0, 0, 15366, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(171940, 10, 3232, 'Cleansed Songflower', 0, 0, 2, 259, 0, 4079, 0, 0, 0, 0, 0, 0, 0, 15366, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(171943, 10, 3232, 'Cleansed Songflower', 0, 0, 2, 259, 0, 2244, 0, 0, 0, 0, 0, 0, 0, 15366, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(174610, 10, 3232, 'Cleansed Songflower', 0, 0, 2, 259, 0, 4215, 0, 0, 0, 0, 0, 0, 0, 15366, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(174612, 10, 3232, 'Cleansed Songflower', 0, 0, 2, 259, 0, 4216, 0, 0, 0, 0, 0, 0, 0, 15366, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(174613, 10, 3232, 'Cleansed Songflower', 0, 0, 2, 259, 0, 4217, 0, 0, 0, 0, 0, 0, 0, 15366, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(174614, 10, 3232, 'Cleansed Songflower', 0, 0, 2, 259, 0, 4218, 0, 0, 0, 0, 0, 0, 0, 15366, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(174615, 10, 3232, 'Cleansed Songflower', 0, 0, 2, 259, 0, 4219, 0, 0, 0, 0, 0, 0, 0, 15366, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');

DELETE FROM `gameobject` WHERE `id` IN (SELECT `entry` FROM `gameobject_template` WHERE `name` LIKE '%Songflower');

-- Added missing gameobject spawn (cleansed was spawned but not related to corrupted and vice versa)
DELETE FROM `gameobject` WHERE `guid` BETWEEN @GUID +1 AND @GUID + 20;
INSERT INTO `gameobject` VALUES 
-- Corrupted Songflowers
(@GUID + 01, 164886, 1, 3723.64, -1402.23, 200.395, 5.30595, 0, 0, 0.469405, -0.882983, 180, 100, 1),
(@GUID + 02, 171939, 1, 3856.6, -1014.86, 241.341, 5.6366, 0, 0, 0.31769, -0.948195, 180, 100, 1),
(@GUID + 03, 171942, 1, 4191.83, -1147.7, 315.197, 2.72276, 0, 0, 0.978153, 0.207887, 180, 100, 1),
(@GUID + 04, 174594, 1, 4959.46, -681.357, 294.914, 4.67448, 0, 0, 0.720383, -0.693577, 180, 100, 1),
(@GUID + 05, 174595, 1, 6900, -2033.33, 583.696, 1.81514, 0, 0, 0.788011, 0.615662, 180, 100, 1),
(@GUID + 06, 174596, 1, 6733.31, -1566.68, 477.04, -2.82743, 0, 0, 0.987688, -0.156434, 180, 100, 1),
(@GUID + 07, 174597, 1, 6297.82, -1972.49, 562.09, 5.38682, 0, 0, 0.433329, -0.901236, 180, 100, 1),
(@GUID + 08, 174598, 1, 6599.99, -1266.66, 448.401, 1.98968, 0, 0, 0.838671, 0.544639, 180, 100, 1),
(@GUID + 09, 174712, 1, 6724.35, -1578.87, 475.274, 2.44158, 0, 0, 0.93937, 0.342906, 180, 0, 1),
(@GUID + 10, 174713, 1, 6868.36, -2025.77, 577.324, 2.49261, 0, 0, 0.947813, 0.318828, 180, 0, 1),
-- Cleansed Songflowers
(@GUID + 11, 164882, 1, 3723.64, -1402.23, 200.395, 5.30595, 0, 0, 0.469405, -0.882983, 180, 100, 1),
(@GUID + 12, 171940, 1, 3856.6, -1014.86, 241.341, 5.6366, 0, 0, 0.31769, -0.948195, 180, 100, 1),
(@GUID + 13, 171943, 1, 4191.83, -1147.7, 315.197, 2.72276, 0, 0, 0.978153, 0.207887, 180, 100, 1),
(@GUID + 14, 174610, 1, 4959.46, -681.357, 294.914, 4.67448, 0, 0, 0.720383, -0.693577, 180, 100, 1),
(@GUID + 15, 174612, 1, 6900, -2033.33, 583.696, 1.81514, 0, 0, 0.788011, 0.615662, 180, 100, 1),
(@GUID + 16, 174613, 1, 6733.31, -1566.68, 477.04, -2.82743, 0, 0, 0.987688, -0.156434, 180, 100, 1),
(@GUID + 17, 174614, 1, 6297.82, -1972.49, 562.09, 5.38682, 0, 0, 0.433329, -0.901236, 180, 100, 1),
(@GUID + 18, 174615, 1, 6599.99, -1266.66, 448.401, 1.98968, 0, 0, 0.838671, 0.544639, 180, 100, 1),
(@GUID + 19, 174714, 1, 6724.35, -1578.87, 475.274, 2.44158, 0, 0, 0.93937, 0.342906, 180, 0, 1),
(@GUID + 20, 174715, 1, 6868.36, -2025.77, 577.324, 2.49261, 0, 0, 0.947813, 0.318828, 180, 0, 1);

-- ----------------------
-- Songflower 
-- ----------------------
UPDATE `dbscripts_on_quest_end` SET `datalong` = @GUID + 11 WHERE `id` = 2523;
INSERT INTO `dbscripts_on_quest_end` VALUES
(2523, 0, 27, 4, 0, 164886, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(2523, @CORRUPTED_DESPAWN, 27, 8, 0, 164886, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
DELETE FROM `dbscripts_on_event` WHERE `id` = 4059;
INSERT INTO `dbscripts_on_event` VALUES
(4059, 0, 15, 15366, 0, 0, 0, 0x02, 0, 0, 0, 0, 0, 0, 0, 0, '');
-- (4059, 5, 27, 8, 0, 164886, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
UPDATE `gameobject_questrelation` SET `id` = 164886 WHERE `quest` = 2523;
UPDATE `gameobject_involvedrelation` SET `id` = 164886 WHERE `quest` = 2523;

UPDATE `dbscripts_on_quest_end` SET `datalong` = @GUID + 12 WHERE `id` = 4465;
INSERT INTO `dbscripts_on_quest_end` VALUES
(4465, 0, 27, 4, 0, 171939, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(4465, @CORRUPTED_DESPAWN, 27, 8, 0, 171939, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
DELETE FROM `dbscripts_on_event` WHERE `id` = 4079;
INSERT INTO `dbscripts_on_event` VALUES
(4079, 0, 15, 15366, 0, 0, 0, 0x02, 0, 0, 0, 0, 0, 0, 0, 0, '');
-- (4079, 5, 27, 8, 0, 171939, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
UPDATE `gameobject_questrelation` SET `id` = 171939 WHERE `quest` = 4465;
UPDATE `gameobject_involvedrelation` SET `id` = 171939 WHERE `quest` = 4465;

UPDATE `dbscripts_on_quest_end` SET `datalong` = @GUID + 13 WHERE `id` = 4464;
INSERT INTO `dbscripts_on_quest_end` VALUES
(4464, 0, 27, 4, 0, 171942, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(4464, @CORRUPTED_DESPAWN, 27, 8, 0, 171942, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
DELETE FROM `dbscripts_on_event` WHERE `id` = 2244;
INSERT INTO `dbscripts_on_event` VALUES
(2244, 0, 15, 15366, 0, 0, 0, 0x02, 0, 0, 0, 0, 0, 0, 0, 0, '');
-- (2244, 5, 27, 8, 0, 171942, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
UPDATE `gameobject_questrelation` SET `id` = 171942 WHERE `quest` = 4464;
UPDATE `gameobject_involvedrelation` SET `id` = 171942 WHERE `quest` = 4464;

UPDATE `dbscripts_on_quest_end` SET `datalong` = @GUID + 14 WHERE `id` = 2878;
INSERT INTO `dbscripts_on_quest_end` VALUES
(2878, 0, 27, 4, 0, 174594, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(2878, @CORRUPTED_DESPAWN, 27, 8, 0, 174594, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
DELETE FROM `dbscripts_on_event` WHERE `id` = 4215;
INSERT INTO `dbscripts_on_event` VALUES
(4215, 0, 15, 15366, 0, 0, 0, 0x02, 0, 0, 0, 0, 0, 0, 0, 0, '');
-- (4215, 5, 27, 8, 0, 174594, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
UPDATE `gameobject_questrelation` SET `id` = 174594 WHERE `quest` = 2878;
UPDATE `gameobject_involvedrelation` SET `id` = 174594 WHERE `quest` = 2878;

UPDATE `dbscripts_on_quest_end` SET `datalong` = @GUID + 15 WHERE `id` = 3363;
INSERT INTO `dbscripts_on_quest_end` VALUES
(3363, 0, 27, 4, 0, 174595, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(3363, @CORRUPTED_DESPAWN, 27, 8, 0, 174595, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
DELETE FROM `dbscripts_on_event` WHERE `id` = 4216;
INSERT INTO `dbscripts_on_event` VALUES
(4216, 0, 15, 15366, 0, 0, 0, 0x02, 0, 0, 0, 0, 0, 0, 0, 0, '');
-- (4216, 5, 27, 8, 0, 174595, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
UPDATE `gameobject_questrelation` SET `id` = 174595 WHERE `quest` = 3363;
UPDATE `gameobject_involvedrelation` SET `id` = 174595 WHERE `quest` = 3363;

UPDATE `dbscripts_on_quest_end` SET `datalong` = @GUID + 16 WHERE `id` = 4113;
INSERT INTO `dbscripts_on_quest_end` VALUES
(4113, 0, 27, 4, 0, 174596, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(4113, @CORRUPTED_DESPAWN, 27, 8, 0, 174596, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
DELETE FROM `dbscripts_on_event` WHERE `id` = 4217;
INSERT INTO `dbscripts_on_event` VALUES
(4217, 0, 15, 15366, 0, 0, 0, 0x02, 0, 0, 0, 0, 0, 0, 0, 0, '');
-- (4217, 5, 27, 8, 0, 174596, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
UPDATE `gameobject_questrelation` SET `id` = 174596 WHERE `quest` = 4113;
UPDATE `gameobject_involvedrelation` SET `id` = 174596 WHERE `quest` = 4113;

UPDATE `dbscripts_on_quest_end` SET `datalong` = @GUID + 17 WHERE `id` = 4114;
INSERT INTO `dbscripts_on_quest_end` VALUES
(4114, 0, 27, 4, 0, 174597, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(4114, @CORRUPTED_DESPAWN, 27, 8, 0, 174597, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
DELETE FROM `dbscripts_on_event` WHERE `id` = 4218;
INSERT INTO `dbscripts_on_event` VALUES
(4218, 0, 15, 15366, 0, 0, 0, 0x02, 0, 0, 0, 0, 0, 0, 0, 0, '');
-- (4218, 5, 27, 8, 0, 174597, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
UPDATE `gameobject_questrelation` SET `id` = 174597 WHERE `quest` = 4114;
UPDATE `gameobject_involvedrelation` SET `id` = 174597 WHERE `quest` = 4114;

UPDATE `dbscripts_on_quest_end` SET `datalong` = @GUID + 18 WHERE `id` = 4116;
INSERT INTO `dbscripts_on_quest_end` VALUES
(4116, 0, 27, 4, 0, 174598, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(4116, @CORRUPTED_DESPAWN, 27, 8, 0, 174598, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
DELETE FROM `dbscripts_on_event` WHERE `id` = 4219;
INSERT INTO `dbscripts_on_event` VALUES
(4219, 0, 15, 15366, 0, 0, 0, 0x02, 0, 0, 0, 0, 0, 0, 0, 0, '');
-- (4219, 5, 27, 8, 0, 174598, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
UPDATE `gameobject_questrelation` SET `id` = 174598 WHERE `quest` = 4116;
UPDATE `gameobject_involvedrelation` SET `id` = 174598 WHERE `quest` = 4116;

UPDATE `dbscripts_on_quest_end` SET `datalong` = @GUID + 19 WHERE `id` = 4118;
INSERT INTO `dbscripts_on_quest_end` VALUES
(4118, 0, 27, 4, 0, 174712, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(4118, @CORRUPTED_DESPAWN, 27, 8, 0, 174712, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
DELETE FROM `dbscripts_on_event` WHERE `id` = 4276;
INSERT INTO `dbscripts_on_event` VALUES
(4276, 0, 15, 15366, 0, 0, 0, 0x02, 0, 0, 0, 0, 0, 0, 0, 0, '');
-- (4276, 5, 27, 8, 0, 174712, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
UPDATE `gameobject_questrelation` SET `id` = 174712 WHERE `quest` = 4118;
UPDATE `gameobject_involvedrelation` SET `id` = 174712 WHERE `quest` = 4118;

UPDATE `dbscripts_on_quest_end` SET `datalong` = @GUID + 20 WHERE `id` = 4401;
INSERT INTO `dbscripts_on_quest_end` VALUES
(4401, 0, 27, 4, 0, 174713, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(4401, @CORRUPTED_DESPAWN, 27, 8, 0, 174713, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
DELETE FROM `dbscripts_on_event` WHERE `id` = 4280;
INSERT INTO `dbscripts_on_event` VALUES
(4280, 0, 15, 15366, 0, 0, 0, 0x02, 0, 0, 0, 0, 0, 0, 0, 0, '');
-- (4280, 5, 27, 8, 0, 174713, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
UPDATE `gameobject_questrelation` SET `id` = 174713 WHERE `quest` = 4401;
UPDATE `gameobject_involvedrelation` SET `id` = 174713 WHERE `quest` = 4401;


-- Cleanup
-- Fixed animation of spawned gameobjects
UPDATE `gameobject` SET `animprogress` = 100 WHERE `id` IN (SELECT `entry` FROM `gameobject_template` WHERE `name` LIKE '%Songflower');
-- Fixed cooldown of cleansed GO
UPDATE `gameobject_template` SET `data6` = @CLEANSED_REACTIVATE WHERE `name` = 'Cleansed Songflower';
-- Make corrupted GO usable
UPDATE `gameobject_template` SET `flags` = 0 WHERE `name` = 'Corrupted Songflower';
-- Fixed spawn time (corrupted already spawned, cleansed despawned)
UPDATE `gameobject` SET `spawntimesecs` = @CORRUPTED_DESPAWN WHERE `id` IN (SELECT `entry` FROM `gameobject_template` WHERE `name` = 'Corrupted Songflower');
UPDATE `gameobject` SET `spawntimesecs` = @CLEANSED_DESPAWN WHERE `id` IN (SELECT `entry` FROM `gameobject_template` WHERE `name` = 'Cleansed Songflower');

UPDATE `quest_template` SET `RequiredRaces` = 255 WHERE `Title` = 'Corrupted Songflower';
