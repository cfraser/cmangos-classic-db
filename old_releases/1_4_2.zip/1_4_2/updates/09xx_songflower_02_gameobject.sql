-- Source: http://www.wowwiki.com/Cenarion_Beacon

SET @CORRUPTED_DESPAWN   := 3595;
SET @CLEANSED_DESPAWN 	 := -3595;
SET @CLEANSED_REACTIVATE := 25 * 60;

-- ----------------------------
-- WINDBLOSSOMS 
-- ----------------------------

SET @GUID := 900000;

DELETE FROM `gameobject` WHERE `id` IN (SELECT `entry` FROM `gameobject_template` WHERE `name` LIKE '%Windblossom');

DELETE FROM `gameobject` WHERE `guid` BETWEEN @GUID + 21 AND @GUID + 40;
INSERT INTO `gameobject` VALUES
-- Corrupted Windblossoms
(@GUID + 21, 164887, 1, 4066.66, -1233.34, 282.075, -1.15192, 0, 0, -0.54464, 0.83867, 180, 100, 1),
(@GUID + 22, 173327, 1, 5533.32, -933, 376.883, 1.222, 0, 0, 0.573687, 0.819075, 180, 100, 1),
(@GUID + 23, 174599, 1, 6233.34, -1533.33, 441.796, 0, 0, 0, 0, 1, 180, 100, 1),
(@GUID + 24, 174600, 1, 6271.71, -605.54, 469.165, 2.69449, 0, 0, 0.975116, 0.221694, 180, 100, 1),
(@GUID + 25, 174601, 1, 6422.47, -957.439, 423.074, 4.52048, 0, 0, 0.7716, -0.636108, 180, 100, 1),
(@GUID + 26, 174602, 1, 4774.45, -484.409, 330.46, 2.52721, 0, 0, 0.953187, 0.302383, 180, 100, 1),
(@GUID + 27, 174603, 1, 5259.69, -351.762, 322.032, 4.56296, 0, 0, 0.757916, -0.652352, 180, 100, 1),
(@GUID + 28, 174604, 1, 5539.47, -932.794, 378.093, 0.13724, 0, 0, 0.0685662, 0.997647, 180, 100, 1),
(@GUID + 29, 174708, 1, 6268.1, -1520.2, 442.386, 0.748996, 0, 0, 0.365805, 0.930691, 180, 100, 1),
(@GUID + 30, 174709, 1, 6366.73, -1666.05, 480.158, 1.08907, 0, 0, 0.51802, 0.855368, 180, 100, 1),
-- Cleansed Windblossoms
(@GUID + 31, 164884, 1, 4066.66, -1233.34, 282.075, -1.15192, 0, 0, -0.54464, 0.83867, -180, 100, 1),
(@GUID + 32, 174711, 1, 5533.32, -933, 376.883, 1.222, 0, 0, 0.573687, 0.819075, -180, 100, 1),
(@GUID + 33, 173326, 1, 6233.34, -1533.33, 441.796, 0, 0, 0, 0, 1, -180, 100, 1),
(@GUID + 34, 174619, 1, 6271.71, -605.54, 469.165, 2.69449, 0, 0, 0.975116, 0.221694, -180, 100, 1),
(@GUID + 35, 174620, 1, 6422.47, -957.439, 423.074, 4.52048, 0, 0, 0.7716, -0.636108, -180, 100, 1),
(@GUID + 36, 174616, 1, 4774.45, -484.409, 330.46, 2.52721, 0, 0, 0.953187, 0.302383, -180, 100, 1),
(@GUID + 37, 174617, 1, 5259.69, -351.762, 322.032, 4.56296, 0, 0, 0.757916, -0.652352, -180, 100, 1),
(@GUID + 38, 174618, 1, 5539.47, -932.794, 378.093, 0.13724, 0, 0, 0.0685662, 0.997647, -180, 100, 1),
(@GUID + 39, 174621, 1, 6268.1, -1520.2, 442.386, 0.748996, 0, 0, 0.365805, 0.930691, -180, 100, 1),
(@GUID + 40, 174710, 1, 6366.73, -1666.05, 480.158, 1.08907, 0, 0, 0.51802, 0.855368, -180, 100, 1);

-- ----------------------
-- Windblossom 
-- ----------------------
UPDATE `dbscripts_on_quest_end` SET `datalong` = @GUID + 31 WHERE `id` = 4343;
INSERT INTO `dbscripts_on_quest_end` VALUES
(4343, 0, 27, 4, 0, 164887, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(4343, @CORRUPTED_DESPAWN, 27, 8, 0, 164887, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
DELETE FROM `dbscripts_on_event` WHERE `id` = 4102;
INSERT INTO `dbscripts_on_event` VALUES
(4102, 0, 15, 15342, 0, 0, 0, 0x02, 0, 0, 0, 0, 0, 0, 0, 0, '');
-- (4102, 5, 27, 8, 0, 164887, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
UPDATE `gameobject_questrelation` SET `id` = 164887 WHERE `quest` = 4343;
UPDATE `gameobject_involvedrelation` SET `id` = 164887 WHERE `quest` = 4343;

UPDATE `dbscripts_on_quest_end` SET `datalong` = @GUID + 32 WHERE `id` = 4115;
INSERT INTO `dbscripts_on_quest_end` VALUES
(4115, 0, 27, 4, 0, 173327, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(4115, @CORRUPTED_DESPAWN, 27, 8, 0, 173327, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
DELETE FROM `dbscripts_on_event` WHERE `id` = 4288;
INSERT INTO `dbscripts_on_event` VALUES
(4288, 0, 15, 15342, 0, 0, 0, 0x02, 0, 0, 0, 0, 0, 0, 0, 0, '');
-- (4288, 5, 27, 8, 0, 173327, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
UPDATE `gameobject_questrelation` SET `id` = 173327 WHERE `quest` = 4115;
UPDATE `gameobject_involvedrelation` SET `id` = 173327 WHERE `quest` = 4115;

UPDATE `dbscripts_on_quest_end` SET `datalong` = @GUID + 33 WHERE `id` = 4221;
INSERT INTO `dbscripts_on_quest_end` VALUES
(4221, 0, 27, 4, 0, 174599, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(4221, @CORRUPTED_DESPAWN, 27, 8, 0, 174599, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
DELETE FROM `dbscripts_on_event` WHERE `id` = 4185;
INSERT INTO `dbscripts_on_event` VALUES
(4185, 0, 15, 15342, 0, 0, 0, 0x02, 0, 0, 0, 0, 0, 0, 0, 0, '');
-- (4185, 5, 27, 8, 0, 174599, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
UPDATE `gameobject_questrelation` SET `id` = 174599 WHERE `quest` = 4221;
UPDATE `gameobject_involvedrelation` SET `id` = 174599 WHERE `quest` = 4221;

UPDATE `dbscripts_on_quest_end` SET `datalong` = @GUID + 34 WHERE `id` = 4222;
INSERT INTO `dbscripts_on_quest_end` VALUES
(4222, 0, 27, 4, 0, 174600, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(4222, @CORRUPTED_DESPAWN, 27, 8, 0, 174600, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
DELETE FROM `dbscripts_on_event` WHERE `id` = 4195;
INSERT INTO `dbscripts_on_event` VALUES
(4195, 0, 15, 15342, 0, 0, 0, 0x02, 0, 0, 0, 0, 0, 0, 0, 0, '');
-- (4195, 5, 27, 8, 0, 174600, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
UPDATE `gameobject_questrelation` SET `id` = 174600 WHERE `quest` = 4222;
UPDATE `gameobject_involvedrelation` SET `id` = 174600 WHERE `quest` = 4222;

UPDATE `dbscripts_on_quest_end` SET `datalong` = @GUID + 35 WHERE `id` = 4403;
INSERT INTO `dbscripts_on_quest_end` VALUES
(4403, 0, 27, 4, 0, 174601, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(4403, @CORRUPTED_DESPAWN, 27, 8, 0, 174601, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
DELETE FROM `dbscripts_on_event` WHERE `id` = 4196;
INSERT INTO `dbscripts_on_event` VALUES
(4196, 0, 15, 15342, 0, 0, 0, 0x02, 0, 0, 0, 0, 0, 0, 0, 0, '');
-- (4196, 5, 27, 8, 0, 174601, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
UPDATE `gameobject_questrelation` SET `id` = 174601 WHERE `quest` = 4403;
UPDATE `gameobject_involvedrelation` SET `id` = 174601 WHERE `quest` = 4403;

UPDATE `dbscripts_on_quest_end` SET `datalong` = @GUID + 36 WHERE `id` = 996;
INSERT INTO `dbscripts_on_quest_end` VALUES
(996, 0, 27, 4, 0, 174602, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(996, @CORRUPTED_DESPAWN, 27, 8, 0, 174602, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
DELETE FROM `dbscripts_on_event` WHERE `id` = 4192;
INSERT INTO `dbscripts_on_event` VALUES
(4192, 0, 15, 15342, 0, 0, 0, 0x02, 0, 0, 0, 0, 0, 0, 0, 0, '');
-- (4192, 5, 27, 8, 0, 174602, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
UPDATE `gameobject_questrelation` SET `id` = 174602 WHERE `quest` = 996;
UPDATE `gameobject_involvedrelation` SET `id` = 174602 WHERE `quest` = 996;

UPDATE `dbscripts_on_quest_end` SET `datalong` = @GUID + 37 WHERE `id` = 998;
INSERT INTO `dbscripts_on_quest_end` VALUES
(998, 0, 27, 4, 0, 174603, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(998, @CORRUPTED_DESPAWN, 27, 8, 0, 174603, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
DELETE FROM `dbscripts_on_event` WHERE `id` = 4193;
INSERT INTO `dbscripts_on_event` VALUES
(4193, 0, 15, 15342, 0, 0, 0, 0x02, 0, 0, 0, 0, 0, 0, 0, 0, '');
-- (4193, 5, 27, 8, 0, 174603, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
UPDATE `gameobject_questrelation` SET `id` = 174603 WHERE `quest` = 998;
UPDATE `gameobject_involvedrelation` SET `id` = 174603 WHERE `quest` = 998;

UPDATE `dbscripts_on_quest_end` SET `datalong` = @GUID + 38 WHERE `id` = 4466;
INSERT INTO `dbscripts_on_quest_end` VALUES
(4466, 0, 27, 4, 0, 174604, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(4466, @CORRUPTED_DESPAWN, 27, 8, 0, 174604, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
DELETE FROM `dbscripts_on_event` WHERE `id` = 4194;
INSERT INTO `dbscripts_on_event` VALUES
(4194, 0, 15, 15342, 0, 0, 0, 0x02, 0, 0, 0, 0, 0, 0, 0, 0, '');
-- (4194, 5, 27, 8, 0, 174604, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
UPDATE `gameobject_questrelation` SET `id` = 174604 WHERE `quest` = 4466;
UPDATE `gameobject_involvedrelation` SET `id` = 174604 WHERE `quest` = 4466;

UPDATE `dbscripts_on_quest_end` SET `datalong` = @GUID + 39 WHERE `id` = 4467;
INSERT INTO `dbscripts_on_quest_end` VALUES
(4467, 0, 27, 4, 0, 174708, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(4467, @CORRUPTED_DESPAWN, 27, 8, 0, 174708, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
DELETE FROM `dbscripts_on_event` WHERE `id` = 4197;
INSERT INTO `dbscripts_on_event` VALUES
(4197, 0, 15, 15342, 0, 0, 0, 0x02, 0, 0, 0, 0, 0, 0, 0, 0, '');
-- (4197, 5, 27, 8, 0, 174708, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
UPDATE `gameobject_questrelation` SET `id` = 174708 WHERE `quest` = 4467;
UPDATE `gameobject_involvedrelation` SET `id` = 174708 WHERE `quest` = 4467;

UPDATE `dbscripts_on_quest_end` SET `datalong` = @GUID + 40 WHERE `id` = 1514;
INSERT INTO `dbscripts_on_quest_end` VALUES
(1514, 0, 27, 4, 0, 174709, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(1514, @CORRUPTED_DESPAWN, 27, 8, 0, 174709, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
DELETE FROM `dbscripts_on_event` WHERE `id` = 4284;
INSERT INTO `dbscripts_on_event` VALUES
(4284, 0, 15, 15342, 0, 0, 0, 0x02, 0, 0, 0, 0, 0, 0, 0, 0, '');
-- (4284, 5, 27, 8, 0, 174709, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
UPDATE `gameobject_questrelation` SET `id` = 174709 WHERE `quest` = 1514;
UPDATE `gameobject_involvedrelation` SET `id` = 174709 WHERE `quest` = 1514;


-- Cleanup
-- Fixed animation of spawned gameobjects
UPDATE `gameobject` SET `animprogress` = 100 WHERE `id` IN (SELECT `entry` FROM `gameobject_template` WHERE `name` LIKE '%Windblossom');
-- Fixed cooldown of cleansed GO
UPDATE `gameobject_template` SET `data6` = @CLEANSED_REACTIVATE WHERE `name` = 'Cleansed Windblossom';
-- Fixed spawn time (corrupted already spawned, cleansed despawned)
UPDATE `gameobject` SET `spawntimesecs` = @CORRUPTED_DESPAWN WHERE `id` IN (SELECT `entry` FROM `gameobject_template` WHERE `name` = 'Corrupted Windblossom');
UPDATE `gameobject` SET `spawntimesecs` = @CLEANSED_DESPAWN WHERE `id` IN (SELECT `entry` FROM `gameobject_template` WHERE `name` = 'Cleansed Windblossom');

UPDATE `quest_template` SET `RequiredRaces` = 255, `QuestFlags` = 264 WHERE `Title` = 'Corrupted Windblossom';


/*
UPDATE `dbscripts_on_quest_end` SET `datalong` = @GUID + 31 WHERE `id` = 4343;
INSERT INTO `dbscripts_on_quest_end` VALUES
(4343, 0, 27, 4, 0, 164887, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(4343, 180, 27, 8, 0, 164887, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
UPDATE `dbscripts_on_quest_end` SET `datalong` = @GUID + 32 WHERE `id` = 4115;
INSERT INTO `dbscripts_on_quest_end` VALUES
(4115, 0, 27, 4, 0, 173327, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(4115, 180, 27, 8, 0, 173327, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
UPDATE `dbscripts_on_quest_end` SET `datalong` = @GUID + 33 WHERE `id` = 4221;
INSERT INTO `dbscripts_on_quest_end` VALUES
(4221, 0, 27, 4, 0, 174599, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(4221, 180, 27, 8, 0, 174599, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
UPDATE `dbscripts_on_quest_end` SET `datalong` = @GUID + 34 WHERE `id` = 4222;
INSERT INTO `dbscripts_on_quest_end` VALUES
(4222, 0, 27, 4, 0, 174600, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(4222, 180, 27, 8, 0, 174600, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
*/
