-- Fix wrong nodes for resources like herbs, minerals or fishes
-- No longer thorium vein in Elwynn Forest or Peacebloom in Eastern Plaguelands.
-- This closes #524

-- ------------------------------
-- Fish schools
-- ------------------------------

-- Sagefish schools -> Floating Debris in the Barrens
UPDATE `gameobject` SET `id` = 180655 WHERE `guid` IN (915,919,936,952,1048,1188,1438,1442,1461,5120,10964,15202,15419,16576,16578,16580,64687);
-- Sagefish schools -> Floating Debris in Westfall
UPDATE `gameobject` SET `id` = 180655 WHERE `guid` IN (1639,1646,1655,1691,1729,1734,1736,1762,1769,64683,64685);
-- Sagefish schools -> Floating Debris in Darkshore
UPDATE `gameobject` SET `id` = 180655 WHERE `guid` IN (916,5123,5178,5181,5183,5190,5322,5340,5435,5441,5465,6808,6844,6864,10963,10967,14085,14087,14089,14097,15111,15200,15204,15476,15497,15633,15763,15771,15776,15779,16548);

UPDATE `gameobject_template` SET `name` = "Schooner Wreckage Pool" WHERE `entry` = 180662;
UPDATE `gameobject_template` SET `name` = "Waterlogged Wreckage Pool" WHERE `entry` = 180685;
