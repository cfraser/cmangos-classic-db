-- Fixed model of GO 177272 "Moonwell" in Stormwind which was displaying roasted meat instead
UPDATE `gameobject_template` SET `displayID` = 1407 WHERE `entry` = 177272;
UPDATE `gameobject` SET `animprogress` = 100, `state` = 1 WHERE `id` = 177272;

-- Removed wrong spawn of NPC 14991 (League of Arathor Emissary)
DELETE FROM `creature` WHERE `guid` = 54621;

-- Fixed completion text for quest 4261 (Ancient Spirit)
UPDATE `quest_template` SET `OfferRewardText` = 'Yes, $N. Felwood has been through much hardship. Thank you for what you have done.$B$BOne day, we may be able to reclaim Felwood from the corruption; every kind deed helps.' WHERE `entry` = 4261;

-- Removed wrong quest text for quest 3382 (A Crew Under Fire)
UPDATE `quest_template` SET `RequestItemsText` = '' WHERE `entry` = 3382;

-- Fixed language and gossip_option used by Alliance druid trainer in Felwood
UPDATE `npc_text` SET `lang0` = 7 WHERE `ID` = 5716;
UPDATE `gossip_menu_option` SET `condition_id` = 21 WHERE `menu_id` = 4605 AND `id` = 0;

-- Removed duplicate NPC in Feralas
DELETE FROM `creature` WHERE `guid` = 51518;
DELETE FROM `creature_addon` WHERE `guid` = 51518;

-- Lorekeeper Raintotem - Mulgore (Entry 3233)
UPDATE npc_text SET `text0_0`='Only the most valiant and honorable amongst the tribe can earn the honor of being laid to rest at Red Rocks.' WHERE `ID`=17838;
-- Kibler - Burning Steppes (Entry 10260)
UPDATE npc_text SET `text0_0`='What!' WHERE `ID`=17805;
-- Terl Arakor - Wetlands (Entry 2153)
UPDATE npc_text SET `text0_0`='This is MY WAGON!$B$BMINE!' WHERE `ID`=16528;
-- Griniblix the Spectator - Dire Maul - Feralas (Entry 14395)
UPDATE npc_text SET `text0_0`='Woohoo! They are into it now!' WHERE `ID`=16432;
-- Commander Aggro gosh - Grom Gol - STV (Entry 2464)
UPDATE npc_text SET `text0_0`='Welcome to Grom\'gol, $C. Before we get off on the wrong foot, I\'ll have you know that I won\'t have slackers in my Base Camp.. I expect a healthy $R like you to pull your own weight around here.' WHERE `ID`=16334;
-- Far Seer Mok thardin - Grom Gol STV (Entry 2465)
UPDATE npc_text SET `text0_0`='Even in this remote corner of the world, know that Hellscream\'s eyes are upon you.' WHERE `ID`=16335;
-- Jangdor Swiftstrider - Camp Mojache - Feralas (Entry 7854)
UPDATE npc_text SET `text0_0`='Welcome to Camp Mojache, brave $C. How may I assist you this day?' WHERE `ID`=2368;
-- Baron Revilgaz - Booty Bay (Entry 2496)
DELETE FROM gossip_menu WHERE `entry`=6685 AND `text_id`=13062;

-- Quest 1532 This adds the ObjectRewardText text for the Shaman quest
UPDATE quest_template SET `OfferRewardText`='For the time being. I shall give you what you need to focus your spells and to call upon the spirits of air. Take this totem, and when you are ready, train with me some more.' WHERE `entry`=1532;