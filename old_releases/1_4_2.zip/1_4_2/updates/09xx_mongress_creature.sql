-- Added missing alternate spawn to rare NPC 14344 (Mongress) in Felwood
-- Source: http://www.wowhead.com/npc=14344

SET @GUID := 140770;
SET @POOL := 1211;

DELETE FROM `creature` WHERE `guid` BETWEEN @GUID + 1 AND @GUID + 3;
INSERT INTO `creature` VALUES
(@GUID + 1, 14344, 1, 0, 0, 4053.78, -645.117, 298.641, 4.76121, 28800, 5, 0, 3322, 0, 0, 1),
(@GUID + 2, 14344, 1, 0, 0, 4196.29, -849.411, 258.506, 2.20474, 28800, 5, 0, 3322, 0, 0, 1),
(@GUID + 3, 14344, 1, 0, 0, 3914.9, -1063.66, 243.252, 4.07791, 28800, 5, 0, 3322, 0, 0, 1);
UPDATE `creature` SET `spawndist` = 5, `MovementType` = 1, `spawntimesecs` = 8 * 60 * 60 WHERE `id` = 14344;

DELETE FROM `pool_creature_template` WHERE `id` = 14344;
INSERT INTO `pool_creature_template` VALUES
(14344, @POOL + 1, 0, 'Mongress (14344)');

DELETE FROM `pool_template` WHERE `entry` = @POOL + 1;
INSERT INTO `pool_template` VALUES
(@POOL + 1, 1, 'Mongress (14344)');
