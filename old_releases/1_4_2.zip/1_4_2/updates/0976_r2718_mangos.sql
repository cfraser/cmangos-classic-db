UPDATE gameobject_template SET ScriptName='go_fathom_stone' WHERE entry=177964;
