-- Scripted Gurubashi Arena event by adding waypoints and text to
-- NPC 14508 (Short John Mithril)
DELETE FROM `creature_movement_template` WHERE `entry`=14508;
INSERT INTO `creature_movement_template` (`entry`, `point`, `position_x`, `position_y`, `position_z`) VALUES
(14508,1,-13187.14, 319.7746, 33.2346),
(14508,2,-13215.14, 322.7813, 33.24456),
(14508,3,-13234.32, 314.1292, 33.20762),
(14508,4,-13248.82, 299.0459, 33.22644),
(14508,5,-13254.88, 284.0705, 33.24255),
(14508,6,-13255.58, 264.5797, 33.24498),
(14508,7,-13247.58, 243.589, 33.20824),
(14508,8,-13237.57, 231.7462, 33.23737),
(14508,9,-13233.31, 231.8894, 33.2352),
(14508,10,-13235.35, 231.8208, 33.23225),
(14508,11,-13234.51, 239.4648, 33.36068),
(14508,12,-13239.65, 247.5611, 29.29738),
(14508,13,-13244.49, 256.3933, 22.63047),
(14508,14,-13241.24, 261.35, 21.93297),
(14508,15,-13204.08, 277.1676, 21.98207),
(14508,16,-13219.24, 275.4513, 21.98207),
(14508,17,-13240.61, 268.921, 21.93298),
(14508,18,-13240.61, 268.921, 21.93298),
(14508,19,-13244.04, 261.8775, 21.93297),
(14508,20,-13243.42, 254.9109, 23.88685),
(14508,21,-13239.03, 245.3709, 29.23729),
(14508,22,-13233.62, 238.1597, 33.35011),
(14508,23,-13237.55, 232.776, 33.23082),
(14508,24,-13250.02, 248.9038, 33.23286),
(14508,25,-13255.25, 264.0384, 33.24439),
(14508,26,-13255.29, 282.6273, 33.24288),
(14508,27,-13248.91, 298.4456, 33.24187),
(14508,28,-13233.84, 314.3157, 33.20814),
(14508,29,-13215.96, 322.7598, 33.24435),
(14508,30,-13199.4, 323.3979, 33.24255),
(14508,31,-13188.29, 320.0755, 33.23479),
(14508,32,-13184.82, 329.8854, 37.95504),
(14508,33,-13184.48, 332.6711, 40.32992);
UPDATE `creature_template` SET `MovementType` = 2 WHERE `entry` = 14508;
UPDATE `creature` SET `position_x` = -13187.14, `position_y` = 319.7746, `position_z` = 33.2346, `MovementType` = 2 WHERE `id` = 14508;

DELETE FROM `game_event_creature` WHERE `guid` = 636;
INSERT INTO `game_event_creature` VALUES (636, 16);

DELETE FROM `game_event_gameobject` WHERE  `guid`=12029 AND `event`=16;
-- DELETE FROM `gameobject` WHERE  `guid`=12029;

UPDATE `creature_movement_template` SET `script_id` = 1450802 WHERE `entry` = 14508 AND `point` = 2;
UPDATE `creature_movement_template` SET `script_id` = 1450816 WHERE `entry` = 14508 AND `point` = 16;
UPDATE `creature_movement_template` SET `script_id` = 1450819 WHERE `entry` = 14508 AND `point` = 19;
UPDATE `creature_movement_template` SET `script_id` = 1450833, `waittime` = 3 * 3500 * 1000 WHERE `entry` = 14508 AND `point` = 33;

SET @ENTRY := 2000005783;

DELETE FROM `dbscripts_on_creature_movement` WHERE `id` IN (1450802, 1450816, 1450819, 1450833);
INSERT INTO `dbscripts_on_creature_movement` VALUES
(1450802, 0, 0, 0, 0, 0, 0, 0, @ENTRY, 0, 0, 0, 0, 0, 0, 0, 'Short John Mithril - yell 1'),
(1450816, 0, 0, 0, 0, 0, 0, 0, @ENTRY + 1, 0, 0, 0, 0, 0, 0, 0, 'Short John Mithril - yell 2'),
(1450819, 0, 9, 12029, 3 * 3500, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'Short John Mithril - spawn chest'),
(1450833, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4.41568, 'Short John Mithril - face arena');

DELETE FROM `db_script_string` WHERE `entry` IN (@ENTRY, @ENTRY + 1);
INSERT INTO `db_script_string` VALUES
(@ENTRY, 'Arrr, Me Hearties!   I be havin'' some extra Treasure that I be givin'' away at the Gurubashi Arena!  All ye need do to collect it is open the chest I leave on the arena floor!', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 6, 0, 0, NULL),
(@ENTRY + 1, 'Let the Bloodletting Begin!', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 6, 0, 0, NULL);
