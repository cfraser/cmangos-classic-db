
UPDATE `quest_template` SET `MinLevel`='50', `QuestLevel`='52', `RewMoneyMaxLevel`='2280' WHERE `entry`='8419';
