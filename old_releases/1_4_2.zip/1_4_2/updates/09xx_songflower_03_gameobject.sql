-- Source: http://www.wowwiki.com/Cenarion_Beacon

SET @CORRUPTED_DESPAWN   := 3595;
SET @CLEANSED_DESPAWN 	 := -3595;
SET @CLEANSED_REACTIVATE := 25 * 60;

-- ----------------------------
-- Night Dragon 
-- ----------------------------

SET @GUID := 900000;

DELETE FROM `gameobject` WHERE `id` IN (SELECT `entry` FROM `gameobject_template` WHERE `name` LIKE '%Night Dragon');

DELETE FROM `gameobject` WHERE `guid` BETWEEN @GUID + 41 AND @GUID + 48;
INSERT INTO `gameobject` VALUES
-- corrupted
(@GUID + 41, 173324, 1, 3780.32, -1176, 220.555, 0.167, 0, 0, 0.083403, 0.996516, 180, 100, 1),
(@GUID + 42, 164885, 1, 3831.22, -1374, 207.119, 0.85, 0, 0, 0.412321, 0.911039, 180, 100, 1),
(@GUID + 43, 174684, 1, 4867.17, -384, 350.56, 2.762, 0, 0, 0.982043, 0.188659, 180, 100, 1),
(@GUID + 44, 174608, 1, 6595.34, -827.373, 474.05, 3.28765, 0, 0, 0.997335, -0.0729638, 180, 100, 1),
-- cleansed
(@GUID + 45, 174609, 1, 3780.32, -1176, 220.555, 0.167, 0, 0, 0.083403, 0.996516, -180, 100, 1),
(@GUID + 46, 164881, 1, 3831.22, -1374, 207.119, 0.85, 0, 0, 0.412321, 0.911039, -180, 100, 1),
(@GUID + 47, 173325, 1, 4867.17, -384, 350.56, 2.762, 0, 0, 0.982043, 0.188659, -180, 100, 1),
(@GUID + 48, 174685, 1, 6595.34, -827.373, 474.05, 3.28765, 0, 0, 0.997335, -0.0729638, -180, 100, 1);

-- ----------------------
-- Night Dragon 
-- ----------------------
UPDATE `dbscripts_on_quest_end` SET `datalong` = @GUID + 45 WHERE `id` = 4447;
INSERT INTO `dbscripts_on_quest_end` VALUES
(4447, 0, 27, 4, 0, 173324, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(4447, @CORRUPTED_DESPAWN, 27, 8, 0, 173324, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
DELETE FROM `dbscripts_on_event` WHERE `id` = 4247;
INSERT INTO `dbscripts_on_event` VALUES
(4247, 0, 15, 15344, 0, 0, 0, 0x02, 0, 0, 0, 0, 0, 0, 0, 0, '');
-- (4247, 5, 27, 8, 0, 173324, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
UPDATE `gameobject_questrelation` SET `id` = 173324 WHERE `quest` = 4447;
UPDATE `gameobject_involvedrelation` SET `id` = 173324 WHERE `quest` = 4447;

UPDATE `dbscripts_on_quest_end` SET `datalong` = @GUID + 46 WHERE `id` = 4119;
INSERT INTO `dbscripts_on_quest_end` VALUES
(4119, 0, 27, 4, 0, 164885, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(4119, @CORRUPTED_DESPAWN, 27, 8, 0, 164885, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
DELETE FROM `dbscripts_on_event` WHERE `id` = 293;
INSERT INTO `dbscripts_on_event` VALUES
(293, 0, 15, 15344, 0, 0, 0, 0x02, 0, 0, 0, 0, 0, 0, 0, 0, '');
-- (293, 5, 27, 8, 0, 164885, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
UPDATE `gameobject_questrelation` SET `id` = 164885 WHERE `quest` = 4119;
UPDATE `gameobject_involvedrelation` SET `id` = 164885 WHERE `quest` = 4119;

UPDATE `dbscripts_on_quest_end` SET `datalong` = @GUID + 47 WHERE `id` = 4462;
INSERT INTO `dbscripts_on_quest_end` VALUES
(4462, 0, 27, 4, 0, 174684, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(4462, @CORRUPTED_DESPAWN, 27, 8, 0, 174684, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
DELETE FROM `dbscripts_on_event` WHERE `id` = 4178;
INSERT INTO `dbscripts_on_event` VALUES
(4178, 0, 15, 15344, 0, 0, 0, 0x02, 0, 0, 0, 0, 0, 0, 0, 0, '');
-- (4178, 5, 27, 8, 0, 174684, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
UPDATE `gameobject_questrelation` SET `id` = 174684 WHERE `quest` = 4462;
UPDATE `gameobject_involvedrelation` SET `id` = 174684 WHERE `quest` = 4462;

UPDATE `dbscripts_on_quest_end` SET `datalong` = @GUID + 48 WHERE `id` = 4448;
INSERT INTO `dbscripts_on_quest_end` VALUES
(4448, 0, 27, 4, 0, 174608, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(4448, @CORRUPTED_DESPAWN, 27, 8, 0, 174608, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
DELETE FROM `dbscripts_on_event` WHERE `id` = 4265;
INSERT INTO `dbscripts_on_event` VALUES
(4265, 0, 15, 15344, 0, 0, 0, 0x02, 0, 0, 0, 0, 0, 0, 0, 0, '');
-- (4265, 5, 27, 8, 0, 174608, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
UPDATE `gameobject_questrelation` SET `id` = 174608 WHERE `quest` = 4448;
UPDATE `gameobject_involvedrelation` SET `id` = 174608 WHERE `quest` = 4448;


-- Cleanup
-- Fixed animation of spawned gameobjects
UPDATE `gameobject` SET `animprogress` = 100 WHERE `id` IN (SELECT `entry` FROM `gameobject_template` WHERE `name` LIKE '%Night Dragon');
-- Fixed cooldown of cleansed GO
UPDATE `gameobject_template` SET `data6` = @CLEANSED_REACTIVATE WHERE `name` = 'Cleansed Night Dragon';
-- Fixed spawn time (corrupted already spawned, cleansed despawned)
UPDATE `gameobject` SET `spawntimesecs` = @CORRUPTED_DESPAWN WHERE `id` IN (SELECT `entry` FROM `gameobject_template` WHERE `name` = 'Corrupted Night Dragon');
UPDATE `gameobject` SET `spawntimesecs` = @CLEANSED_DESPAWN WHERE `id` IN (SELECT `entry` FROM `gameobject_template` WHERE `name` = 'Cleansed Night Dragon');
