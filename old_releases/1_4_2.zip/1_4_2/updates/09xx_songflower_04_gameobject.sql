-- Source: http://www.wowwiki.com/Cenarion_Beacon

SET @CORRUPTED_DESPAWN   := 3595;
SET @CLEANSED_DESPAWN 	 := -3595;
SET @CLEANSED_REACTIVATE := 25 * 60;

-- ----------------------------
-- Night Dragon 
-- ----------------------------

SET @GUID := 900000;

DELETE FROM `gameobject` WHERE `id` IN (SELECT `entry` FROM `gameobject_template` WHERE `name` LIKE '%Whipper Root');

DELETE FROM `gameobject` WHERE `guid` BETWEEN @GUID + 49 AND @GUID + 60;
INSERT INTO `gameobject` VALUES
-- corrupted
(@GUID + 49, 164888, 1, 6305.33, -957, 417.3, 2.499, 0, 0, 0.948827, 0.315797, 180, 100, 1),
(@GUID + 50, 173284, 1, 6433.25, -1267, 383.206, 2.234, 0, 0, 0.898789, 0.438381, 180, 100, 1),
(@GUID + 51, 174605, 1, 6666.67, -1200, 471.328, 2.164, 0, 0, 0.882899, 0.469563, 180, 100, 1),
(@GUID + 52, 174606, 1, 6353.12, -690.658, 477.432, 0.730612, 0, 0, 0.357235, 0.934014, 180, 100, 1),
(@GUID + 53, 174607, 1, 6434.15, -1268.32, 383.379, 3.20225, 0, 0, 0.99954, -0.030324, 180, 100, 1),
(@GUID + 54, 174686, 1, 6669.76, -1209.39, 469.181, 3.43473, 0, 0, 0.989278, -0.146044, 180, 100, 1),
-- cleansed
(@GUID + 55, 164883, 1, 6305.33, -957, 417.3, 2.499, 0, 0, 0.948827, 0.315797, -180, 100, 1),
(@GUID + 56, 174622, 1, 6433.25, -1267, 383.206, 2.234, 0, 0, 0.898789, 0.438381, -180, 100, 1),
(@GUID + 57, 174623, 1, 6666.67, -1200, 471.328, 2.164, 0, 0, 0.882899, 0.469563, -180, 100, 1),
(@GUID + 58, 174624, 1, 6353.12, -690.658, 477.432, 0.730612, 0, 0, 0.357235, 0.934014, -180, 100, 1),
(@GUID + 59, 174625, 1, 6434.15, -1268.32, 383.379, 3.20225, 0, 0, 0.99954, -0.030324, -180, 100, 1),
(@GUID + 60, 174687, 1, 6669.76, -1209.39, 469.181, 3.43473, 0, 0, 0.989278, -0.146044, -180, 100, 1);

-- ----------------------
-- Whipper Root 
-- ----------------------
UPDATE `dbscripts_on_quest_end` SET `datalong` = @GUID + 55 WHERE `id` = 4117;
INSERT INTO `dbscripts_on_quest_end` VALUES
(4117, 0, 27, 4, 0, 164888, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(4117, @CORRUPTED_DESPAWN, 27, 8, 0, 164888, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
DELETE FROM `dbscripts_on_event` WHERE `id` = 4118;
INSERT INTO `dbscripts_on_event` VALUES
(4118, 0, 15, 15343, 0, 0, 0, 0x02, 0, 0, 0, 0, 0, 0, 0, 0, '');
-- (4118, 5, 27, 8, 0, 164888, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
UPDATE `gameobject_questrelation` SET `id` = 164888 WHERE `quest` = 4117;
UPDATE `gameobject_involvedrelation` SET `id` = 164888 WHERE `quest` = 4117;

UPDATE `dbscripts_on_quest_end` SET `datalong` = @GUID + 56 WHERE `id` = 4443;
INSERT INTO `dbscripts_on_quest_end` VALUES
(4443, 0, 27, 4, 0, 173284, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(4443, @CORRUPTED_DESPAWN, 27, 8, 0, 173284, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
DELETE FROM `dbscripts_on_event` WHERE `id` = 4234;
INSERT INTO `dbscripts_on_event` VALUES
(4234, 0, 15, 15343, 0, 0, 0, 0x02, 0, 0, 0, 0, 0, 0, 0, 0, '');
-- (4234, 5, 27, 8, 0, 173284, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
UPDATE `gameobject_questrelation` SET `id` = 173284 WHERE `quest` = 4443;
UPDATE `gameobject_involvedrelation` SET `id` = 173284 WHERE `quest` = 4443;

UPDATE `dbscripts_on_quest_end` SET `datalong` = @GUID + 57 WHERE `id` = 4444;
INSERT INTO `dbscripts_on_quest_end` VALUES
(4444, 0, 27, 4, 0, 174605, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(4444, @CORRUPTED_DESPAWN, 27, 8, 0, 174605, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
DELETE FROM `dbscripts_on_event` WHERE `id` = 4235;
INSERT INTO `dbscripts_on_event` VALUES
(4235, 0, 15, 15343, 0, 0, 0, 0x02, 0, 0, 0, 0, 0, 0, 0, 0, '');
-- (4235, 5, 27, 8, 0, 174605, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
UPDATE `gameobject_questrelation` SET `id` = 174605 WHERE `quest` = 4444;
UPDATE `gameobject_involvedrelation` SET `id` = 174605 WHERE `quest` = 4444;

UPDATE `dbscripts_on_quest_end` SET `datalong` = @GUID + 58 WHERE `id` = 4445;
INSERT INTO `dbscripts_on_quest_end` VALUES
(4445, 0, 27, 4, 0, 174606, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(4445, @CORRUPTED_DESPAWN, 27, 8, 0, 174606, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
DELETE FROM `dbscripts_on_event` WHERE `id` = 4236;
INSERT INTO `dbscripts_on_event` VALUES
(4236, 0, 15, 15343, 0, 0, 0, 0x02, 0, 0, 0, 0, 0, 0, 0, 0, '');
-- (4236, 5, 27, 8, 0, 174606, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
UPDATE `gameobject_questrelation` SET `id` = 174606 WHERE `quest` = 4445;
UPDATE `gameobject_involvedrelation` SET `id` = 174606 WHERE `quest` = 4445;

UPDATE `dbscripts_on_quest_end` SET `datalong` = @GUID + 59 WHERE `id` = 4446;
INSERT INTO `dbscripts_on_quest_end` VALUES
(4446, 0, 27, 4, 0, 174607, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(4446, @CORRUPTED_DESPAWN, 27, 8, 0, 174607, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
DELETE FROM `dbscripts_on_event` WHERE `id` = 4237;
INSERT INTO `dbscripts_on_event` VALUES
(4237, 0, 15, 15343, 0, 0, 0, 0x02, 0, 0, 0, 0, 0, 0, 0, 0, '');
-- (4237, 5, 27, 8, 0, 174607, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
UPDATE `gameobject_questrelation` SET `id` = 174607 WHERE `quest` = 4446;
UPDATE `gameobject_involvedrelation` SET `id` = 174607 WHERE `quest` = 4446;

UPDATE `dbscripts_on_quest_end` SET `datalong` = @GUID + 60 WHERE `id` = 4461;
INSERT INTO `dbscripts_on_quest_end` VALUES
(4461, 0, 27, 4, 0, 174686, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(4461, @CORRUPTED_DESPAWN, 27, 8, 0, 174686, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
DELETE FROM `dbscripts_on_event` WHERE `id` = 4260;
INSERT INTO `dbscripts_on_event` VALUES
(4260, 0, 15, 15343, 0, 0, 0, 0x02, 0, 0, 0, 0, 0, 0, 0, 0, '');
-- (4260, 5, 27, 8, 0, 174686, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
UPDATE `gameobject_questrelation` SET `id` = 174686 WHERE `quest` = 4461;
UPDATE `gameobject_involvedrelation` SET `id` = 174686 WHERE `quest` = 4461;


-- Cleanup
-- Fixed animation of spawned gameobjects
UPDATE `gameobject` SET `animprogress` = 100 WHERE `id` IN (SELECT `entry` FROM `gameobject_template` WHERE `name` LIKE '%Whipper Root');
-- Fixed cooldown of cleansed GO
UPDATE `gameobject_template` SET `data6` = @CLEANSED_REACTIVATE WHERE `name` = 'Cleansed Whipper Root';
-- Fixed spawn time (corrupted already spawned, cleansed despawned)
UPDATE `gameobject` SET `spawntimesecs` = @CORRUPTED_DESPAWN WHERE `id` IN (SELECT `entry` FROM `gameobject_template` WHERE `name` = 'Corrupted Whipper Root');
UPDATE `gameobject` SET `spawntimesecs` = @CLEANSED_DESPAWN WHERE `id` IN (SELECT `entry` FROM `gameobject_template` WHERE `name` = 'Cleansed Whipper Root');

UPDATE `quest_template` SET `RequiredRaces` = 255, `QuestFlags` = 264 WHERE `Title` = 'Corrupted Whipper Root';