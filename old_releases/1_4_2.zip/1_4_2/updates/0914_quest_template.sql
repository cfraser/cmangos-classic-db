


-- --------------------

UPDATE `quest_template` SET `PrevQuestId`='0' WHERE `entry`='509';
UPDATE `quest_template` SET `PrevQuestId`='0' WHERE `entry`='501';
