-- Fixed Shade of Hakkar encounter in Sunken Temple
UPDATE `creature_template` SET `UnitFlags`=33554752 WHERE `Entry`=8440;
