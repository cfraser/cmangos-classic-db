
UPDATE `quest_template` SET `RewMoneyMaxLevel`='390' WHERE `entry`='8262';
UPDATE `quest_template` SET `RewMoneyMaxLevel`='390' WHERE `entry`='8265';
UPDATE `quest_template` SET `RewMoneyMaxLevel`='162' WHERE `entry`='8260';
UPDATE `quest_template` SET `RewMoneyMaxLevel`='162' WHERE `entry`='8263';
UPDATE `quest_template` SET `RewMoneyMaxLevel`='228' WHERE `entry`='8261';
UPDATE `quest_template` SET `RewMoneyMaxLevel`='228' WHERE `entry`='8264';
