-- Fixed loot of item 20767 (Scum covered bag)
-- thanks thetrueanimal for pointing. This closes #745
UPDATE `item_template` SET `minMoneyLoot` = 500, `maxMoneyLoot` = 2000 WHERE `entry` = 20767;
UPDATE `item_loot_template` SET `groupid` = 1, `ChanceOrQuestChance` = 33 WHERE `entry` = 20767 AND `item` IN (1710, 3827);
UPDATE `item_loot_template` SET `groupid` = 1, `ChanceOrQuestChance` = 0 WHERE `entry` = 20767 AND `item` IN (3928, 6149);
DELETE FROM `item_loot_template` WHERE `entry` = 20767 AND `item` = 24707;
INSERT INTO `item_loot_template` VALUES (20767, 24707, 4.2, 0, -24707, 1, 0);

DELETE FROM `reference_loot_template` WHERE `entry` = 24707;
INSERT INTO `reference_loot_template` VALUES 
(24707, 7989, 0, 1, 1, 1, 0),
(24707, 7990, 0, 1, 1, 1, 0),
(24707, 7991, 0, 1, 1, 1, 0),
(24707, 7993, 0, 1, 1, 1, 0),
(24707, 8028, 0, 1, 1, 1, 0),
(24707, 8029, 0, 1, 1, 1, 0),
(24707, 8389, 0, 1, 1, 1, 0),
(24707, 8390, 0, 1, 1, 1, 0),
(24707, 8398, 0, 1, 1, 1, 0),
(24707, 8399, 0, 1, 1, 1, 0),
(24707, 8400, 0, 1, 1, 1, 0),
(24707, 8401, 0, 1, 1, 1, 0),
(24707, 9295, 0, 1, 1, 1, 0),
(24707, 9296, 0, 1, 1, 1, 0),
(24707, 9297, 0, 1, 1, 1, 0),
(24707, 9298, 0, 1, 1, 1, 0),
(24707, 10312, 0, 1, 1, 1, 0),
(24707, 10315, 0, 1, 1, 1, 0),
(24707, 10320, 0, 1, 1, 1, 0),
(24707, 10605, 0, 1, 1, 1, 0),
(24707, 10606, 0, 1, 1, 1, 0),
(24707, 10608, 0, 1, 1, 1, 0),
(24707, 11206, 0, 1, 1, 1, 0),
(24707, 11208, 0, 1, 1, 1, 0),
(24707, 11224, 0, 1, 1, 1, 0),
(24707, 11225, 0, 1, 1, 1, 0);
