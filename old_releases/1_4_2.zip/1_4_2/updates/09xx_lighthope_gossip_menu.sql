-- Fixed gossip menu for NPC added in patch 1.10 at Light's Hope Chapel
INSERT INTO `gossip_menu` VALUES
(7126, 8397, 0, 0), -- Angela Dosantos
(7127, 8396, 0, 0), -- Angela Dosantos
(7128, 8395, 0, 0), -- Angela Dosantos
(7129, 8394, 0, 0), -- Angela Dosantos
(7130, 8393, 0, 0), -- Angela Dosantos
(7131, 8392, 0, 0), -- Angela Dosantos
(7132, 8391, 0, 0), -- Angela Dosantos
(7133, 8390, 0, 0), -- Angela Dosantos
(7134, 8389, 0, 0), -- Angela Dosantos
(7135, 8388, 0, 0), -- Angela Dosantos
(7144, 8408, 0, 0), -- Leopold
(7145, 8409, 0, 0), -- Rohan
(7150, 8414, 0, 0), -- Angela Dosantos
(7151, 8415, 0, 0), -- Korfax
(7152, 8416, 0, 0), -- Rayne
(7208, 8498, 0, 0), -- Miranda
(7209, 8499, 0, 0), -- Miranda
(7210, 8500, 0, 0), -- Miranda
(7212, 8502, 0, 0), -- Miranda
(7213, 8503, 0, 0); -- Miranda

UPDATE `gossip_menu_option` SET `action_menu_id` = 7135 WHERE `menu_id` = 7096 AND `id` = 0; -- Angela Dosantos
UPDATE `gossip_menu_option` SET `action_menu_id` = 7144 WHERE `menu_id` = 7102 AND `id` = 1; -- Leopold
UPDATE `gossip_menu_option` SET `action_menu_id` = 7145 WHERE `menu_id` = 7101 AND `id` = 1; -- Rohan
UPDATE `gossip_menu_option` SET `action_menu_id` = 7150 WHERE `menu_id` = 7096 AND `id` = 1; -- Angela Dosantos
UPDATE `gossip_menu_option` SET `action_menu_id` = 7151 WHERE `menu_id` = 7099 AND `id` = 1; -- Korfax
UPDATE `gossip_menu_option` SET `action_menu_id` = 7152 WHERE `menu_id` = 7104 AND `id` = 1; -- Rayne
UPDATE `gossip_menu_option` SET `action_menu_id` = 7208 WHERE `menu_id` = 3461 AND `id` = 2; -- Miranda

INSERT INTO `gossip_menu_option` VALUES
(7127, 0, 0, 'Is there anything else?', 1, 1, 7126, 0, 0, 0, 0, NULL, 0),
(7128, 0, 0, 'Please, tell me more.', 1, 1, 7127, 0, 0, 0, 0, NULL, 0),
(7129, 0, 0, 'This is disturbing. Please continue.', 1, 1, 7128, 0, 0, 0, 0, NULL, 0),
(7130, 0, 0, 'What?', 1, 1, 7129, 0, 0, 0, 0, NULL, 0),
(7131, 0, 0, 'Please continue.', 1, 1, 7130, 0, 0, 0, 0, NULL, 0),
(7132, 0, 0, 'Please continue.', 1, 1, 7131, 0, 0, 0, 0, NULL, 0),
(7133, 0, 0, 'What corruption?', 1, 1, 7132, 0, 0, 0, 0, NULL, 0),
(7134, 0, 0, 'Please continue.', 1, 1, 7133, 0, 0, 0, 0, NULL, 0),
(7135, 0, 0, 'What Guardian? I don\'t understand any of this.', 1, 1, 7134, 0, 0, 0, 0, NULL, 0),
(7208, 0, 0, 'Friendly', 1, 1, 7213, 0, 0, 0, 0, NULL, 0),
(7208, 1, 0, 'Honored', 1, 1, 7209, 0, 0, 0, 0, NULL, 0),
(7208, 2, 0, 'Revered', 1, 1, 7210, 0, 0, 0, 0, NULL, 0),
(7208, 3, 0, 'Exalted', 1, 1, 7212, 0, 0, 0, 0, NULL, 0);
