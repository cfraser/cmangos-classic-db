-- Updated NPC position in Eastern Plagueland: Tyr's Hand
-- Suffering victims
UPDATE `creature` SET `position_x` = 1594.56, `position_y` = -5313.1, `position_z` = 69.84, `orientation` = 3.1 WHERE `guid` = 53036;
UPDATE `creature` SET `position_x` = 1598.14, `position_y` = -5314.94, `position_z` = 70.0242, `orientation` = 3.13426 WHERE `guid` = 84825;
UPDATE `creature` SET `position_x` = 1603.62, `position_y` = -5306.68, `position_z` = 70.045, `orientation` = 4.9 WHERE `guid` = 86149;
